# MySQL dump of database 'repo_erp' on host 'localhost'
# Backup Date and Time: 2023-10-26 11:07
# Built by Finesse ERP 2.4.7
# http://Finessewebtech.com
# Company: Finesse
# User: Administrator

# Compatibility: 2.4.1


SET NAMES latin1;


### Structure of table `fa_alloted_room` ###

DROP TABLE IF EXISTS `fa_alloted_room`;

CREATE TABLE `fa_alloted_room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_id` varchar(11) DEFAULT NULL,
  `bed_id` int(11) DEFAULT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '1',
  `from_date` datetime NOT NULL,
  `to_date` datetime NOT NULL,
  `remark` varchar(300) NOT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_alloted_room` ###


### Structure of table `fa_allowed_book` ###

DROP TABLE IF EXISTS `fa_allowed_book`;

CREATE TABLE `fa_allowed_book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_id` varchar(50) NOT NULL,
  `checkout_policy` varchar(100) NOT NULL,
  `no_book` int(10) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 ;

### Data of table `fa_allowed_book` ###

INSERT INTO `fa_allowed_book` VALUES
('39', 'No-001', 'Staff', '7', '0'),
('40', 'No-002', 'Student', '2', '0');

### Structure of table `fa_areas` ###

DROP TABLE IF EXISTS `fa_areas`;

CREATE TABLE `fa_areas` (
  `area_code` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`area_code`),
  UNIQUE KEY `description` (`description`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_areas` ###

INSERT INTO `fa_areas` VALUES
('1', 'Global', '0');

### Structure of table `fa_assembled_assets` ###

DROP TABLE IF EXISTS `fa_assembled_assets`;

CREATE TABLE `fa_assembled_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_category_id` int(11) NOT NULL,
  `item_sub_category_id` int(11) NOT NULL,
  `stock_id` varchar(20) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `inactive` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_category_id` (`item_category_id`),
  KEY `item_sub_category_id` (`item_sub_category_id`),
  KEY `asset_id` (`asset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_assembled_assets` ###


### Structure of table `fa_asset_issue_items` ###

DROP TABLE IF EXISTS `fa_asset_issue_items`;

CREATE TABLE `fa_asset_issue_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `qty_issued` double DEFAULT NULL,
  `unit_cost` double NOT NULL DEFAULT '0',
  `sl_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'NA',
  `room_no` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'NA',
  `department_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'NA',
  `seat_no` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'NA',
  `asset_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_asset_issue_items` ###


### Structure of table `fa_asset_master` ###

DROP TABLE IF EXISTS `fa_asset_master`;

CREATE TABLE `fa_asset_master` (
  `asset_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(10) NOT NULL,
  `code` varchar(100) NOT NULL,
  `inactive` tinyint(2) NOT NULL,
  `qty` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`asset_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

### Data of table `fa_asset_master` ###

INSERT INTO `fa_asset_master` VALUES
('1', '1', 'Development', '0', '4');

### Structure of table `fa_attachments` ###

DROP TABLE IF EXISTS `fa_attachments`;

CREATE TABLE `fa_attachments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type_no` int(11) NOT NULL DEFAULT '0',
  `trans_no` int(11) NOT NULL DEFAULT '0',
  `unique_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `filename` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `filetype` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `type_no` (`type_no`,`trans_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_attachments` ###


### Structure of table `fa_attendance` ###

DROP TABLE IF EXISTS `fa_attendance`;

CREATE TABLE `fa_attendance` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `overtime_id` int(11) NOT NULL,
  `hours_no` float NOT NULL DEFAULT '0',
  `rate` float NOT NULL DEFAULT '1',
  `att_date` date NOT NULL,
  PRIMARY KEY (`emp_id`,`overtime_id`,`att_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;

### Data of table `fa_attendance` ###


### Structure of table `fa_audit_trail` ###

DROP TABLE IF EXISTS `fa_audit_trail`;

CREATE TABLE `fa_audit_trail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` smallint(6) unsigned NOT NULL DEFAULT '0',
  `trans_no` int(11) unsigned NOT NULL DEFAULT '0',
  `user` smallint(6) unsigned NOT NULL DEFAULT '0',
  `stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `description` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fiscal_year` int(11) NOT NULL DEFAULT '0',
  `gl_date` date NOT NULL DEFAULT '0000-00-00',
  `gl_seq` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Seq` (`fiscal_year`,`gl_date`,`gl_seq`),
  KEY `Type_and_Number` (`type`,`trans_no`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_audit_trail` ###

INSERT INTO `fa_audit_trail` VALUES
('1', '25', '1', '1', '2023-09-20 22:24:32', NULL, '7', '2023-09-20', NULL),
('2', '25', '1', '1', '2023-09-20 22:24:32', NULL, '7', '2023-09-20', NULL),
('3', '26', '1', '1', '2023-09-20 22:35:49', NULL, '0', '2023-09-20', NULL),
('4', '26', '1', '1', '2023-09-20 22:35:49', 'Released.', '0', '0000-00-00', NULL),
('5', '29', '1', '1', '2023-09-20 22:36:25', 'Production.', '7', '2023-09-20', NULL),
('6', '25', '2', '1', '2023-09-20 22:25:13', NULL, '7', '0000-00-00', NULL),
('7', '26', '2', '1', '2023-09-20 22:40:42', NULL, '0', '2023-09-20', NULL),
('8', '26', '2', '1', '2023-09-20 22:40:42', 'Released.', '0', '0000-00-00', NULL),
('9', '29', '2', '1', '2023-09-20 22:41:29', 'Production.', '7', '2023-09-20', NULL),
('10', '25', '3', '1', '2023-10-03 23:55:33', NULL, '7', '0000-00-00', NULL),
('11', '26', '3', '1', '2023-09-20 06:00:57', NULL, '0', '2023-09-20', NULL),
('12', '26', '3', '1', '2023-09-20 06:00:57', 'Released.', '0', '0000-00-00', '0'),
('13', '29', '8', '1', '2023-09-20 06:09:52', 'Production.', '7', '2023-09-20', '0'),
('14', '25', '1', '1', '2023-09-20 22:24:32', NULL, '7', '2023-09-21', NULL),
('15', '25', '1', '1', '2023-09-20 22:24:32', NULL, '7', '2023-09-21', '0'),
('16', '25', '2', '1', '2023-09-20 22:25:13', NULL, '7', '2023-09-21', NULL),
('17', '25', '2', '1', '2023-09-20 22:25:13', NULL, '7', '2023-09-21', '0'),
('18', '26', '1', '1', '2023-09-20 22:35:49', NULL, '0', '2023-09-21', NULL),
('19', '26', '1', '1', '2023-09-20 22:35:49', 'Released.', '0', '0000-00-00', '0'),
('20', '29', '1', '1', '2023-09-20 22:36:25', 'Production.', '7', '2023-09-21', '0'),
('21', '25', '3', '1', '2023-10-03 23:55:33', NULL, '7', '0000-00-00', NULL),
('22', '26', '2', '1', '2023-09-20 22:40:42', NULL, '0', '2023-09-21', NULL),
('23', '26', '2', '1', '2023-09-20 22:40:42', 'Released.', '0', '0000-00-00', '0'),
('24', '29', '2', '1', '2023-09-20 22:41:29', 'Production.', '7', '2023-09-21', '0'),
('25', '25', '4', '1', '2023-10-03 23:55:33', NULL, '7', '2023-10-04', '0'),
('26', '25', '3', '1', '2023-10-03 23:55:33', NULL, '7', '2023-10-04', '0');

### Structure of table `fa_author_details` ###

DROP TABLE IF EXISTS `fa_author_details`;

CREATE TABLE `fa_author_details` (
  `auth_id` int(11) NOT NULL AUTO_INCREMENT,
  `auth_name` varchar(100) NOT NULL,
  `auth_code` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`auth_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;

### Data of table `fa_author_details` ###


### Structure of table `fa_bank_accounts` ###

DROP TABLE IF EXISTS `fa_bank_accounts`;

CREATE TABLE `fa_bank_accounts` (
  `account_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `account_type` smallint(6) NOT NULL DEFAULT '0',
  `bank_account_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bank_account_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bank_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bank_address` tinytext COLLATE utf8_unicode_ci,
  `bank_curr_code` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_curr_act` tinyint(1) NOT NULL DEFAULT '0',
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `bank_charge_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_reconciled_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ending_reconcile_balance` double NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `bank_account_name` (`bank_account_name`),
  KEY `bank_account_number` (`bank_account_number`),
  KEY `account_code` (`account_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_bank_accounts` ###

INSERT INTO `fa_bank_accounts` VALUES
('1002', '0', 'car bank1', '21222000', 'sbi', 'patna', 'INR', '1', '1', '1002', '0000-00-00 00:00:00', '0', '0');

### Structure of table `fa_bank_trans` ###

DROP TABLE IF EXISTS `fa_bank_trans`;

CREATE TABLE `fa_bank_trans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` smallint(6) DEFAULT NULL,
  `trans_no` int(11) DEFAULT NULL,
  `bank_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ref` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trans_date` date NOT NULL DEFAULT '0000-00-00',
  `amount` double DEFAULT NULL,
  `dimension_id` int(11) NOT NULL DEFAULT '0',
  `dimension2_id` int(11) NOT NULL DEFAULT '0',
  `person_type_id` int(11) NOT NULL DEFAULT '0',
  `person_id` tinyblob,
  `reconciled` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bank_act` (`bank_act`,`ref`),
  KEY `type` (`type`,`trans_no`),
  KEY `bank_act_2` (`bank_act`,`reconciled`),
  KEY `bank_act_3` (`bank_act`,`trans_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_bank_trans` ###


### Structure of table `fa_bom` ###

DROP TABLE IF EXISTS `fa_bom`;

CREATE TABLE `fa_bom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `component` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `workcentre_added` int(11) NOT NULL DEFAULT '0',
  `loc_code` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `quantity` double NOT NULL DEFAULT '1',
  `serialno` text COLLATE utf8_unicode_ci NOT NULL,
  `issue_date` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`parent`,`component`,`workcentre_added`,`loc_code`),
  KEY `component` (`component`),
  KEY `id` (`id`),
  KEY `loc_code` (`loc_code`),
  KEY `parent` (`parent`,`loc_code`),
  KEY `workcentre_added` (`workcentre_added`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_bom` ###

INSERT INTO `fa_bom` VALUES
('1', '1Gigabyte', '16GBDDR3', '2', 'PAT', '1', '', '2023-09-21', '0'),
('2', '1Gigabyte', '1TBHDD', '2', 'PAT', '1', '', '2023-09-21', '0'),
('3', 'Corsiar1', '16GBDDR3', '2', 'PAT', '1', '', '2023-09-21', '0'),
('4', 'Corsiar1', '1TBHDD', '2', 'PAT', '1', '', '2023-09-21', '0');

### Structure of table `fa_bom_drawings` ###

DROP TABLE IF EXISTS `fa_bom_drawings`;

CREATE TABLE `fa_bom_drawings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(60) CHARACTER SET utf8 NOT NULL,
  `type_no` varchar(50) CHARACTER SET utf8 NOT NULL,
  `unique_name` varchar(60) CHARACTER SET utf8 NOT NULL,
  `tran_date` date DEFAULT NULL,
  `filename` varchar(60) CHARACTER SET utf8 NOT NULL,
  `filesize` varchar(60) CHARACTER SET utf8 NOT NULL,
  `filetype` varchar(60) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_bom_drawings` ###


### Structure of table `fa_book_category` ###

DROP TABLE IF EXISTS `fa_book_category`;

CREATE TABLE `fa_book_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `cat_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_book_category` ###


### Structure of table `fa_book_fine` ###

DROP TABLE IF EXISTS `fa_book_fine`;

CREATE TABLE `fa_book_fine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `based_on` int(10) NOT NULL,
  `amount` float NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_book_fine` ###


### Structure of table `fa_book_location` ###

DROP TABLE IF EXISTS `fa_book_location`;

CREATE TABLE `fa_book_location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `floor_id` varchar(100) NOT NULL,
  `fl_num` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_book_location` ###


### Structure of table `fa_book_map` ###

DROP TABLE IF EXISTS `fa_book_map`;

CREATE TABLE `fa_book_map` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(10) NOT NULL,
  `ISBN` varchar(80) NOT NULL,
  `copies_no` varchar(80) NOT NULL,
  `title` varchar(80) NOT NULL,
  `author` varchar(50) NOT NULL,
  `floor` varchar(50) NOT NULL,
  `aisel` varchar(50) NOT NULL,
  `self` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_book_map` ###


### Structure of table `fa_books` ###

DROP TABLE IF EXISTS `fa_books`;

CREATE TABLE `fa_books` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `ISBN` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `category` int(10) NOT NULL,
  `author` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `publisher` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `published_date` date NOT NULL,
  `edition` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `copies_no` int(10) NOT NULL,
  `book_cost` float NOT NULL,
  `copyright_year` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(10) NOT NULL,
  `added_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date` datetime DEFAULT NULL,
  `modified_by` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IP_address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entered_by` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_books` ###


### Structure of table `fa_books_copies` ###

DROP TABLE IF EXISTS `fa_books_copies`;

CREATE TABLE `fa_books_copies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ISBN` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `category` int(10) NOT NULL,
  `copies_no` varchar(100) NOT NULL,
  `status` int(10) NOT NULL DEFAULT '0',
  `hold` int(10) NOT NULL DEFAULT '0',
  `issue` int(10) NOT NULL DEFAULT '0',
  `damage` int(10) NOT NULL DEFAULT '0',
  `req_copy` int(50) NOT NULL DEFAULT '0',
  `map` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_books_copies` ###


### Structure of table `fa_breakdown_maintain_items` ###

DROP TABLE IF EXISTS `fa_breakdown_maintain_items`;

CREATE TABLE `fa_breakdown_maintain_items` (
  `items_id` int(11) NOT NULL AUTO_INCREMENT,
  `break_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `sub_cat_id` int(11) NOT NULL,
  `item_id` varchar(150) NOT NULL,
  `quantity` float NOT NULL,
  `stock_qty` float NOT NULL,
  PRIMARY KEY (`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_breakdown_maintain_items` ###


### Structure of table `fa_breakdown_maintenance` ###

DROP TABLE IF EXISTS `fa_breakdown_maintenance`;

CREATE TABLE `fa_breakdown_maintenance` (
  `break_id` int(11) NOT NULL AUTO_INCREMENT,
  `maintain_date` varchar(30) NOT NULL,
  `utility_id` varchar(250) NOT NULL,
  `contractor_id` int(11) NOT NULL,
  `break_st_time` text NOT NULL,
  `break_end_time` text NOT NULL,
  `ob_reason` text NOT NULL,
  `ob_1` varchar(200) NOT NULL,
  `ob_2` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `sub_cat_id` int(11) NOT NULL,
  PRIMARY KEY (`break_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_breakdown_maintenance` ###


### Structure of table `fa_breakdown_new_items` ###

DROP TABLE IF EXISTS `fa_breakdown_new_items`;

CREATE TABLE `fa_breakdown_new_items` (
  `new_items_id` int(11) NOT NULL AUTO_INCREMENT,
  `break_id` int(11) NOT NULL,
  `n_item` varchar(100) NOT NULL,
  `n_qty` float NOT NULL,
  `n_bill_date` varchar(30) NOT NULL,
  `n_billno` varchar(100) NOT NULL,
  `n_contractor` varchar(120) NOT NULL,
  `n_comments` text NOT NULL,
  PRIMARY KEY (`new_items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_breakdown_new_items` ###


### Structure of table `fa_budget_trans` ###

DROP TABLE IF EXISTS `fa_budget_trans`;

CREATE TABLE `fa_budget_trans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `amount` double NOT NULL DEFAULT '0',
  `dimension_id` int(11) DEFAULT '0',
  `dimension2_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `Account` (`account`,`tran_date`,`dimension_id`,`dimension2_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_budget_trans` ###


### Structure of table `fa_building_issues` ###

DROP TABLE IF EXISTS `fa_building_issues`;

CREATE TABLE `fa_building_issues` (
  `issue_no` int(11) NOT NULL AUTO_INCREMENT,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `loc_code` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workcentre_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`issue_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_building_issues` ###


### Structure of table `fa_carry_forward_leave` ###

DROP TABLE IF EXISTS `fa_carry_forward_leave`;

CREATE TABLE `fa_carry_forward_leave` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `updated_date` date NOT NULL,
  `no_of_cls` float NOT NULL,
  `no_of_el` float NOT NULL,
  `no_of_pls` float NOT NULL,
  `updated_date_ml` date NOT NULL,
  `updated_date_vl` date NOT NULL,
  `updated_date_el` date NOT NULL,
  `no_of_medical_ls` float NOT NULL,
  `updated_date_on` date NOT NULL,
  `empl` int(11) NOT NULL,
  `empl_id` varchar(50) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_carry_forward_leave` ###


### Structure of table `fa_cat_group` ###

DROP TABLE IF EXISTS `fa_cat_group`;

CREATE TABLE `fa_cat_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `subcat_id` int(11) NOT NULL,
  `cat_group` varchar(110) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ;

### Data of table `fa_cat_group` ###

INSERT INTO `fa_cat_group` VALUES
('1', '16', '49', 'I3'),
('2', '16', '49', 'I5'),
('3', '16', '49', 'I7');

### Structure of table `fa_chart_class` ###

DROP TABLE IF EXISTS `fa_chart_class`;

CREATE TABLE `fa_chart_class` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ctype` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_chart_class` ###


### Structure of table `fa_chart_master` ###

DROP TABLE IF EXISTS `fa_chart_master`;

CREATE TABLE `fa_chart_master` (
  `account_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `account_code2` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `account_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `account_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`account_code`),
  KEY `account_name` (`account_name`),
  KEY `accounts_by_type` (`account_type`,`account_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_chart_master` ###

INSERT INTO `fa_chart_master` VALUES
('1002', '2001', 'test account', '2', '0');

### Structure of table `fa_chart_types` ###

DROP TABLE IF EXISTS `fa_chart_types`;

CREATE TABLE `fa_chart_types` (
  `id` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `class_id` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `parent` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-1',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `class_id` (`class_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_chart_types` ###

INSERT INTO `fa_chart_types` VALUES
('9.1', 'Indirect Expenses (Recurring)', '8', '', '0'),
('5.2', 'Sundry Creditors', '3', '', '0'),
('6', 'Fixed Assets (Tangible)', '4', '', '0'),
('7.1', 'Sundry Debtors', '6', '', '0'),
('5.1', 'Suspense A/c', '3', '', '0'),
('8', 'Sales (MIsc.)', '7', '', '0'),
('3.1', 'Remuneration Paid to Employees', '11', '', '0'),
('4.1', 'Loans (Liability)', '2', '', '0'),
('9', 'Indirect Expenses (Non-recurring)', '8', '', '0'),
('6.1', 'Fixed Assets ( Intangible)', '4', '', '0'),
('2', 'Sales (Goods)', '10', '', '0'),
('1.0', 'Reserves &amp; Surplus', '1', '', '0'),
('7.2', 'Current Assets', '6', '', '0'),
('7', 'Inventory Assets', '6', '', '0'),
('1.1', 'Capital Assets', '1', '', '0'),
('5', 'Current Liabilities', '3', '', '0'),
('4', 'Long Term Liabilities', '2', '', '0'),
('1.2', 'Share Capital', '1', '', '0'),
('7.3', 'Retained Earnings', '6', '1.0', '0'),
('2.1', 'Sales (Services)', '10', '', '0'),
('8.1', 'Revenue (Misc.)', '7', '', '0'),
('3', 'Cost of Goods Sold', '11', '', '0'),
('9.2', 'General and Admin Expenses', '8', '', '0'),
('3.2', 'Costs towards Sales', '11', '', '0'),
('9.3', 'Depreciation', '8', '', '0'),
('2.2', 'Sales (Contra) Cash Discount', '10', '', '0'),
('10', 'Purchase Stocks for Sale', '9', '', '0');

### Structure of table `fa_comments` ###

DROP TABLE IF EXISTS `fa_comments`;

CREATE TABLE `fa_comments` (
  `type` int(11) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL DEFAULT '0',
  `date_` date DEFAULT '0000-00-00',
  `memo_` tinytext COLLATE utf8_unicode_ci,
  KEY `type_and_id` (`type`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_comments` ###

INSERT INTO `fa_comments` VALUES
('29', '0', '2022-11-30', 'Manufactured cpu');

### Structure of table `fa_contractor` ###

DROP TABLE IF EXISTS `fa_contractor`;

CREATE TABLE `fa_contractor` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `supp_name` varchar(60) NOT NULL,
  `supp_ref` varchar(30) NOT NULL,
  `address` tinytext NOT NULL,
  `supp_address` tinytext NOT NULL,
  `gst_no` varchar(25) NOT NULL,
  `website` varchar(100) NOT NULL,
  `bank_account` varchar(60) NOT NULL,
  `curr_code` char(3) NOT NULL,
  `payment_terms` int(11) NOT NULL,
  `tax_included` tinyint(4) NOT NULL,
  `tax_group_id` int(11) NOT NULL,
  `purchase_account` varchar(15) NOT NULL,
  `payable_account` varchar(15) NOT NULL,
  `payment_discount_account` varchar(15) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `phone2` bigint(20) NOT NULL,
  `notes` tinytext NOT NULL,
  `contact` varchar(50) NOT NULL,
  `fax` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `inactive` tinyint(4) NOT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ;

### Data of table `fa_contractor` ###

INSERT INTO `fa_contractor` VALUES
('1', 'Contractor 1', 'CN1', 'Address 1', 'Address 2', 'wqwer', '', 'dfsfsdfsdf', 'INR', '4', '1', '1', '', '1060', '1060', '9835226373', '2', '3r423', 'mohan', 'weqwe', 'newas@gmail.com', '0'),
('2', 'Yamaha Service center', 'YSC', 'Address 1', 'Address 2', '5435', '', '', 'INR', '4', '1', '1', '', '1111', '1111', '32423543425', '3453453454', 'Regular Servicing', 'WM', '', '', '0'),
('3', 'Sikandar', 'Sikandar', '', '', '', '', '', 'INR', '4', '0', '1', '', '', '', '0', '0', '', '', '', '', '0'),
('4', 'Microsoft Service', 'Sikandar fine', '', '', 'GSTSikandar', '', '', 'INR', '4', '0', '1', '', '', '', '6203516109', '2457899', '', 'Shreekant', '', '', '0');

### Structure of table `fa_cost_centre` ###

DROP TABLE IF EXISTS `fa_cost_centre`;

CREATE TABLE `fa_cost_centre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `descript` text NOT NULL,
  `inactive` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_cost_centre` ###


### Structure of table `fa_cost_centre_category` ###

DROP TABLE IF EXISTS `fa_cost_centre_category`;

CREATE TABLE `fa_cost_centre_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `inactive` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_cost_centre_category` ###


### Structure of table `fa_credit_status` ###

DROP TABLE IF EXISTS `fa_credit_status`;

CREATE TABLE `fa_credit_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reason_description` char(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dissallow_invoices` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `reason_description` (`reason_description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_credit_status` ###


### Structure of table `fa_crm_categories` ###

DROP TABLE IF EXISTS `fa_crm_categories`;

CREATE TABLE `fa_crm_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'pure technical key',
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `action` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `system` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'nonzero for core system usage',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_crm_categories` ###

INSERT INTO `fa_crm_categories` VALUES
('1', 'cust_branch', 'general', 'General', 'General contact data for customer branch (overrides company setting)', '1', '0'),
('2', 'cust_branch', 'invoice', 'Invoices', 'Invoice posting (overrides company setting)', '1', '0'),
('3', 'cust_branch', 'order', 'Orders', 'Order confirmation (overrides company setting)', '1', '0'),
('4', 'cust_branch', 'delivery', 'Deliveries', 'Delivery coordination (overrides company setting)', '1', '0'),
('5', 'customer', 'general', 'General', 'General contact data for customer', '1', '0'),
('6', 'customer', 'order', 'Orders', 'Order confirmation', '1', '0'),
('7', 'customer', 'delivery', 'Deliveries', 'Delivery coordination', '1', '0'),
('8', 'customer', 'invoice', 'Invoices', 'Invoice posting', '1', '0'),
('9', 'supplier', 'general', 'General', 'General contact data for supplier', '1', '0'),
('10', 'supplier', 'order', 'Orders', 'Order confirmation', '1', '0'),
('11', 'supplier', 'delivery', 'Deliveries', 'Delivery coordination', '1', '0'),
('12', 'supplier', 'invoice', 'Invoices', 'Invoice posting', '1', '0');

### Structure of table `fa_crm_contacts` ###

DROP TABLE IF EXISTS `fa_crm_contacts`;

CREATE TABLE `fa_crm_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL DEFAULT '0' COMMENT 'foreign key to crm_contacts',
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `action` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `entity_id` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`,`action`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_crm_contacts` ###

INSERT INTO `fa_crm_contacts` VALUES
('1', '1', 'supplier', 'general', '1'),
('3', '2', 'supplier', 'delivery', '2'),
('4', '2', 'supplier', 'general', '2'),
('5', '2', 'supplier', 'invoice', '2'),
('6', '2', 'supplier', 'order', '2'),
('7', '3', 'cust_branch', 'general', '0'),
('9', '4', 'cust_branch', 'general', '2'),
('10', '5', 'supplier', 'general', '6'),
('11', '6', 'cust_branch', 'general', '1'),
('13', '3', 'customer', 'general', '1'),
('14', '7', 'cust_branch', 'general', '2'),
('15', '7', 'customer', 'general', '2'),
('16', '8', 'supplier', 'general', '1'),
('17', '9', 'supplier', 'general', '2'),
('18', '10', 'supplier', 'general', '1'),
('20', '12', 'supplier', 'general', '3'),
('21', '11', 'supplier', 'general', '2'),
('22', '13', 'supplier', 'general', '4'),
('23', '14', 'supplier', 'general', '5'),
('24', '15', 'supplier', 'general', '6'),
('25', '16', 'supplier', 'general', '7'),
('26', '17', 'supplier', 'general', '8'),
('27', '18', 'supplier', 'general', '9'),
('28', '19', 'supplier', 'general', '10'),
('29', '20', 'supplier', 'general', '11'),
('30', '21', 'supplier', 'general', '12'),
('31', '22', 'supplier', 'general', '13'),
('32', '23', 'supplier', 'general', '14'),
('33', '24', 'supplier', 'general', '15'),
('34', '25', 'supplier', 'general', '16'),
('35', '26', 'supplier', 'general', '17'),
('36', '27', 'supplier', 'general', '18'),
('37', '28', 'supplier', 'general', '19'),
('38', '29', 'supplier', 'general', '20'),
('39', '30', 'supplier', 'general', '21'),
('40', '31', 'supplier', 'general', '22'),
('41', '32', 'supplier', 'general', '23'),
('42', '33', 'supplier', 'general', '24'),
('43', '34', 'supplier', 'general', '25'),
('44', '35', 'supplier', 'general', '26'),
('45', '36', 'supplier', 'general', '27'),
('46', '37', 'supplier', 'general', '28');

### Structure of table `fa_crm_persons` ###

DROP TABLE IF EXISTS `fa_crm_persons`;

CREATE TABLE `fa_crm_persons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `name2` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` tinytext COLLATE utf8_unicode_ci,
  `phone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` char(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ref` (`ref`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_crm_persons` ###

INSERT INTO `fa_crm_persons` VALUES
('1', 'S-one', 'Contact person', NULL, NULL, '9998777', '87755555', NULL, 'fine.com', 'en_IN', '', '0'),
('2', 'S-one', 'Supplier', NULL, NULL, '2332423', '123123123', NULL, NULL, NULL, '', '0'),
('3', 'test', 'Test ', 'user', 'patna', '9874563210', '8563214780', '+91 (44) 2222-2221', 'arya0367@gmail.com', NULL, '', '0'),
('4', 'kumar', 'kumar', NULL, 'chc chandan chandan banka', '8287161976', '8563214780', '+91 (44) 2222-2221', 'arya@gmail.com', 'en_IN', '', '0'),
('5', 'Finesse', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('6', 'tes', 'test', NULL, 'gghj gfghfh ', NULL, NULL, NULL, NULL, NULL, '', '0'),
('7', 'Ashu', 'Ashutosh Sharma', NULL, 'bailey Raoad Patna ,\nBihar\n801503', '7762972976', NULL, NULL, 'chandnisinha2011@gmail.com', NULL, '', '0'),
('8', 'Finesse', '', NULL, 'patna', '9874563210', NULL, NULL, NULL, NULL, '', '0'),
('9', 'Finesse', '', NULL, 'patna', '9874563210', NULL, NULL, NULL, NULL, '', '0'),
('10', 'SI', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('11', 'Sify', 'sify test', 'test', 'Anan Plaza, Near RBI &amp; Subhash Park South Gandhi Maidan  Road Patna ', '9334544001', NULL, NULL, NULL, NULL, '', '0'),
('12', 'Microsof', '', NULL, 'Shed No1.1 B Situated at 23/5 Delhi Mathura Road, Ballabhgarh \n', NULL, NULL, NULL, NULL, NULL, '', '0'),
('13', 'Lalita elc', '', NULL, NULL, '9973023899', NULL, NULL, NULL, NULL, '', '0'),
('14', 'IT Vision', '', NULL, NULL, '9334116887', NULL, NULL, NULL, NULL, '', '0'),
('15', '06AACCG0527D1ZB', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0'),
('16', 'Atria', '', NULL, NULL, '9176993232', NULL, NULL, NULL, NULL, '', '0'),
('17', 'AIIM', '', NULL, NULL, '8100270778', NULL, NULL, NULL, NULL, '', '0'),
('18', 'Repu', '', NULL, 'Nehru nagar ', NULL, NULL, NULL, NULL, NULL, '', '0'),
('19', 'Repu2', '', NULL, 'Hyderabad', NULL, NULL, NULL, NULL, NULL, '', '0'),
('20', 'Muskan Agencay', '', NULL, NULL, '9874563210', NULL, NULL, NULL, NULL, '', '0'),
('21', 'Amazon.in', '', NULL, NULL, '9874563210', NULL, NULL, NULL, NULL, '', '0'),
('22', 'Ayam', '', NULL, NULL, '99874563210', NULL, NULL, NULL, NULL, '', '0'),
('23', 'Shree Agencies ', '', NULL, NULL, '9874563210', NULL, NULL, NULL, NULL, '', '0'),
('24', 'Industrial Machinary &amp; Ser', '', NULL, NULL, '9874563210', NULL, NULL, NULL, NULL, '', '0'),
('25', 'Flipkart.com ', '', NULL, NULL, '9987465633210', NULL, NULL, NULL, NULL, '', '0'),
('26', 'Network Crae', '', NULL, NULL, '9874563210', NULL, NULL, NULL, NULL, '', '0'),
('27', 'Service World', '', NULL, NULL, '9874563210', NULL, NULL, NULL, NULL, '', '0'),
('28', 'Super Computer', '', NULL, NULL, '9874563210', NULL, NULL, NULL, NULL, '', '0'),
('29', 'Travel store', '', NULL, NULL, '9874563210', NULL, NULL, NULL, NULL, '', '0'),
('30', 'Maruti Battery Center', '', NULL, NULL, '9874563210', NULL, NULL, NULL, NULL, '', '0'),
('31', 'Mi.com', '', NULL, NULL, '9874563210', NULL, NULL, NULL, NULL, '', '0'),
('32', 'New Hello Mobile', '', NULL, NULL, '9874563210', NULL, NULL, NULL, NULL, '', '0'),
('33', 'Digital Equipments', '', NULL, NULL, '9874563210', NULL, NULL, NULL, NULL, '', '0'),
('34', 'Total Solution ', '', NULL, NULL, '9876543210', NULL, NULL, NULL, NULL, '', '0'),
('35', 'The Telecon', '', NULL, NULL, '987456332210', NULL, NULL, NULL, NULL, '', '0'),
('36', 'Super Fast Laptop Repair', '', NULL, NULL, '9874563210', NULL, NULL, NULL, NULL, '', '0'),
('37', 'SK ENTERPRISES', '', NULL, NULL, '9874563210', NULL, NULL, NULL, NULL, '', '0');

### Structure of table `fa_currencies` ###

DROP TABLE IF EXISTS `fa_currencies`;

CREATE TABLE `fa_currencies` (
  `currency` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `curr_abrev` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `curr_symbol` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `hundreds_name` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `auto_update` tinyint(1) NOT NULL DEFAULT '1',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`curr_abrev`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_currencies` ###

INSERT INTO `fa_currencies` VALUES
('Indian Rupees', 'INR', 'Rs', 'India', 'Paise', '0', '0'),
('US Dollars', 'USD', '$', 'United States', 'Cents', '1', '0');

### Structure of table `fa_cust_allocations` ###

DROP TABLE IF EXISTS `fa_cust_allocations`;

CREATE TABLE `fa_cust_allocations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) DEFAULT NULL,
  `amt` double unsigned DEFAULT NULL,
  `date_alloc` date NOT NULL DEFAULT '0000-00-00',
  `trans_no_from` int(11) DEFAULT NULL,
  `trans_type_from` int(11) DEFAULT NULL,
  `trans_no_to` int(11) DEFAULT NULL,
  `trans_type_to` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`,`trans_type_from`,`trans_no_from`,`trans_type_to`,`trans_no_to`),
  KEY `From` (`trans_type_from`,`trans_no_from`),
  KEY `To` (`trans_type_to`,`trans_no_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_cust_allocations` ###


### Structure of table `fa_cust_branch` ###

DROP TABLE IF EXISTS `fa_cust_branch`;

CREATE TABLE `fa_cust_branch` (
  `branch_code` int(11) NOT NULL AUTO_INCREMENT,
  `debtor_no` int(11) NOT NULL DEFAULT '0',
  `br_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `branch_ref` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `br_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `area` int(11) DEFAULT NULL,
  `salesman` int(11) NOT NULL DEFAULT '0',
  `default_location` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_group_id` int(11) DEFAULT NULL,
  `sales_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sales_discount_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `receivables_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payment_discount_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `default_ship_via` int(11) NOT NULL DEFAULT '1',
  `br_post_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `group_no` int(11) NOT NULL DEFAULT '0',
  `notes` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `bank_account` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `country` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`branch_code`,`debtor_no`),
  KEY `branch_ref` (`branch_ref`),
  KEY `group_no` (`group_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_cust_branch` ###


### Structure of table `fa_debtor_trans` ###

DROP TABLE IF EXISTS `fa_debtor_trans`;

CREATE TABLE `fa_debtor_trans` (
  `trans_no` int(11) unsigned NOT NULL DEFAULT '0',
  `type` smallint(6) unsigned NOT NULL DEFAULT '0',
  `version` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `debtor_no` int(11) unsigned NOT NULL DEFAULT '0',
  `branch_code` int(11) NOT NULL DEFAULT '-1',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tpe` int(11) NOT NULL DEFAULT '0',
  `order_` int(11) NOT NULL DEFAULT '0',
  `ov_amount` double NOT NULL DEFAULT '0',
  `ov_gst` double NOT NULL DEFAULT '0',
  `ov_freight` double NOT NULL DEFAULT '0',
  `ov_freight_tax` double NOT NULL DEFAULT '0',
  `ov_discount` double NOT NULL DEFAULT '0',
  `alloc` double NOT NULL DEFAULT '0',
  `prep_amount` double NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '1',
  `ship_via` int(11) DEFAULT NULL,
  `dimension_id` int(11) NOT NULL DEFAULT '0',
  `dimension2_id` int(11) NOT NULL DEFAULT '0',
  `payment_terms` int(11) DEFAULT NULL,
  `tax_included` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `gst` double NOT NULL,
  `gst_amt` double NOT NULL,
  `cst` double NOT NULL,
  `cst_amt` double NOT NULL,
  `ist` double NOT NULL,
  `ist_amt` double NOT NULL,
  `hsn_no` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `f_year` int(11) NOT NULL,
  PRIMARY KEY (`type`,`trans_no`,`debtor_no`),
  KEY `debtor_no` (`debtor_no`,`branch_code`),
  KEY `tran_date` (`tran_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_debtor_trans` ###


### Structure of table `fa_debtor_trans_details` ###

DROP TABLE IF EXISTS `fa_debtor_trans_details`;

CREATE TABLE `fa_debtor_trans_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `debtor_trans_no` int(11) DEFAULT NULL,
  `debtor_trans_type` int(11) DEFAULT NULL,
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` tinytext COLLATE utf8_unicode_ci,
  `unit_price` double NOT NULL DEFAULT '0',
  `unit_tax` double NOT NULL DEFAULT '0',
  `quantity` double NOT NULL DEFAULT '0',
  `discount_percent` double NOT NULL DEFAULT '0',
  `standard_cost` double NOT NULL DEFAULT '0',
  `qty_done` double NOT NULL DEFAULT '0',
  `src_id` int(11) DEFAULT NULL,
  `gst` double NOT NULL,
  `gst_amt` double NOT NULL,
  `cst` double NOT NULL,
  `cst_amt` double NOT NULL,
  `ist` double NOT NULL,
  `ist_amt` double NOT NULL,
  `hsn_no` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Transaction` (`debtor_trans_type`,`debtor_trans_no`),
  KEY `src_id` (`src_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_debtor_trans_details` ###


### Structure of table `fa_debtors_master` ###

DROP TABLE IF EXISTS `fa_debtors_master`;

CREATE TABLE `fa_debtors_master` (
  `debtor_no` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `debtor_ref` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `address` tinytext COLLATE utf8_unicode_ci,
  `tax_id` varchar(55) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `curr_code` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sales_type` int(11) NOT NULL DEFAULT '1',
  `dimension_id` int(11) NOT NULL DEFAULT '0',
  `dimension2_id` int(11) NOT NULL DEFAULT '0',
  `credit_status` int(11) NOT NULL DEFAULT '0',
  `payment_terms` int(11) DEFAULT NULL,
  `discount` double NOT NULL DEFAULT '0',
  `pymt_discount` double NOT NULL DEFAULT '0',
  `credit_limit` float NOT NULL DEFAULT '1000',
  `notes` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `country` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  PRIMARY KEY (`debtor_no`),
  UNIQUE KEY `debtor_ref` (`debtor_ref`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_debtors_master` ###


### Structure of table `fa_department` ###

DROP TABLE IF EXISTS `fa_department`;

CREATE TABLE `fa_department` (
  `dept_id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_name` tinytext NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;

### Data of table `fa_department` ###


### Structure of table `fa_department_allocation` ###

DROP TABLE IF EXISTS `fa_department_allocation`;

CREATE TABLE `fa_department_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `master_id` int(11) NOT NULL,
  `department_id` varchar(110) NOT NULL,
  `quantity` int(11) NOT NULL,
  `inactive` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `master_id` (`master_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

### Data of table `fa_department_allocation` ###

INSERT INTO `fa_department_allocation` VALUES
('1', '1', 'NETWORKING', '10', '0');

### Structure of table `fa_department_master` ###

DROP TABLE IF EXISTS `fa_department_master`;

CREATE TABLE `fa_department_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `building` int(11) NOT NULL,
  `floor` int(11) NOT NULL,
  `room` int(11) NOT NULL,
  `inactive` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `room` (`room`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

### Data of table `fa_department_master` ###

INSERT INTO `fa_department_master` VALUES
('1', '1', '1', '1', '0');

### Structure of table `fa_dept_issue_items` ###

DROP TABLE IF EXISTS `fa_dept_issue_items`;

CREATE TABLE `fa_dept_issue_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `qty_issued` double DEFAULT NULL,
  `unit_cost` double NOT NULL DEFAULT '0',
  `sl_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seat_no` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'NA',
  `seat_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_dept_issue_items` ###


### Structure of table `fa_dept_issues` ###

DROP TABLE IF EXISTS `fa_dept_issues`;

CREATE TABLE `fa_dept_issues` (
  `issue_no` int(11) NOT NULL AUTO_INCREMENT,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `loc_code` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workcentre_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`issue_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_dept_issues` ###


### Structure of table `fa_designation_master` ###

DROP TABLE IF EXISTS `fa_designation_master`;

CREATE TABLE `fa_designation_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `desig_group_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `inactive` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1 ;

### Data of table `fa_designation_master` ###

INSERT INTO `fa_designation_master` VALUES
('1', '1', 'JR. SOFTWARE ENGINEER', 'JR. SOFTWARE ENGINEER', '0'),
('2', '1', 'SR. SOFTWARE ENGINEER', 'SR. SOFTWARE ENGINEER', '0'),
('3', '3', 'PROJECT MANAGER', 'PROJECT MANAGER', '0'),
('4', '9', 'TEAM LEADER', 'TEAM LEADER', '0'),
('5', '9', 'PROJECT LEADER', 'PROJECT LEADER', '0'),
('6', '5', ' SR.UI/UX Designer', ' SR.UI/UX Designer', '0'),
('7', '5', 'JR. UI/Ux Designer', 'JR. UI/Ux Designer', '0'),
('8', '8', 'QUALITY ANALYST', 'QUALITY ANALYST', '0'),
('9', '14', ' VICE PRESIDENT', ' VICE PRESIDENT', '0'),
('10', '10', 'TECHNICAL ADMINISTRATIVE ASSIS', 'TECHNICAL ADMINISTRATIVE ASSIS', '0'),
('11', '11', ' SR.NETWORKING EXECUTIVE', ' SR.NETWORKING EXECUTIVE', '0'),
('12', '13', 'PROOF READER', 'PROOF READER', '0'),
('13', '14', ' VICE PRESIDENT', ' VICE PRESIDENT', '0'),
('15', '3', 'SITE MANAGER', 'SITE MANAGER', '0'),
('16', '3', 'SR. MANAGER  HR OPERATIONS', 'SR. MANAGER  HR OPERATIONS', '0'),
('17', '15', 'CONSULTANT', 'CONSULTANT', '0'),
('18', '3', 'SITE MANAGER', 'SITE MANAGER', '0'),
('19', '16', 'ONLINE MARKETING EXECUTIVE', 'ONLINE MARKETING EXECUTIVE', '0'),
('20', '3', 'CONTENT MANAGER -DIGITAL MARKE', 'CONTENT MANAGER -DIGITAL MARKE', '0'),
('22', '9', 'TEAM LEAD_PPC', 'TEAM LEAD_PPC', '0'),
('23', '3', 'MANAGER-FINANCE &amp; ACCOUNTS', 'MANAGER-FINANCE &amp; ACCOUNTS', '0'),
('24', '3', 'ASST.MANAGER-FINANCE &amp; ACCOUNT', 'ASST.MANAGER-FINANCE &amp; ACCOUNT', '0'),
('25', '21', 'F&amp; B Incharge', 'F&amp; B Incharge', '0'),
('26', '19', 'Custodian', 'Custodian', '0'),
('27', '20', 'Driver', 'Driver', '0'),
('28', '22', 'DIRECTOR OPERATIONS', 'DIRECTOR OPERATIONS', '0'),
('29', '8', ' SOFTWARE TEST ENGINEER', ' SOFTWARE TEST ENGINEER', '0'),
('30', '12', 'NETWORK SUPPORT', 'NETWORK SUPPORT', '0');

### Structure of table `fa_dimensions` ###

DROP TABLE IF EXISTS `fa_dimensions`;

CREATE TABLE `fa_dimensions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type_` tinyint(1) NOT NULL DEFAULT '1',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `date_` date NOT NULL DEFAULT '0000-00-00',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `date_` (`date_`),
  KEY `due_date` (`due_date`),
  KEY `type_` (`type_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_dimensions` ###


### Structure of table `fa_dispatch_management` ###

DROP TABLE IF EXISTS `fa_dispatch_management`;

CREATE TABLE `fa_dispatch_management` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_id` varchar(255) NOT NULL,
  `issue_no` varchar(255) DEFAULT NULL,
  `subject_title` varchar(255) NOT NULL,
  `dispatch_date` datetime NOT NULL,
  `person_org_name` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `pin_no` varchar(50) NOT NULL,
  `dispatch_mode` varchar(255) NOT NULL,
  `document_type` varchar(255) NOT NULL,
  `dispatched_reciept_number_if_any` varchar(255) DEFAULT NULL,
  `upload_scanned_copy` varchar(255) NOT NULL,
  `sender_person` varchar(255) NOT NULL,
  `sender_designation` varchar(255) NOT NULL,
  `sender_department` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `unique_name` varchar(255) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `contact_no` int(10) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

### Data of table `fa_dispatch_management` ###

INSERT INTO `fa_dispatch_management` VALUES
('1', 'ref-001', NULL, '', '2020-01-22 00:00:00', '', '', '', ',', '', '1479', '', '', '', NULL, '', '', '', '', '99', '', '', '', '0', '', '1');

### Structure of table `fa_dispatch_mode` ###

DROP TABLE IF EXISTS `fa_dispatch_mode`;

CREATE TABLE `fa_dispatch_mode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `discription` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_dispatch_mode` ###


### Structure of table `fa_document_type` ###

DROP TABLE IF EXISTS `fa_document_type`;

CREATE TABLE `fa_document_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_document_type` ###


### Structure of table `fa_driver_details` ###

DROP TABLE IF EXISTS `fa_driver_details`;

CREATE TABLE `fa_driver_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `father_name` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `pin_no` int(11) DEFAULT NULL,
  `phone_no` int(11) DEFAULT NULL,
  `emergency_contact` int(11) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `licence_no` varchar(50) DEFAULT NULL,
  `valid_upto` varchar(40) DEFAULT NULL,
  `aadhar_no` varchar(50) DEFAULT NULL,
  `aadhar_copy` varchar(100) NOT NULL,
  `licence_copy` varchar(100) NOT NULL,
  `profile_pic` varchar(100) NOT NULL,
  `status` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_driver_details` ###


### Structure of table `fa_employee` ###

DROP TABLE IF EXISTS `fa_employee`;

CREATE TABLE `fa_employee` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_first_name` varchar(100) DEFAULT NULL,
  `emp_last_name` varchar(100) DEFAULT NULL,
  `gender` tinyint(1) NOT NULL DEFAULT '0',
  `emp_address` tinytext,
  `emp_mobile` varchar(30) DEFAULT NULL,
  `emp_email` varchar(100) DEFAULT NULL,
  `emp_birthdate` date NOT NULL,
  `emp_notes` tinytext NOT NULL,
  `emp_hiredate` date DEFAULT NULL,
  `department_id` int(11) NOT NULL,
  `salary_scale_id` int(11) NOT NULL DEFAULT '0',
  `emp_releasedate` date DEFAULT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`emp_id`),
  KEY `salary_scale_id` (`salary_scale_id`),
  KEY `department_id` (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;

### Data of table `fa_employee` ###


### Structure of table `fa_employee_trans` ###

DROP TABLE IF EXISTS `fa_employee_trans`;

CREATE TABLE `fa_employee_trans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_no` int(11) NOT NULL DEFAULT '0',
  `payslip_no` int(11) NOT NULL,
  `pay_date` date NOT NULL,
  `to_the_order_of` varchar(255) NOT NULL,
  `pay_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;

### Data of table `fa_employee_trans` ###


### Structure of table `fa_enq_drawings` ###

DROP TABLE IF EXISTS `fa_enq_drawings`;

CREATE TABLE `fa_enq_drawings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(60) CHARACTER SET utf8 NOT NULL,
  `type_no` varchar(50) CHARACTER SET utf8 NOT NULL,
  `unique_name` varchar(60) CHARACTER SET utf8 NOT NULL,
  `tran_date` date DEFAULT NULL,
  `filename` varchar(60) CHARACTER SET utf8 NOT NULL,
  `filesize` varchar(60) CHARACTER SET utf8 NOT NULL,
  `filetype` varchar(60) CHARACTER SET utf8 NOT NULL,
  `trans_type` varchar(10) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_enq_drawings` ###


### Structure of table `fa_exchange_rates` ###

DROP TABLE IF EXISTS `fa_exchange_rates`;

CREATE TABLE `fa_exchange_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `curr_code` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `rate_buy` double NOT NULL DEFAULT '0',
  `rate_sell` double NOT NULL DEFAULT '0',
  `date_` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `curr_code` (`curr_code`,`date_`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_exchange_rates` ###

INSERT INTO `fa_exchange_rates` VALUES
('1', 'USD', '46.3052', '46.3052', '2010-02-20');

### Structure of table `fa_ext_policy` ###

DROP TABLE IF EXISTS `fa_ext_policy`;

CREATE TABLE `fa_ext_policy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_id` varchar(50) NOT NULL,
  `ext_policy` varchar(100) NOT NULL,
  `no_day` int(10) NOT NULL,
  `no_time` int(10) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 ;

### Data of table `fa_ext_policy` ###

INSERT INTO `fa_ext_policy` VALUES
('39', 'No-001', 'Staff', '10', '5', '0'),
('40', 'No-002', 'Student', '7', '2', '0');

### Structure of table `fa_fiscal_year` ###

DROP TABLE IF EXISTS `fa_fiscal_year`;

CREATE TABLE `fa_fiscal_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `begin` date DEFAULT '0000-00-00',
  `end` date DEFAULT '0000-00-00',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `begin` (`begin`),
  UNIQUE KEY `end` (`end`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_fiscal_year` ###

INSERT INTO `fa_fiscal_year` VALUES
('3', '2019-04-01', '2020-03-31', '0'),
('4', '2020-04-01', '2021-03-31', '0'),
('5', '2021-04-01', '2022-03-31', '0'),
('6', '2022-04-01', '2023-03-31', '0'),
('7', '2023-04-01', '2024-03-31', '0');

### Structure of table `fa_floor_aisle` ###

DROP TABLE IF EXISTS `fa_floor_aisle`;

CREATE TABLE `fa_floor_aisle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `floor_id` varchar(100) NOT NULL,
  `floor_aisle` varchar(50) NOT NULL,
  `aisle_desc` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_floor_aisle` ###


### Structure of table `fa_floor_issue_items` ###

DROP TABLE IF EXISTS `fa_floor_issue_items`;

CREATE TABLE `fa_floor_issue_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `qty_issued` double DEFAULT NULL,
  `unit_cost` double NOT NULL DEFAULT '0',
  `sl_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `room_no` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'NA',
  `department_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'NA',
  `seat_no` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'NA',
  `room_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_floor_issue_items` ###


### Structure of table `fa_floor_issues` ###

DROP TABLE IF EXISTS `fa_floor_issues`;

CREATE TABLE `fa_floor_issues` (
  `issue_no` int(11) NOT NULL AUTO_INCREMENT,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `loc_code` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workcentre_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`issue_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_floor_issues` ###


### Structure of table `fa_frequency_master` ###

DROP TABLE IF EXISTS `fa_frequency_master`;

CREATE TABLE `fa_frequency_master` (
  `freq_id` int(11) NOT NULL AUTO_INCREMENT,
  `frequency_name` varchar(150) NOT NULL,
  `frequency_desc` varchar(150) NOT NULL,
  `inactive` int(11) NOT NULL,
  `frequency_des` varchar(100) NOT NULL,
  PRIMARY KEY (`freq_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

### Data of table `fa_frequency_master` ###

INSERT INTO `fa_frequency_master` VALUES
('1', 'Monthly', 'Monthly', '0', '1 months'),
('2', 'Half-Yearly', 'Half-Yearly', '0', '6 months'),
('3', 'Daily', 'day to day work daily routine', '0', '1 days'),
('4', 'Every 2 Hrs', 'Every 2Hours Routine check', '0', ''),
('5', 'Quarterly', 'Quaterly', '0', '4 months'),
('6', 'Annual', 'Annual', '0', '1 year');

### Structure of table `fa_gl_trans` ###

DROP TABLE IF EXISTS `fa_gl_trans`;

CREATE TABLE `fa_gl_trans` (
  `counter` int(11) NOT NULL AUTO_INCREMENT,
  `type` smallint(6) NOT NULL DEFAULT '0',
  `type_no` int(11) NOT NULL DEFAULT '0',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `memo_` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `dimension_id` int(11) NOT NULL DEFAULT '0',
  `dimension2_id` int(11) NOT NULL DEFAULT '0',
  `person_type_id` int(11) DEFAULT NULL,
  `person_id` tinyblob,
  PRIMARY KEY (`counter`),
  KEY `Type_and_Number` (`type`,`type_no`),
  KEY `dimension_id` (`dimension_id`),
  KEY `dimension2_id` (`dimension2_id`),
  KEY `tran_date` (`tran_date`),
  KEY `account_and_tran_date` (`account`,`tran_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_gl_trans` ###


### Structure of table `fa_grn_batch` ###

DROP TABLE IF EXISTS `fa_grn_batch`;

CREATE TABLE `fa_grn_batch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL DEFAULT '0',
  `purch_order_no` int(11) DEFAULT NULL,
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `delivery_date` date NOT NULL DEFAULT '0000-00-00',
  `loc_code` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rate` double DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `delivery_date` (`delivery_date`),
  KEY `purch_order_no` (`purch_order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_grn_batch` ###

INSERT INTO `fa_grn_batch` VALUES
('1', '5', '1', '1', '2023-09-21', 'PAT', '1'),
('2', '5', '2', '2', '2023-09-21', 'PAT', '1'),
('3', '5', '4', '4', '2023-10-04', 'PAT', '1');

### Structure of table `fa_grn_items` ###

DROP TABLE IF EXISTS `fa_grn_items`;

CREATE TABLE `fa_grn_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grn_batch_id` int(11) DEFAULT NULL,
  `po_detail_item` int(11) NOT NULL DEFAULT '0',
  `item_code` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` tinytext COLLATE utf8_unicode_ci,
  `qty_recd` double NOT NULL DEFAULT '0',
  `quantity_inv` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `grn_batch_id` (`grn_batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_grn_items` ###

INSERT INTO `fa_grn_items` VALUES
('1', '1', '1', '16GBDDR3', '16 GB DDR3', '10', '0'),
('2', '2', '2', '1TBHDD', 'HDD 1TB', '10', '0'),
('3', '3', '4', '16GBDDR3', '16 GB DDR3', '16', '0');

### Structure of table `fa_grn_serial_no` ###

DROP TABLE IF EXISTS `fa_grn_serial_no`;

CREATE TABLE `fa_grn_serial_no` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grn_batch_id` int(11) NOT NULL,
  `sl_no` varchar(50) DEFAULT NULL,
  `osl_no` varchar(100) NOT NULL,
  `warranty` int(11) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `stock_id` varchar(50) NOT NULL,
  `manufactured_id` int(11) NOT NULL,
  `group_center_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1 ;

### Data of table `fa_grn_serial_no` ###

INSERT INTO `fa_grn_serial_no` VALUES
('1', '1', NULL, 'RAM16GB01', '1', '2023-09-21', '2023-09-21', '1', '16GBDDR3', '1', '0'),
('2', '1', NULL, 'RAM16GB02', '1', '2023-09-21', '2023-09-21', '1', '16GBDDR3', '2', '0'),
('3', '1', NULL, 'RAM16GB03', '1', '2023-09-21', '2023-09-21', '0', '16GBDDR3', '0', '0'),
('4', '1', NULL, 'RAM16GB04', '1', '2023-09-21', '2023-09-21', '0', '16GBDDR3', '0', '0'),
('5', '1', NULL, 'RAM16GB05', '1', '2023-09-21', '2023-09-21', '0', '16GBDDR3', '0', '0'),
('6', '1', NULL, 'RAM16GB06', '1', '2023-09-21', '2023-09-21', '0', '16GBDDR3', '0', '0'),
('7', '1', NULL, 'RAM16GB07', '1', '2023-09-21', '2023-09-21', '0', '16GBDDR3', '0', '0'),
('8', '1', NULL, 'RAM16GB08', '1', '2023-09-21', '2023-09-21', '0', '16GBDDR3', '0', '0'),
('9', '1', NULL, 'RAM16GB09', '1', '2023-09-21', '2023-09-21', '0', '16GBDDR3', '0', '0'),
('10', '1', NULL, 'RAM16GB10', '1', '2023-09-21', '2023-09-21', '0', '16GBDDR3', '0', '0'),
('11', '2', NULL, '1TBHDD01', '1', '2023-09-21', '2024-09-21', '1', '1TBHDD', '1', '0'),
('12', '2', NULL, '1TBHDD02', '1', '2023-09-21', '2024-09-21', '1', '1TBHDD', '2', '0'),
('13', '2', NULL, '1TBHDD03', '1', '2023-09-21', '2024-09-21', '0', '1TBHDD', '0', '0'),
('14', '2', NULL, '1TBHDD04', '1', '2023-09-21', '2024-09-21', '0', '1TBHDD', '0', '0'),
('15', '2', NULL, '1TBHDD05', '1', '2023-09-21', '2024-09-21', '0', '1TBHDD', '0', '0'),
('16', '2', NULL, '1TBHDD06', '1', '2023-09-21', '2024-09-21', '0', '1TBHDD', '0', '0'),
('17', '2', NULL, '1TBHDD07', '1', '2023-09-21', '2024-09-21', '0', '1TBHDD', '0', '0'),
('18', '2', NULL, '1TBHDD08', '1', '2023-09-21', '2024-09-21', '0', '1TBHDD', '0', '0'),
('19', '2', NULL, '1TBHDD09', '1', '2023-09-21', '2024-09-21', '0', '1TBHDD', '0', '0'),
('20', '2', NULL, '1TBHDD10', '1', '2023-09-21', '2024-09-21', '0', '1TBHDD', '0', '0'),
('21', '3', NULL, 'FB-CPU-65', '1', '2023-09-21', '2024-09-21', '0', 'FB-CPU-Test', '0', '0'),
('22', '4', 'A16', 'A16', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0'),
('23', '4', 'A15', 'A15', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0'),
('24', '4', 'A14', 'A14', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0'),
('25', '4', 'A13', 'A13', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0'),
('26', '4', 'A12', 'A12', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0'),
('27', '4', 'A11', 'A11', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0'),
('28', '4', 'A10', 'A10', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0'),
('29', '4', 'A9', 'A9', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0'),
('30', '4', 'A8', 'A8', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0'),
('31', '4', 'A7', 'A7', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0'),
('32', '4', 'A6', 'A6', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0'),
('33', '4', 'A5', 'A5', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0'),
('34', '4', 'A4', 'A4', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0'),
('35', '4', 'A3', 'A3', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0'),
('36', '4', 'A2', 'A2', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0'),
('37', '4', 'A1', 'A1', '0', '2023-10-04', '2023-10-04', '0', '16GBDDR3', '0', '0');

### Structure of table `fa_group` ###

DROP TABLE IF EXISTS `fa_group`;

CREATE TABLE `fa_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `assinged` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 ;

### Data of table `fa_group` ###

INSERT INTO `fa_group` VALUES
('1', 'NMP Server ', 'NMP Server ', '0'),
('2', 'Facebook RDP', 'Facebook RDP', '0'),
('3', 'Gramerly RDP', 'Gramerly RDP', '0'),
('4', 'Biometric Server', 'Biometric Server', '0'),
('5', 'Dev Antivirus/FTP Server', 'Dev Antivirus/FTP Server', '0'),
('6', 'Shivjee Prasad', 'Shivjee Prasad', '0'),
('7', 'Marketing Antivirus/Sikandar sir', 'Marketing Antivirus/Sikandar sir', '0'),
('8', 'TFS Server', 'TFS Server', '0'),
('9', 'Analyzer Server', 'Analyzer Server', '0'),
('10', 'Juhi', 'Juhi', '0'),
('11', 'Shashi Ranjan', 'Shashi Ranjan', '0'),
('12', 'Ramesh Kumar', 'Ramesh Kumar', '0'),
('13', 'Shoaib', 'Shoaib', '1'),
('14', 'Abhishek Singh Dev', 'Abhishek Singh Dev', '0'),
('15', 'Shishir', 'Shishir', '0'),
('16', 'Sidharth Designer', 'Sidharth Designer', '0'),
('17', 'Hemanth kumar', 'Hemanth kumar', '0'),
('18', 'Abhishek Narayan', 'Abhishek Narayan', '0'),
('19', 'Sumit Qa', 'Sumit Qa', '1');

### Structure of table `fa_groups` ###

DROP TABLE IF EXISTS `fa_groups`;

CREATE TABLE `fa_groups` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `description` (`description`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_groups` ###

INSERT INTO `fa_groups` VALUES
('1', 'Small', '0'),
('2', 'Medium', '0'),
('3', 'Large', '0');

### Structure of table `fa_guest_registration` ###

DROP TABLE IF EXISTS `fa_guest_registration`;

CREATE TABLE `fa_guest_registration` (
  `guest_id` int(11) NOT NULL,
  `guest_name` varchar(300) DEFAULT NULL,
  `fathers_name` varchar(300) DEFAULT NULL,
  `gender` int(11) DEFAULT NULL,
  `marital_status` int(11) DEFAULT NULL,
  `id_proof` varchar(300) DEFAULT NULL,
  `porpose` varchar(300) DEFAULT NULL,
  `line1` varchar(300) DEFAULT NULL,
  `line2` varchar(300) DEFAULT NULL,
  `city` varchar(300) DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `pin_code` int(11) DEFAULT NULL,
  `email_id` varchar(300) DEFAULT NULL,
  `contact_number` int(11) NOT NULL,
  `registraion_date` datetime NOT NULL,
  `filename` varchar(255) NOT NULL,
  `unique_name` varchar(11) NOT NULL,
  `inactive` tinyint(11) NOT NULL DEFAULT '0',
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_guest_registration` ###


### Structure of table `fa_help_desk_category` ###

DROP TABLE IF EXISTS `fa_help_desk_category`;

CREATE TABLE `fa_help_desk_category` (
  `desk_cat_id` int(11) NOT NULL,
  `category_name` varchar(80) NOT NULL,
  `inactive` int(11) NOT NULL,
  PRIMARY KEY (`desk_cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_help_desk_category` ###

INSERT INTO `fa_help_desk_category` VALUES
('1', 'Employee', '0'),
('2', 'Student', '0');

### Structure of table `fa_hold_book` ###

DROP TABLE IF EXISTS `fa_hold_book`;

CREATE TABLE `fa_hold_book` (
  `id` int(11) NOT NULL,
  `ref_id` varchar(50) NOT NULL,
  `hold_book` varchar(100) NOT NULL,
  `no_book` int(10) NOT NULL,
  `no_day` int(10) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_hold_book` ###

INSERT INTO `fa_hold_book` VALUES
('39', 'No-001', 'Staff', '5', '7', '0'),
('40', 'No-002', 'Student', '2', '3', '0');

### Structure of table `fa_item_codes` ###

DROP TABLE IF EXISTS `fa_item_codes`;

CREATE TABLE `fa_item_codes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `item_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `category_id` smallint(6) unsigned NOT NULL,
  `quantity` double NOT NULL DEFAULT '1',
  `is_foreign` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_id` (`stock_id`,`item_code`),
  KEY `item_code` (`item_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_item_codes` ###


### Structure of table `fa_item_tax_type_exemptions` ###

DROP TABLE IF EXISTS `fa_item_tax_type_exemptions`;

CREATE TABLE `fa_item_tax_type_exemptions` (
  `item_tax_type_id` int(11) NOT NULL DEFAULT '0',
  `tax_type_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_tax_type_id`,`tax_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_item_tax_type_exemptions` ###


### Structure of table `fa_item_tax_types` ###

DROP TABLE IF EXISTS `fa_item_tax_types`;

CREATE TABLE `fa_item_tax_types` (
  `id` int(11) NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `exempt` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_item_tax_types` ###

INSERT INTO `fa_item_tax_types` VALUES
('1', 'Regular', '0', '0');

### Structure of table `fa_item_units` ###

DROP TABLE IF EXISTS `fa_item_units`;

CREATE TABLE `fa_item_units` (
  `abbr` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `decimals` tinyint(2) NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`abbr`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_item_units` ###

INSERT INTO `fa_item_units` VALUES
('PC', 'Piece', '1', '0');

### Structure of table `fa_journal` ###

DROP TABLE IF EXISTS `fa_journal`;

CREATE TABLE `fa_journal` (
  `type` smallint(6) NOT NULL DEFAULT '0',
  `trans_no` int(11) NOT NULL DEFAULT '0',
  `tran_date` date DEFAULT '0000-00-00',
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `source_ref` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `event_date` date DEFAULT '0000-00-00',
  `doc_date` date NOT NULL DEFAULT '0000-00-00',
  `currency` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `amount` double NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '1',
  PRIMARY KEY (`type`,`trans_no`),
  KEY `tran_date` (`tran_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_journal` ###


### Structure of table `fa_kv_allocation_request` ###

DROP TABLE IF EXISTS `fa_kv_allocation_request`;

CREATE TABLE `fa_kv_allocation_request` (
  `allocate_id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) NOT NULL,
  `desig_group_id` int(11) NOT NULL,
  `desig_id` int(11) NOT NULL,
  `employees_id` varchar(50) NOT NULL,
  `request_date` date NOT NULL,
  `type_leave` int(11) NOT NULL,
  `reason` text NOT NULL,
  `today_date` varchar(20) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `no_of_days` float NOT NULL,
  `upload_file` text NOT NULL,
  `filesize` varchar(60) NOT NULL,
  `filetype` varchar(60) NOT NULL,
  `unique_name` varchar(60) NOT NULL,
  `no_of_days_approved` int(11) NOT NULL,
  `approved_from_date` date NOT NULL,
  `approved_to_date` date NOT NULL,
  `comments` text NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT '1',
  `updated_date` date NOT NULL,
  `inactive` int(11) NOT NULL,
  `cancel_status` tinyint(4) NOT NULL,
  `cal_year` int(11) NOT NULL,
  PRIMARY KEY (`allocate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_allocation_request` ###

INSERT INTO `fa_kv_allocation_request` VALUES
('3', '1', '1', '11', 'EMP-F-005', '2019-04-11', '1', '', '11-04-2019', '2019-04-11', '2019-04-11', '1', '', '0', '', '', '1', '2019-04-11', '2019-04-11', '', '5', '0000-00-00', '0', '1', '2019'),
('4', '1', '1', '1', 'EMP-S-002', '2019-04-11', '1', '', '11-04-2019', '2019-04-12', '2019-04-12', '1', '', '0', '', '', '1', '2019-04-12', '2019-04-12', '', '2', '0000-00-00', '0', '1', '2019'),
('6', '1', '3', '5', 'EMP-F-001', '2019-07-23', '11', '', '23-07-2019', '2019-01-14', '2019-01-14', '1', '', '0', '', '', '1', '2019-01-14', '2019-01-14', '', '2', '0000-00-00', '0', '0', '2019'),
('7', '1', '3', '5', 'EMP-F-001', '2019-07-23', '11', 'personal work', '23-07-2019', '2019-03-04', '2019-03-04', '1', '', '0', '', '', '1', '2019-03-04', '2019-03-04', '', '2', '0000-00-00', '0', '0', '2019'),
('8', '1', '3', '5', 'EMP-F-001', '2019-07-23', '11', '', '23-07-2019', '2019-04-19', '2019-04-19', '1', '', '0', '', '', '1', '2019-04-19', '2019-04-19', '', '2', '0000-00-00', '0', '0', '2019'),
('9', '1', '3', '5', 'EMP-F-001', '2019-07-23', '11', '', '23-07-2019', '2019-06-04', '2019-06-04', '1', '', '0', '', '', '1', '2019-06-04', '2019-06-04', '', '2', '0000-00-00', '0', '0', '2019'),
('10', '1', '2', '3', 'EMP-F-004', '2021-04-05', '1', '', '05-04-2021', '2021-04-05', '2021-04-05', '1', '', '', '', '', '1', '2021-04-05', '2021-04-05', '', '2', '0000-00-00', '0', '0', '2021');

### Structure of table `fa_kv_allowances` ###

DROP TABLE IF EXISTS `fa_kv_allowances`;

CREATE TABLE `fa_kv_allowances` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `percentage` float NOT NULL,
  `basic` int(11) NOT NULL DEFAULT '0',
  `Tax` int(2) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_kv_allowances` ###

INSERT INTO `fa_kv_allowances` VALUES
('1', 'Basic Pay', 'Earnings', 'Percentage', '40', '1', '0', '0'),
('2', 'Academic Grade Pay/Grade Pay', 'Earnings', 'Amount', '0', '0', '0', '1'),
('3', 'DA', 'Earnings', 'Percentage', '40', '0', '0', '1'),
('4', 'HRA', 'Earnings', 'Percentage', '40', '0', '0', '0'),
('5', 'test', 'Earnings', 'Amount', '0', '0', '0', '1'),
('6', 'SAS', 'Deductions', 'Percentage', '8.33', '0', '0', '1'),
('8', 'Conveyance ', 'Earnings', 'Amount', '0', '0', '0', '1'),
('10', 'Prof. TAX', 'Deductions', 'Amount', '0', '0', '0', '0'),
('12', 'PF', 'Deductions', 'Percentage', '12', '0', '0', '0'),
('13', 'Leave encashment', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('14', 'Perks - Free House', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('15', 'Other Perks', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('16', 'Tax on Employment u/s 16', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('17', 'Entertainment allowance u/s 16', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('18', 'Interest on NSC', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('19', 'Interest on Housing Loan (Negative)', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('20', 'Interest on Deposit (Bank/PO)', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('21', 'Income from House Property', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('22', 'Statutory Provident Fund', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('23', 'Public PF', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('24', 'LIC Direct', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('25', 'NSC', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('26', 'Int. on NSC', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('27', 'Infrastructure Bonds', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('28', 'Children&#039;s Education', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('29', 'Pension U/S 80 CCC (Jeevan Suraksha)', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('30', 'Ded. U/S 80 D (Medi-Claim)', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('31', 'Ded. U/S 80 DD (Handicapped-Dependant)', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('32', 'Ded. U/S 80DD B (Expenses on medical treatment on certain deseases for self or dependent)', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('33', 'Ded. U/S 80 G (Charitable contribution)', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('34', 'Ded. U/S 80 E  (Payment of intrest towards loan taken for higher studies for individual, spouce, children)', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('35', 'Rent Paid', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('36', 'ULIP/ LIC Dhanraksha/ LIC Home/ Mutual Fund/UTI/CTD/NSS', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('37', 'Equity Linked Savings/Other Insurance/RD/FD', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('38', 'Repayment of housing Loan', 'Tax-E', 'Amount', '0', '0', '1', '0'),
('39', 'CTC', 'Earnings', 'Amount', '0', '0', '0', '0'),
('40', 'Food Coupon', 'Earnings', 'Amount', '0', '0', '0', '0'),
('41', 'Employer&#039;s ESI', 'Earnings', 'Amount', '0', '0', '0', '0'),
('43', 'Employer&#039;s ESI', 'Deductions', 'Amount', '0', '0', '0', '0'),
('44', 'Salary Advance', 'Earnings', 'Amount', '0', '0', '0', '0'),
('45', 'Medical', 'Earnings', 'Amount', '0', '0', '0', '1'),
('46', 'Incentive', 'Earnings', 'Amount', '0', '0', '0', '0'),
('47', 'Special Allowance', 'Earnings', 'Amount', '0', '0', '0', '0'),
('48', 'ESI(Employee Cont.)', 'Deductions', 'Amount', '0', '0', '0', '1'),
('49', 'Employee ESI', 'Deductions', 'Amount', '0', '0', '0', '0'),
('50', 'Medical', 'Deductions', 'Amount', '0', '0', '0', '1'),
('51', 'Food Coupon', 'Deductions', 'Amount', '0', '0', '0', '0'),
('52', 'Employer&#039;s PF ', 'Earnings', 'Percentage', '12', '0', '0', '0'),
('53', 'testing data', 'Earnings', 'Amount', '0', '0', '0', '1');

### Structure of table `fa_kv_comp_request` ###

DROP TABLE IF EXISTS `fa_kv_comp_request`;

CREATE TABLE `fa_kv_comp_request` (
  `allocate_id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) NOT NULL,
  `desig_group_id` int(11) NOT NULL,
  `desig_id` int(11) NOT NULL,
  `employees_id` varchar(50) NOT NULL,
  `request_date` date NOT NULL,
  `type_leave` int(11) NOT NULL,
  `reason` text NOT NULL,
  `today_date` varchar(20) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `no_of_days` float NOT NULL,
  `upload_file` text NOT NULL,
  `filesize` varchar(60) NOT NULL,
  `filetype` varchar(60) NOT NULL,
  `unique_name` varchar(60) NOT NULL,
  `no_of_days_approved` int(11) NOT NULL,
  `approved_from_date` date NOT NULL,
  `approved_to_date` date NOT NULL,
  `comments` text NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT '1',
  `updated_date` date NOT NULL,
  `inactive` int(11) NOT NULL,
  `cancel_status` tinyint(4) NOT NULL,
  `cal_year` int(11) NOT NULL,
  `working_hours` varchar(10) NOT NULL,
  PRIMARY KEY (`allocate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_comp_request` ###


### Structure of table `fa_kv_countries` ###

DROP TABLE IF EXISTS `fa_kv_countries`;

CREATE TABLE `fa_kv_countries` (
  `id` int(11) NOT NULL,
  `countries_name` varchar(128) COLLATE utf8_bin NOT NULL,
  `countries_iso_code_2` varchar(2) COLLATE utf8_bin NOT NULL,
  `countries_iso_code_3` varchar(3) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ;

### Data of table `fa_kv_countries` ###

INSERT INTO `fa_kv_countries` VALUES
('1', 'Afghanistan', 'AF', 'AFG'),
('2', 'Albania', 'AL', 'ALB'),
('3', 'Algeria', 'DZ', 'DZA'),
('4', 'American Samoa', 'AS', 'ASM'),
('5', 'Andorra', 'AD', 'AND'),
('6', 'Angola', 'AO', 'AGO'),
('7', 'Anguilla', 'AI', 'AIA'),
('8', 'Antarctica', 'AQ', 'ATA'),
('9', 'Antigua and Barbuda', 'AG', 'ATG'),
('10', 'Argentina', 'AR', 'ARG'),
('11', 'Armenia', 'AM', 'ARM'),
('12', 'Aruba', 'AW', 'ABW'),
('13', 'Australia', 'AU', 'AUS'),
('14', 'Austria', 'AT', 'AUT'),
('15', 'Azerbaijan', 'AZ', 'AZE'),
('16', 'Bahamas', 'BS', 'BHS'),
('17', 'Bahrain', 'BH', 'BHR'),
('18', 'Bangladesh', 'BD', 'BGD'),
('19', 'Barbados', 'BB', 'BRB'),
('20', 'Belarus', 'BY', 'BLR'),
('21', 'Belgium', 'BE', 'BEL'),
('22', 'Belize', 'BZ', 'BLZ'),
('23', 'Benin', 'BJ', 'BEN'),
('24', 'Bermuda', 'BM', 'BMU'),
('25', 'Bhutan', 'BT', 'BTN'),
('26', 'Bolivia', 'BO', 'BOL'),
('27', 'Bosnia and Herzegowina', 'BA', 'BIH'),
('28', 'Botswana', 'BW', 'BWA'),
('29', 'Bouvet Island', 'BV', 'BVT'),
('30', 'Brazil', 'BR', 'BRA'),
('31', 'British Indian Ocean Territory', 'IO', 'IOT'),
('32', 'Brunei Darussalam', 'BN', 'BRN'),
('33', 'Bulgaria', 'BG', 'BGR'),
('34', 'Burkina Faso', 'BF', 'BFA'),
('35', 'Burundi', 'BI', 'BDI'),
('36', 'Cambodia', 'KH', 'KHM'),
('37', 'Cameroon', 'CM', 'CMR'),
('38', 'Canada', 'CA', 'CAN'),
('39', 'Cape Verde', 'CV', 'CPV'),
('40', 'Cayman Islands', 'KY', 'CYM'),
('41', 'Central African Republic', 'CF', 'CAF'),
('42', 'Chad', 'TD', 'TCD'),
('43', 'Chile', 'CL', 'CHL'),
('44', 'China', 'CN', 'CHN'),
('45', 'Christmas Island', 'CX', 'CXR'),
('46', 'Cocos (Keeling) Islands', 'CC', 'CCK'),
('47', 'Colombia', 'CO', 'COL'),
('48', 'Comoros', 'KM', 'COM'),
('49', 'Congo', 'CG', 'COG'),
('50', 'Cook Islands', 'CK', 'COK'),
('51', 'Costa Rica', 'CR', 'CRI'),
('52', 'Cote D&#039;Ivoire', 'CI', 'CIV'),
('53', 'Croatia', 'HR', 'HRV'),
('54', 'Cuba', 'CU', 'CUB'),
('55', 'Cyprus', 'CY', 'CYP'),
('56', 'Czech Republic', 'CZ', 'CZE'),
('57', 'Denmark', 'DK', 'DNK'),
('58', 'Djibouti', 'DJ', 'DJI'),
('59', 'Dominica', 'DM', 'DMA'),
('60', 'Dominican Republic', 'DO', 'DOM'),
('61', 'East Timor', 'TP', 'TMP'),
('62', 'Ecuador', 'EC', 'ECU'),
('63', 'Egypt', 'EG', 'EGY'),
('64', 'El Salvador', 'SV', 'SLV'),
('65', 'Equatorial Guinea', 'GQ', 'GNQ'),
('66', 'Eritrea', 'ER', 'ERI'),
('67', 'Estonia', 'EE', 'EST'),
('68', 'Ethiopia', 'ET', 'ETH'),
('69', 'Falkland Islands (Malvinas)', 'FK', 'FLK'),
('70', 'Faroe Islands', 'FO', 'FRO'),
('71', 'Fiji', 'FJ', 'FJI'),
('72', 'Finland', 'FI', 'FIN'),
('73', 'France', 'FR', 'FRA'),
('74', 'France, Metropolitan', 'FX', 'FXX'),
('75', 'French Guiana', 'GF', 'GUF'),
('76', 'French Polynesia', 'PF', 'PYF'),
('77', 'French Southern Territories', 'TF', 'ATF'),
('78', 'Gabon', 'GA', 'GAB'),
('79', 'Gambia', 'GM', 'GMB'),
('80', 'Georgia', 'GE', 'GEO'),
('81', 'Germany', 'DE', 'DEU'),
('82', 'Ghana', 'GH', 'GHA'),
('83', 'Gibraltar', 'GI', 'GIB'),
('84', 'Greece', 'GR', 'GRC'),
('85', 'Greenland', 'GL', 'GRL'),
('86', 'Grenada', 'GD', 'GRD'),
('87', 'Guadeloupe', 'GP', 'GLP'),
('88', 'Guam', 'GU', 'GUM'),
('89', 'Guatemala', 'GT', 'GTM'),
('90', 'Guinea', 'GN', 'GIN'),
('91', 'Guinea-bissau', 'GW', 'GNB'),
('92', 'Guyana', 'GY', 'GUY'),
('93', 'Haiti', 'HT', 'HTI'),
('94', 'Heard and Mc Donald Islands', 'HM', 'HMD'),
('95', 'Honduras', 'HN', 'HND'),
('96', 'Hong Kong', 'HK', 'HKG'),
('97', 'Hungary', 'HU', 'HUN'),
('98', 'Iceland', 'IS', 'ISL'),
('99', 'India', 'IN', 'IND'),
('100', 'Indonesia', 'ID', 'IDN'),
('101', 'Iran (Islamic Republic of)', 'IR', 'IRN'),
('102', 'Iraq', 'IQ', 'IRQ'),
('103', 'Ireland', 'IE', 'IRL'),
('104', 'Israel', 'IL', 'ISR'),
('105', 'Italy', 'IT', 'ITA'),
('106', 'Jamaica', 'JM', 'JAM'),
('107', 'Japan', 'JP', 'JPN'),
('108', 'Jordan', 'JO', 'JOR'),
('109', 'Kazakhstan', 'KZ', 'KAZ'),
('110', 'Kenya', 'KE', 'KEN'),
('111', 'Kiribati', 'KI', 'KIR'),
('112', 'North Korea', 'KP', 'PRK'),
('113', 'Korea, Republic of', 'KR', 'KOR'),
('114', 'Kuwait', 'KW', 'KWT'),
('115', 'Kyrgyzstan', 'KG', 'KGZ'),
('116', 'Lao People&#039;s Democratic Republic', 'LA', 'LAO'),
('117', 'Latvia', 'LV', 'LVA'),
('118', 'Lebanon', 'LB', 'LBN'),
('119', 'Lesotho', 'LS', 'LSO'),
('120', 'Liberia', 'LR', 'LBR'),
('121', 'Libyan Arab Jamahiriya', 'LY', 'LBY'),
('122', 'Liechtenstein', 'LI', 'LIE'),
('123', 'Lithuania', 'LT', 'LTU'),
('124', 'Luxembourg', 'LU', 'LUX'),
('125', 'Macau', 'MO', 'MAC'),
('126', 'Macedonia', 'MK', 'MKD'),
('127', 'Madagascar', 'MG', 'MDG'),
('128', 'Malawi', 'MW', 'MWI'),
('129', 'Malaysia', 'MY', 'MYS'),
('130', 'Maldives', 'MV', 'MDV'),
('131', 'Mali', 'ML', 'MLI'),
('132', 'Malta', 'MT', 'MLT'),
('133', 'Marshall Islands', 'MH', 'MHL'),
('134', 'Martinique', 'MQ', 'MTQ'),
('135', 'Mauritania', 'MR', 'MRT'),
('136', 'Mauritius', 'MU', 'MUS'),
('137', 'Mayotte', 'YT', 'MYT'),
('138', 'Mexico', 'MX', 'MEX'),
('139', 'Micronesia, Federated States of', 'FM', 'FSM'),
('140', 'Moldova, Republic of', 'MD', 'MDA'),
('141', 'Monaco', 'MC', 'MCO'),
('142', 'Mongolia', 'MN', 'MNG'),
('143', 'Montserrat', 'MS', 'MSR'),
('144', 'Morocco', 'MA', 'MAR'),
('145', 'Mozambique', 'MZ', 'MOZ'),
('146', 'Myanmar', 'MM', 'MMR'),
('147', 'Namibia', 'NA', 'NAM'),
('148', 'Nauru', 'NR', 'NRU'),
('149', 'Nepal', 'NP', 'NPL'),
('150', 'Netherlands', 'NL', 'NLD'),
('151', 'Netherlands Antilles', 'AN', 'ANT'),
('152', 'New Caledonia', 'NC', 'NCL'),
('153', 'New Zealand', 'NZ', 'NZL'),
('154', 'Nicaragua', 'NI', 'NIC'),
('155', 'Niger', 'NE', 'NER'),
('156', 'Nigeria', 'NG', 'NGA'),
('157', 'Niue', 'NU', 'NIU'),
('158', 'Norfolk Island', 'NF', 'NFK'),
('159', 'Northern Mariana Islands', 'MP', 'MNP'),
('160', 'Norway', 'NO', 'NOR'),
('161', 'Oman', 'OM', 'OMN'),
('162', 'Pakistan', 'PK', 'PAK'),
('163', 'Palau', 'PW', 'PLW'),
('164', 'Panama', 'PA', 'PAN'),
('165', 'Papua New Guinea', 'PG', 'PNG'),
('166', 'Paraguay', 'PY', 'PRY'),
('167', 'Peru', 'PE', 'PER'),
('168', 'Philippines', 'PH', 'PHL'),
('169', 'Pitcairn', 'PN', 'PCN'),
('170', 'Poland', 'PL', 'POL'),
('171', 'Portugal', 'PT', 'PRT'),
('172', 'Puerto Rico', 'PR', 'PRI'),
('173', 'Qatar', 'QA', 'QAT'),
('174', 'Reunion', 'RE', 'REU'),
('175', 'Romania', 'RO', 'ROM'),
('176', 'Russian Federation', 'RU', 'RUS'),
('177', 'Rwanda', 'RW', 'RWA'),
('178', 'Saint Kitts and Nevis', 'KN', 'KNA'),
('179', 'Saint Lucia', 'LC', 'LCA'),
('180', 'Saint Vincent and the Grenadines', 'VC', 'VCT'),
('181', 'Samoa', 'WS', 'WSM'),
('182', 'San Marino', 'SM', 'SMR'),
('183', 'Sao Tome and Principe', 'ST', 'STP'),
('184', 'Saudi Arabia', 'SA', 'SAU'),
('185', 'Senegal', 'SN', 'SEN'),
('186', 'Seychelles', 'SC', 'SYC'),
('187', 'Sierra Leone', 'SL', 'SLE'),
('188', 'Singapore', 'SG', 'SGP'),
('189', 'Slovak Republic', 'SK', 'SVK'),
('190', 'Slovenia', 'SI', 'SVN'),
('191', 'Solomon Islands', 'SB', 'SLB'),
('192', 'Somalia', 'SO', 'SOM'),
('193', 'South Africa', 'ZA', 'ZAF'),
('194', 'South Georgia &amp; South Sandwich Islands', 'GS', 'SGS'),
('195', 'Spain', 'ES', 'ESP'),
('196', 'Sri Lanka', 'LK', 'LKA'),
('197', 'St. Helena', 'SH', 'SHN'),
('198', 'St. Pierre and Miquelon', 'PM', 'SPM'),
('199', 'Sudan', 'SD', 'SDN'),
('200', 'Suriname', 'SR', 'SUR'),
('201', 'Svalbard and Jan Mayen Islands', 'SJ', 'SJM'),
('202', 'Swaziland', 'SZ', 'SWZ'),
('203', 'Sweden', 'SE', 'SWE'),
('204', 'Switzerland', 'CH', 'CHE'),
('205', 'Syrian Arab Republic', 'SY', 'SYR'),
('206', 'Taiwan', 'TW', 'TWN'),
('207', 'Tajikistan', 'TJ', 'TJK'),
('208', 'Tanzania, United Republic of', 'TZ', 'TZA'),
('209', 'Thailand', 'TH', 'THA'),
('210', 'Togo', 'TG', 'TGO'),
('211', 'Tokelau', 'TK', 'TKL'),
('212', 'Tonga', 'TO', 'TON'),
('213', 'Trinidad and Tobago', 'TT', 'TTO'),
('214', 'Tunisia', 'TN', 'TUN'),
('215', 'Turkey', 'TR', 'TUR'),
('216', 'Turkmenistan', 'TM', 'TKM'),
('217', 'Turks and Caicos Islands', 'TC', 'TCA'),
('218', 'Tuvalu', 'TV', 'TUV'),
('219', 'Uganda', 'UG', 'UGA'),
('220', 'Ukraine', 'UA', 'UKR'),
('221', 'United Arab Emirates', 'AE', 'ARE'),
('222', 'United Kingdom', 'GB', 'GBR'),
('223', 'United States', 'US', 'USA'),
('224', 'United States Minor Outlying Islands', 'UM', 'UMI'),
('225', 'Uruguay', 'UY', 'URY'),
('226', 'Uzbekistan', 'UZ', 'UZB'),
('227', 'Vanuatu', 'VU', 'VUT'),
('228', 'Vatican City State (Holy See)', 'VA', 'VAT'),
('229', 'Venezuela', 'VE', 'VEN'),
('230', 'Viet Nam', 'VN', 'VNM'),
('231', 'Virgin Islands (British)', 'VG', 'VGB'),
('232', 'Virgin Islands (U.S.)', 'VI', 'VIR'),
('233', 'Wallis and Futuna Islands', 'WF', 'WLF'),
('234', 'Western Sahara', 'EH', 'ESH'),
('235', 'Yemen', 'YE', 'YEM'),
('236', 'Yugoslavia', 'YU', 'YUG'),
('237', 'Democratic Republic of Congo', 'CD', 'COD'),
('238', 'Zambia', 'ZM', 'ZMB'),
('239', 'Zimbabwe', 'ZW', 'ZWE');

### Structure of table `fa_kv_country` ###

DROP TABLE IF EXISTS `fa_kv_country`;

CREATE TABLE `fa_kv_country` (
  `id` int(11) unsigned NOT NULL,
  `iso` varchar(50) DEFAULT NULL,
  `local_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

### Data of table `fa_kv_country` ###

INSERT INTO `fa_kv_country` VALUES
('1', 'AD', 'Andorra'),
('2', 'AE', 'United Arab Emirates'),
('3', 'AF', 'Afghanistan'),
('4', 'AG', 'Antigua and Barbuda'),
('5', 'AI', 'Anguilla'),
('6', 'AL', 'Albania'),
('7', 'AM', 'Armenia\r\n'),
('8', 'AN', 'Netherlands Antilles\r\n'),
('9', 'AO', 'Angola\r\n'),
('10', 'AQ', 'Antarctica\r\n'),
('11', 'AR', 'Argentina\r\n'),
('12', 'AS', 'American Samoa\r\n'),
('13', 'AT', 'Austria\r\n'),
('14', 'AU', 'Australia\r\n'),
('15', 'AW', 'Aruba\r\n'),
('16', 'AX', 'Aland Islands'),
('17', 'AZ', 'Azerbaijan\r\n'),
('18', 'BA', 'Bosnia and Herzegovina\r\n'),
('19', 'BB', 'Barbados\r\n'),
('20', 'BD', 'Bangladesh\r\n'),
('21', 'BE', 'Belgium\r\n'),
('22', 'BF', 'Burkina Faso\r\n'),
('23', 'BG', 'Bulgaria\r\n'),
('24', 'BH', 'Bahrain\r\n'),
('25', 'BI', 'Burundi\r\n'),
('26', 'BJ', 'Benin\r\n'),
('27', 'BL', 'Saint Barthlemy'),
('28', 'BM', 'Bermuda\r\n'),
('29', 'BN', 'Brunei Darussalam\r\n'),
('30', 'BO', 'Bolivia\r\nBolivia, Plurinational state of'),
('31', 'BR', 'Brazil\r\n'),
('32', 'BS', 'Bahamas\r\n'),
('33', 'BT', 'Bhutan\r\n'),
('34', 'BV', 'Bouvet Island\r\n'),
('35', 'BW', 'Botswana\r\n'),
('36', 'BY', 'Belarus\r\n'),
('37', 'BZ', 'Belize\r\n'),
('38', 'CA', 'Canada\r\n'),
('39', 'CC', 'Cocos (Keeling) Islands\r\n'),
('40', 'CD', 'Congo, The Democratic Republic of the\r\n'),
('41', 'CF', 'Central African Republic\r\n'),
('42', 'CG', 'Congo\r\n'),
('43', 'CH', 'Switzerland\r\n'),
('45', 'CK', 'Cook Islands\r\n'),
('46', 'CL', 'Chile'),
('47', 'CM', 'Cameroon\r\n'),
('48', 'CN', 'China\r\n'),
('49', 'CO', 'Colombia\r\n'),
('50', 'CR', 'Costa Rica\r\n'),
('51', 'CU', 'Cuba\r\n'),
('52', 'CV', 'Cape Verde\r\n'),
('53', 'CX', 'Christmas Island\r\n'),
('54', 'CY', 'Cyprus\r\n'),
('55', 'CZ', 'Czech Republic\r\n'),
('56', 'DE', 'Germany\r\n'),
('57', 'DJ', 'Djibouti\r\n'),
('58', 'DK', 'Denmark\r\n'),
('59', 'DM', 'Dominica\r\n'),
('60', 'DO', 'Dominican Republic\r\n'),
('61', 'DZ', 'Algeria\r\n'),
('62', 'EC', 'Ecuador\r\n'),
('63', 'EE', 'Estonia\r\n'),
('64', 'EG', 'Egypt\r\n'),
('65', 'EH', 'Western Sahara\r\n'),
('66', 'ER', 'Eritrea\r\n'),
('67', 'ES', 'Spain\r\n'),
('68', 'ET', 'Ethiopia\r\n'),
('69', 'FI', 'Finland\r\n'),
('70', 'FJ', 'Fiji\r\n'),
('71', 'FK', 'Falkland Islands (Malvinas)\r\n'),
('72', 'FM', 'Micronesia, Federated States of\r\n'),
('73', 'FO', 'Faroe Islands\r\n'),
('74', 'FR', 'France\r\n'),
('75', 'GA', 'Gabon'),
('76', 'GB', 'United Kingdom'),
('77', 'GD', 'Grenada'),
('78', 'GE', 'Georgia'),
('79', 'GF', 'French Guiana'),
('80', 'GG', 'Guernsey'),
('81', 'GH', 'Ghana\r\n'),
('82', 'GI', 'Gibraltar\r\n'),
('83', 'GL', 'Greenland\r\n'),
('84', 'GM', 'Gambia\r\n'),
('85', 'GN', 'Guinea\r\n'),
('86', 'GP', 'Guadeloupe\r\n'),
('87', 'GQ', 'Equatorial Guinea\r\n'),
('88', 'GR', 'Greece\r\n'),
('89', 'GS', 'South Georgia and the South Sandwich Islands\r\n'),
('90', 'GT', 'Guatemala\r\n'),
('91', 'GU', 'Guam\r\n'),
('92', 'GW', 'Guinea-Bissau\r\n'),
('93', 'GY', 'Guyana\r\n'),
('94', 'HK', 'Hong Kong\r\n'),
('95', 'HM', 'Heard Island and McDonald Islands\r\n'),
('96', 'HN', 'Honduras\r\n'),
('97', 'HR', 'Croatia\r\n'),
('98', 'HT', 'Haiti\r\n'),
('99', 'HU', 'Hungary\r\n'),
('100', 'ID', 'Indonesia\r\n'),
('101', 'IE', 'Ireland\r\n'),
('102', 'IL', 'Israel\r\n'),
('103', 'IM', 'Isle of Man\r\n'),
('104', 'IN', 'India\r\n'),
('105', 'IO', 'British Indian Ocean Territory\r\n'),
('106', 'IQ', 'Iraq\r\n'),
('107', 'IR', 'Iran, Islamic Republic of\r\n'),
('108', 'IS', 'Iceland\r\n'),
('109', 'IT', 'Italy'),
('110', 'JE', 'Jersey\r\n'),
('111', 'JM', 'Jamaica\r\n'),
('112', 'JO', 'Jordan\r\n'),
('113', 'JP', 'Japan\r\n'),
('114', 'KE', 'Kenya\r\n'),
('115', 'KG', 'Kyrgyzstan\r\n'),
('116', 'KH', 'Cambodia\r\n'),
('117', 'KI', 'Kiribati\r\n'),
('118', 'KM', 'Comoros\r\n'),
('119', 'KN', 'Saint Kitts and Nevis\r\n'),
('120', 'KP', 'Korea, Democratic People&#039;s Republic of\r\n'),
('121', 'KR', 'Korea, Republic of\r\n'),
('122', 'KW', 'Kuwait\r\n'),
('123', 'KY', 'Cayman Islands\r\n'),
('124', 'KZ', 'Kazakhstan\r\n'),
('125', 'LA', 'Lao People&#039;s Democratic Republic\r\n'),
('126', 'LB', 'Lebanon\r\n'),
('127', 'LC', 'Saint Lucia\r\n'),
('128', 'LI', 'Liechtenstein\r\n'),
('129', 'LK', 'Sri Lanka\r\n'),
('130', 'LR', 'Liberia\r\n'),
('131', 'LS', 'Lesotho\r\n'),
('132', 'LT', 'Lithuania\r\n'),
('133', 'LU', 'Luxembourg\r\n'),
('134', 'LV', 'Latvia\r\n'),
('135', 'LY', 'Libyan Arab Jamahiriya\r\n'),
('136', 'MA', 'Morocco\r\n'),
('137', 'MC', 'Monaco\r\n'),
('138', 'MD', 'Moldova, Republic of\r\n'),
('139', 'ME', 'Montenegro\r\n'),
('140', 'MF', 'Saint Martin'),
('141', 'MG', 'Madagascar\r\n'),
('142', 'MH', 'Marshall Islands\r\n'),
('143', 'MK', 'Macedonia\r\n'),
('144', 'ML', 'Mali\r\n'),
('145', 'MM', 'Myanmar\r\n'),
('146', 'MN', 'Mongolia\r\n'),
('147', 'MO', 'Macao\r\n'),
('148', 'MP', 'Northern Mariana Islands\r\n'),
('149', 'MQ', 'Martinique\r\n'),
('150', 'MR', 'Mauritania\r\n'),
('151', 'MS', 'Montserrat\r\n'),
('152', 'MT', 'Malta\r\n'),
('153', 'MU', 'Mauritius\r\n'),
('154', 'MV', 'Maldives\r\n'),
('155', 'MW', 'Malawi\r\n'),
('156', 'MX', 'Mexico\r\n'),
('157', 'MY', 'Malaysia\r\n'),
('158', 'MZ', 'Mozambique\r\n'),
('159', 'NA', 'Namibia\r\n'),
('160', 'NC', 'New Caledonia\r\n'),
('161', 'NE', 'Niger\r\n'),
('162', 'NF', 'Norfolk Island\r\n'),
('163', 'NG', 'Nigeria\r\n'),
('164', 'NI', 'Nicaragua\r\n'),
('165', 'NL', 'Netherlands\r\n'),
('166', 'NO', 'Norway'),
('167', 'NP', 'Nepal\r\n'),
('168', 'NR', 'Nauru\r\n'),
('169', 'NU', 'Niue\r\n'),
('170', 'NZ', 'New Zealand\r\n'),
('171', 'OM', 'Oman\r\n'),
('172', 'PA', 'Panama\r\n'),
('173', 'PE', 'Peru\r\n'),
('174', 'PF', 'French Polynesia\r\n'),
('175', 'PG', 'Papua New Guinea\r\n'),
('176', 'PH', 'Philippines\r\n'),
('177', 'PK', 'Pakistan\r\n'),
('178', 'PL', 'Poland\r\n'),
('179', 'PM', 'Saint Pierre and Miquelon\r\n'),
('180', 'PN', 'Pitcairn\r\n'),
('181', 'PR', 'Puerto Rico\r\n'),
('182', 'PS', 'Palestinian Territory, Occupied'),
('183', 'PT', 'Portugal\r\n'),
('184', 'PW', 'Palau\r\n'),
('185', 'PY', 'Paraguay\r\n'),
('186', 'QA', 'Qatar\r\n'),
('188', 'RO', 'Romania\r\n'),
('189', 'RS', 'Serbia\r\n'),
('190', 'RU', 'Russian Federation\r\n'),
('191', 'RW', 'Rwanda\r\n'),
('192', 'SA', 'Saudi Arabia\r\n'),
('193', 'SB', 'Solomon Islands\r\n'),
('194', 'SC', 'Seychelles\r\n'),
('195', 'SD', 'Sudan\r\n'),
('196', 'SE', 'Sweden\r\n'),
('197', 'SG', 'Singapore\r\n'),
('198', 'SH', 'Saint Helena\r\n'),
('199', 'SI', 'Slovenia\r\n'),
('200', 'SJ', 'Svalbard and Jan Mayen\r\n'),
('201', 'SK', 'Slovakia\r\n'),
('202', 'SL', 'Sierra Leone\r\n'),
('203', 'SM', 'San Marino\r\n'),
('204', 'SN', 'Senegal\r\n'),
('205', 'SO', 'Somalia\r\n'),
('206', 'SR', 'Suriname\r\n'),
('207', 'ST', 'Sao Tome and Principe\r\n'),
('208', 'SV', 'El Salvador\r\n'),
('209', 'SY', 'Syrian Arab Republic\r\n'),
('210', 'SZ', 'Swaziland\r\n'),
('211', 'TC', 'Turks and Caicos Islands\r\n'),
('212', 'TD', 'Chad'),
('213', 'TF', 'French Southern Territories'),
('214', 'TG', 'Togo'),
('215', 'TH', 'Thailand'),
('216', 'TJ', 'Tajikistan'),
('217', 'TK', 'Tokelau'),
('218', 'TL', 'Timor-Leste'),
('219', 'TM', 'Turkmenistan\r\n'),
('220', 'TN', 'Tunisia\r\n'),
('221', 'TO', 'Tonga\r\n'),
('222', 'TR', 'Turkey'),
('223', 'TT', 'Trinidad and Tobago\r\n'),
('224', 'TV', 'Tuvalu\r\n'),
('225', 'TW', 'Taiwan\r\n'),
('226', 'TZ', 'Tanzania, United Republic of\r\n'),
('227', 'UA', 'Ukraine\r\n'),
('228', 'UG', 'Uganda\r\n'),
('229', 'UM', 'United States Minor Outlying Islands\r\n'),
('230', 'US', 'United States\r\n'),
('231', 'UY', 'Uruguay\r\n'),
('232', 'UZ', 'Uzbekistan\r\n'),
('233', 'VA', 'Holy See (Vatican City State)\r\n'),
('234', 'VC', 'Saint Vincent and the Grenadines\r\n'),
('235', 'VE', 'Venezuela, Bolivarian Republic of'),
('236', 'VG', 'Virgin Islands, British\r\n'),
('237', 'VI', 'Virgin Islands, U.S.\r\n'),
('238', 'VN', 'Viet Nam'),
('239', 'VU', 'Vanuatu\r\n'),
('240', 'WF', 'Wallis and Futuna\r\n'),
('241', 'WS', 'Samoa\r\n'),
('242', 'YE', 'Yemen\r\n'),
('243', 'YT', 'Mayotte\r\n'),
('244', 'ZA', 'South Africa\r\n'),
('245', 'ZM', 'Zambia\r\n'),
('246', 'ZW', 'Zimbabwe');

### Structure of table `fa_kv_departments` ###

DROP TABLE IF EXISTS `fa_kv_departments`;

CREATE TABLE `fa_kv_departments` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(60) NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_departments` ###

INSERT INTO `fa_kv_departments` VALUES
('1', 'ADMIN', '0'),
('2', 'DEVELOPMENT', '0'),
('3', 'Marketing', '0'),
('4', 'HR ADMIN', '0'),
('5', 'ANSAFONE', '0'),
('6', 'NETWORKING', '0'),
('7', 'TRANSCRIPTION', '0'),
('8', 'WEB MARKETING', '0'),
('9', 'MANAGER-FINANCE &amp; ACCOUNTS', '0'),
('10', 'MANAGER FINANCE', '0'),
('11', 'ADMIN SUPPORT', '0'),
('12', 'INCHARGE F-B', '0'),
('13', 'HOUSE-KEEPING STAFF', '0'),
('14', 'DRIVER', '0'),
('15', 'Designer', '0'),
('16', 'QA Room', '0');

### Structure of table `fa_kv_desig_group` ###

DROP TABLE IF EXISTS `fa_kv_desig_group`;

CREATE TABLE `fa_kv_desig_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `inactive` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_desig_group` ###

INSERT INTO `fa_kv_desig_group` VALUES
('1', 'SOFTWARE ENGINEER', 'SOFTWARE ENGINEER', '0'),
('2', 'App Developer', 'Mobile App Development', '0'),
('3', 'Manager', 'Manager', '0'),
('4', 'Intern', 'Intern', '0'),
('5', 'Designer', 'Designer', '0'),
('7', 'Web Developer', 'Senior Developer', '0'),
('8', 'QA', 'Testing ', '0'),
('9', 'TEAM LEADER', 'TEAM LEADER', '0'),
('10', 'TECHNICAL ADMINISTRATIVE', 'TECHNICAL ADMINISTRATIVE', '0'),
('11', 'NETWORKING EXECUTIVE', 'NETWORKING EXECUTIVE', '0'),
('12', 'NETWORK SUPPORT', 'NETWORK SUPPORT', '0'),
('13', 'PROOF READER', 'PROOF READER', '0'),
('14', 'PRESIDENT', 'PRESIDENT', '0'),
('15', 'CONSULTANT', 'CONSULTANT', '0'),
('16', 'MARKETING EXECUTIVE', 'MARKETING EXECUTIVE', '0'),
('18', 'Transcription', 'Transcription', '0'),
('19', 'Custodian', 'Custodian', '0'),
('20', 'Driver', 'Driver', '0'),
('21', 'FB Incharge', 'FB Incharge', '0'),
('22', 'ADMIN', 'ADMIN', '0');

### Structure of table `fa_kv_empl_attendancee` ###

DROP TABLE IF EXISTS `fa_kv_empl_attendancee`;

CREATE TABLE `fa_kv_empl_attendancee` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `month` int(2) DEFAULT NULL,
  `year` int(2) DEFAULT NULL,
  `dept_id` int(10) NOT NULL,
  `empl_id` varchar(30) DEFAULT NULL,
  `1` varchar(5) NOT NULL,
  `2` varchar(5) NOT NULL,
  `3` varchar(5) NOT NULL,
  `4` varchar(5) NOT NULL,
  `5` varchar(5) NOT NULL,
  `6` varchar(5) NOT NULL,
  `7` varchar(5) NOT NULL,
  `8` varchar(5) NOT NULL,
  `9` varchar(5) NOT NULL,
  `10` varchar(5) NOT NULL,
  `11` varchar(5) NOT NULL,
  `12` varchar(5) NOT NULL,
  `13` varchar(5) NOT NULL,
  `14` varchar(5) NOT NULL,
  `15` varchar(5) NOT NULL,
  `16` varchar(5) NOT NULL,
  `17` varchar(5) NOT NULL,
  `18` varchar(5) NOT NULL,
  `19` varchar(5) NOT NULL,
  `20` varchar(5) NOT NULL,
  `21` varchar(5) NOT NULL,
  `22` varchar(5) NOT NULL,
  `23` varchar(5) NOT NULL,
  `24` varchar(5) NOT NULL,
  `25` varchar(5) NOT NULL,
  `26` varchar(5) NOT NULL,
  `27` varchar(5) NOT NULL,
  `28` varchar(5) NOT NULL,
  `29` varchar(5) NOT NULL,
  `30` varchar(5) NOT NULL,
  `31` varchar(5) NOT NULL,
  `cal_year` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

### Data of table `fa_kv_empl_attendancee` ###


### Structure of table `fa_kv_empl_cv` ###

DROP TABLE IF EXISTS `fa_kv_empl_cv`;

CREATE TABLE `fa_kv_empl_cv` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `empl_id` varchar(10) NOT NULL,
  `empl_firstname` varchar(60) NOT NULL,
  `cv_title` varchar(60) NOT NULL,
  `filename` varchar(60) NOT NULL,
  `unique_name` varchar(60) NOT NULL,
  `uploaded_date` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `f_year` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_empl_cv` ###


### Structure of table `fa_kv_empl_degree` ###

DROP TABLE IF EXISTS `fa_kv_empl_degree`;

CREATE TABLE `fa_kv_empl_degree` (
  `id` int(10) NOT NULL,
  `empl_id` varchar(10) NOT NULL,
  `degree` varchar(20) NOT NULL,
  `major` varchar(20) NOT NULL,
  `university` varchar(80) NOT NULL,
  `grade` varchar(20) NOT NULL,
  `year` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_empl_degree` ###


### Structure of table `fa_kv_empl_experience` ###

DROP TABLE IF EXISTS `fa_kv_empl_experience`;

CREATE TABLE `fa_kv_empl_experience` (
  `id` int(10) NOT NULL,
  `empl_id` varchar(10) NOT NULL,
  `organization` varchar(60) NOT NULL,
  `job_role` varchar(60) NOT NULL,
  `job_position` varchar(120) NOT NULL,
  `nature_of_work` varchar(120) NOT NULL,
  `type_employment` varchar(120) NOT NULL,
  `monthly_sal` varchar(100) NOT NULL,
  `s_date` date NOT NULL,
  `e_date` date NOT NULL,
  `experience` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_empl_experience` ###


### Structure of table `fa_kv_empl_info` ###

DROP TABLE IF EXISTS `fa_kv_empl_info`;

CREATE TABLE `fa_kv_empl_info` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `empl_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `empl_salutation` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `salutation_text` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `empl_firstname` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `empl_middlename` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `empl_lastname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `addr_line1` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `addr_line2` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `correspondence_address` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `permanent_address` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `same_as_correspond_address` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `empl_city` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `empl_state` int(11) NOT NULL,
  `pincode` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `country` int(5) NOT NULL,
  `gender` int(2) NOT NULL,
  `date_of_birth` date NOT NULL,
  `age` int(3) NOT NULL,
  `marital_status` int(2) NOT NULL,
  `office_phone` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `home_phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `mobile_phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(2) NOT NULL,
  `empl_pic` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '...',
  `pf_number` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `pan_no` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `aadhaar_no` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `esi_no` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `pran_no` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `per_addr_line1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `per_addr_line2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `empl_per_city` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `per_country` int(11) NOT NULL,
  `empl_per_state` int(11) NOT NULL,
  `per_pincode` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `no_of_children` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `eligible_hra` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_kv_empl_info` ###

INSERT INTO `fa_kv_empl_info` VALUES
('2', 'EMP-F-001', '1', '', 'PRABHAT', '', 'PRASAD', 'Hyderabad', 'Hyderabad', '', '', '1', 'Hyderabad', '2053', '', '99', '1', '0000-00-00', '0', '1', NULL, '9874563210', '9874563210', 'PRABHAT@gmail.com', '1', '', '', 'AUZPP9956H', '236314867306', '', '', 'Hyderabad', 'Hyderabad', 'Hyderabad', '99', '2053', '', '', NULL),
('3', 'EMP-F-002', '', '', 'VISHNUVARDHAN CHOLKAR', '', '', 'Hyderabad', 'Hyderabad', '', '', '', 'Hyderabad', '2053', '', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'VISHNUVARDHAN@gmail.com', '1', '', '', 'AHTPC0766F', '', '', '', '', '', '', '0', '0', '', '', NULL),
('4', 'EMP-F-162', '', '', 'KODIMYALA SAINATH BABU', '', '', 'Hyderabad', 'Hyderabad', '', '', '', 'Hyderabad', '2053', '', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'KODIMYALA@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('5', 'EMP-F-225', '', '', 'CHIGURLA SAI KIRAN', '', '', 'Hyderabad', 'Hyderabad', '', '', '', 'Hyderabad', '2053', '', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'CHIGURLA@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('6', 'EMP-F-005', '', '', 'MOHAMMED ABDUL AZIZ', '', '', 'Hyderabad', 'Hyderabad', '', '', '', 'Hyderabad', '2053', '', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'MOHAMMED@gmail.com', '1', '', '', 'AKMPM9035H', '519593454792', '', '', '', '', '', '0', '0', '', '', NULL),
('7', 'EMP-F-006', '', '', 'NEELAM NAVEEN', '', '', 'Hyderabad', 'Hyderabad', '', '', '', 'Hyderabad', '2053', '', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'NEELAM@gmail.com', '1', '', '', 'AMIPN5422H', '938977712802', '', '', '', '', '', '0', '0', '', '', NULL),
('8', 'EMP-F-008', '', '', 'SURAJ KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SURAJ@gmail.com', '1', '', '', 'BKHPK8943E', '445117811308', '', '', '', '', '', '0', '0', '', '', NULL),
('9', 'EMP-F-009', '', '', 'VISHAL ANURAG', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'VISHAL@gmail.com', '1', '', '', 'ARIPA8547K', '765826193839', '', '', '', '', '', '0', '0', '', '', NULL),
('10', 'EMP-F-010', '', '', 'SONU SHARMA', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SONU@gmail.com', '1', '', '', 'EAHPS9438B', '638650935581', '', '', '', '', '', '0', '0', '', '', NULL),
('11', 'EMP-F-014', '', '', 'SUMIT VERMA', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SUMIT@gmail.com', '1', '', '', 'ANVPV0320N', '952497917671', '', '', '', '', '', '0', '0', '', '', NULL),
('12', 'EMP-F-022', '', '', 'VIVEK KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'VIVEK@gmail.com', '1', '', '', 'EHYPK9921D', '', '', '', '', '', '', '0', '0', '', '', NULL),
('13', 'EMP-F-025', '', '', 'ASHISH ANAND', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ASHISH@gmail.com', '1', '', '', 'APSPA6381D', '', '', '', '', '', '', '0', '0', '', '', NULL),
('14', 'EMP-F-075', '', '', 'AMARJEET KUMAR SUDHANSOO', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'AMARJEET@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('15', 'EMP-F-077', '', '', 'CHANCHAL KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'CHANCHAL@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('16', 'EMP-F-078', '', '', 'SHISHIR KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SHISHIR@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('17', 'EMP-F-085', '', '', 'RAJ KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'RAJ@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('18', 'EMP-F-094', '', '', 'SAURABH SHEKHAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SAURABH@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('19', 'EMP-F-111', '', '', 'SIDHARTH KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SIDHARTH@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('20', 'EMP-F-114', '', '', 'ABHISHEK KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ABHISHEK@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('21', 'EMP-F-126', '', '', 'SUMIT KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SUMIT@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('22', 'EMP-F-136', '', '', 'NITISH KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'NITISH@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('23', 'EMP-F-150', '', '', 'RAMESH KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'RAMESH@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('24', 'EMP-F-152', '', '', 'ABHISHEK NARAYAN', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ABHISHEK@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('25', 'EMP-F-161', '', '', 'SAKSHI PRIYA', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SAKSHI@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('26', 'EMP-F-163', '', '', 'ROHIT KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ROHIT@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('27', 'EMP-F-164', '', '', 'MD SALEH ASHARAF', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ASHARAF@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('28', 'EMP-F-166', '', '', 'ACHALANAND JHA', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ACHALANAND@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('29', 'EMP-F-168', '', '', 'CHANDAN KUMAR GUPTA', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'CHANDAN@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('30', 'EMP-F-169', '', '', 'MD SADIQUE HUSSAIN', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'HUSSAIN@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('31', 'EMP-F-175', '', '', 'JUHI AFREEN', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'JUHI@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('32', 'EMP-F-177', '', '', 'SONAM RAJ', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SONAM@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('33', 'EMP-F-179', '', '', 'GULAB PRASAD', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'GULAB@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('34', 'EMP-F-180', '', '', 'SHASHI RANJAN KUMAR SINGH', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SHASHI@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('35', 'EMP-F-185', '', '', 'VIKASH KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'VIKASH@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('36', 'EMP-F-186', '', '', 'LOKNAYAK BHARTI', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'LOKNAYAK@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('37', 'EMP-F-187', '', '', 'MOHAMMAD TAUSEEF', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'MOHAMMAD@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('38', 'EMP-F-190', '', '', 'HEMANT SRIVASTAVA', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'HEMANT@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('39', 'EMP-F-196', '', '', 'MD SOAIB ANSARI', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ANSARI@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('40', 'EMP-F-201', '', '', 'NIRANJAN KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'NIRANJAN@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('41', 'EMP-F-204', '', '', 'ADITYA ABHIRAM', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ADITYA@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('42', 'EMP-F-208', '', '', 'NAVNIT KUMAR RAI', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'NAVNIT@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('43', 'EMP-F-211', '', '', 'AVINASH KUMAR.', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'AVINASH@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('44', 'EMP-F-219', '', '', 'KUNAL SINGH', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'KUNAL@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('45', 'EMP-F-027', '', '', 'MD SIKANDAR AHMED', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SIKANDAR@gmail.com', '1', '', '', 'AKPPA5637E', '', '', '', '', '', '', '0', '0', '', '', NULL),
('46', 'EMP-F-100', '', '', 'SHIVJEE PRASAD', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SHIVJEE@gmail.com', '1', '', '', 'CKGPP2028B', '', '', '', '', '', '', '0', '0', '', '', NULL),
('47', 'EMP-F-029', '', '', 'RAJESH KUMAR SINHA', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'RAJESH@gmail.com', '1', '', '', 'BDSPS7514M', '', '', '', '', '', '', '0', '0', '', '', NULL),
('48', 'EMP-F-030', '', '', 'MAHESH KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'MAHESH@gmail.com', '1', '', '', 'AVTPK2338K', '', '', '', '', '', '', '0', '0', '', '', NULL),
('49', 'EMP-F-035', '', '', 'ANKESH KUMAR SRIVASTAVA', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ANKESH@gmail.com', '1', '', '', 'FGKPS4113M', '', '', '', '', '', '', '0', '0', '', '', NULL),
('50', 'EMP-F-036', '', '', 'AMIT RANJAN', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'AMIT@gmail.com', '1', '', '', 'BQFPR4276P', '', '', '', '', '', '', '0', '0', '', '', NULL),
('51', 'EMP-F-037', '', '', 'PRAVIN KUMAR SINGH', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'PRAVIN@gmail.com', '1', '', '', 'BJWPS6684Q', '', '', '', '', '', '', '0', '0', '', '', NULL),
('52', 'EMP-F-040', '', '', 'SANGEETA KUMAR', '', '', ' Bengaluru', ' Bengaluru', '', '', '', ' Bengaluru', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SANGEETA@gmail.com', '1', '', '', 'ARJPK0931C', '', '', '', '', '', '', '0', '0', '', '', NULL),
('53', 'EMP-F-041', '', '', 'ABHAY KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ABHAY@gmail.com', '1', '', '', 'DMSPK4281G', '', '', '', '', '', '', '0', '0', '', '', NULL),
('54', 'EMP-F-046', '', '', 'RAHUL ANAND', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'RAHUL@gmail.com', '1', '', '', 'BFMPA0533C', '', '', '', '', '', '', '0', '0', '', '', NULL),
('55', 'EMP-F-047', '', '', 'AVINASH KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'AVINASH@gmail.com', '1', '', '', 'CHUPK3773K', '', '', '', '', '', '', '0', '0', '', '', NULL),
('56', 'EMP-F-050', '', '', 'SHASHANK SHEKHER', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SHASHANK@gmail.com', '1', '', '', 'CHFPS7910D', '', '', '', '', '', '', '0', '0', '', '', NULL),
('57', 'EMP-F-086', '1', '', 'RAM THAKUR', '', '', 'Patna', 'Patna', '', '', '1', 'Patna', '1479', '800013', '99', '1', '0000-00-00', '0', '1', NULL, '', '9874563210', 'RAM@gmail.com', '1', '', '', '', '', '', '', 'Patna', 'Patna', 'Patna', '99', '1479', '800013', '', NULL),
('58', 'EMP-F-096', '', '', 'VIPUL KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'VIPUL@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('59', 'EMP-F-102', '', '', 'VISHAL KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'VISHAL@gmail.com', '1', '', '', '', '254470243402', '', '', '', '', '', '0', '0', '', '', NULL),
('60', 'EMP-F-108', '', '', 'PARUL PRASHUN', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'PARUL@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('61', 'EMP-F-128', '', '', 'KUMARI KIRTI BALA', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'KUMARI@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('62', 'EMP-F-120', '', '', 'POONAM KUMARI', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'POONAM@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('63', 'EMP-F-131', '', '', 'NAYAN PRAKASH', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'NAYAN@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('64', 'EMP-F-130', '', '', 'ASHISH KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ASHISH@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('65', 'EMP-F-149', '', '', 'SANY SUSANNA SAJU', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SANY@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('66', 'EMP-F-153', '', '', 'RAKESH NANDAN', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'RAKESH@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('67', 'EMP-F-156', '', '', 'NITESH PATEL', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'NITESH@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('68', 'EMP-F-167', '', '', 'ANAMIKA KUMARI', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ANAMIKA@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('69', 'EMP-F-173', '', '', 'RIYA RANI', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'RIYA@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('70', 'EMP-F-178', '', '', 'ABHINAV KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ABHINAV@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('71', 'EMP-F-182', '', '', 'AKANKSHA KUMARI', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'AKANKSHA@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('72', 'EMP-F-188', '', '', 'RATNESH KUMAR SINHA', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'RATNESH@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('73', 'EMP-F-192', '', '', 'KUMAR ANKIT', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'KUMAR@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('74', 'EMP-F-194', '', '', 'KUMAR ROHAN', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'KUMAR@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('75', 'EMP-F-197', '', '', 'TARANNUM FATMA', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'TARANNUM@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('76', 'EMP-F-198', '', '', 'HARENDRA KUMAR CHANDAN', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'HARENDRA@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('77', 'EMP-F-199', '', '', 'ANANYA SINGH', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ANANYA@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('78', 'EMP-F-202', '', '', 'NISHA KUMARI', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'NISHA@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('79', 'EMP-F-203', '', '', 'SHUBHAM RAJ', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SHUBHAM@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('80', 'EMP-F-206', '', '', 'RITU KUMARI', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'RITU@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('81', 'EMP-F-207', '', '', 'MOHAMMAD AMAN QUADRI', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'MOHAMMAD@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('82', 'EMP-F-215', '', '', 'RAHUL RAVI', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'RAHUL@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('83', 'EMP-F-220', '', '', 'SHASHANK SAMDARSHI', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SHASHANK@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('84', 'EMP-F-221', '', '', 'AMIT RANJAN.', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'AMIT@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('85', 'EMP-F-222', '', '', 'BHAWANA SINGH', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'BHAWANA@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('86', 'EMP-F-223', '', '', 'DEEPAK KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'DEEPAK@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('87', 'EMP-F-224', '', '', 'RAHUL', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'RAHUL@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('88', 'EMP-F-226', '', '', 'SOMIYA KUMAR', '', '', '', '', '', '', '', '', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SOMIYA@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('89', 'EMP-F-227', '', '', 'ANAND RAJ', '', '', '', '', '', '', '', '', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ANAND@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('90', 'EMP-F-061', '', '', 'SHREEKANT', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SHREEKANT@gmail.com', '1', '', '', 'AKDPK6648R', '', '', '', '', '', '', '0', '0', '', '', NULL),
('91', 'EMP-F-013', '', '', 'SUYASH', '', '', 'Mumbai', 'Mumbai', '', '', '', 'Mumbai', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SUYASH@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('92', 'EMP-F-062', '', '', 'BINOD PRASAD', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'BINOD@gmail.com', '1', '', '', 'CBBPP4314A', '', '', '', '', '', '', '0', '0', '', '', NULL),
('93', 'EMP-F-063', '', '', 'BIMLESH KUMAR SINGH', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'BIMLESH@gmail.com', '1', '', '', 'BYXPS0950F', '', '', '', '', '', '', '0', '0', '', '', NULL),
('94', 'EMP-F-064', '', '', 'SUNIL KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SUNIL@gmail.com', '1', '', '', 'BMDPK0704M', '', '', '', '', '', '', '0', '0', '', '', NULL),
('95', 'EMP-F-065', '', '', 'GUDIYA  KUMARI', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'GUDIYA@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('96', 'EMP-F-067', '', '', 'ABRAHAM SOREN', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'ABRAHAM@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('97', 'EMP-F-217', '', '', 'RAJESH KUMAR ', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'RAJESH@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('98', 'EMP-F-218', '', '', 'SURESH KUMAR', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'SURESH@gmail.com', '1', '', '', '', '', '', '', '', '', '', '0', '0', '', '', NULL),
('99', 'EMP-F-071', '', '', 'VINAY KUMAR SHARMA', '', '', 'Patna', 'Patna', '', '', '', 'Patna', '1479', '800013', '99', '0', '0000-00-00', '0', '0', NULL, '', '9874563210', 'VINAY@gmail.com', '1', '', '', 'BWCPS7937M', '', '', '', '', '', '', '0', '0', '', '', NULL);

### Structure of table `fa_kv_empl_job` ###

DROP TABLE IF EXISTS `fa_kv_empl_job`;

CREATE TABLE `fa_kv_empl_job` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `empl_id` varchar(10) NOT NULL,
  `employee_type` int(11) NOT NULL,
  `eligible_hra` int(11) NOT NULL,
  `grade` tinyint(2) NOT NULL,
  `department` tinyint(2) NOT NULL,
  `desig_group` tinyint(2) NOT NULL,
  `desig` varchar(40) NOT NULL,
  `joining` date NOT NULL,
  `empl_type` tinyint(2) NOT NULL,
  `working_branch` tinyint(2) NOT NULL,
  `mod_of_pay` int(2) NOT NULL,
  `ifsc_code` varchar(100) NOT NULL,
  `bank_name` varchar(40) NOT NULL,
  `act_holder_name` varchar(150) DEFAULT NULL,
  `acc_no` varchar(30) NOT NULL,
  `gross_pay_annum` int(20) NOT NULL,
  `gross` varchar(10) DEFAULT NULL,
  `5` varchar(15) DEFAULT NULL,
  `6` varchar(15) DEFAULT NULL,
  `2` varchar(15) DEFAULT NULL,
  `3` varchar(15) DEFAULT NULL,
  `4` varchar(15) DEFAULT NULL,
  `1` varchar(11) DEFAULT NULL,
  `8` varchar(11) DEFAULT NULL,
  `contract_end_date` varchar(100) DEFAULT NULL,
  `contract_duration` varchar(100) DEFAULT '0',
  `10` varchar(15) DEFAULT NULL,
  `12` varchar(15) DEFAULT NULL,
  `13` varchar(10) DEFAULT NULL,
  `14` varchar(10) DEFAULT NULL,
  `15` varchar(10) DEFAULT NULL,
  `16` varchar(10) DEFAULT NULL,
  `17` varchar(10) DEFAULT NULL,
  `18` varchar(10) DEFAULT NULL,
  `19` varchar(10) DEFAULT NULL,
  `20` varchar(10) DEFAULT NULL,
  `21` varchar(10) DEFAULT NULL,
  `22` varchar(10) DEFAULT NULL,
  `23` varchar(10) DEFAULT NULL,
  `24` varchar(10) DEFAULT NULL,
  `25` varchar(10) DEFAULT NULL,
  `26` varchar(10) DEFAULT NULL,
  `27` varchar(10) DEFAULT NULL,
  `28` varchar(10) DEFAULT NULL,
  `29` varchar(10) DEFAULT NULL,
  `30` varchar(10) DEFAULT NULL,
  `31` varchar(10) DEFAULT NULL,
  `32` varchar(10) DEFAULT NULL,
  `33` varchar(10) DEFAULT NULL,
  `34` varchar(10) DEFAULT NULL,
  `35` varchar(10) DEFAULT NULL,
  `36` varchar(10) DEFAULT NULL,
  `37` varchar(10) DEFAULT NULL,
  `38` varchar(10) DEFAULT NULL,
  `pre_basic_pay` int(10) DEFAULT '0',
  `pre_grade_pay` int(10) DEFAULT '0',
  `pre_da` int(10) DEFAULT '0',
  `pre_hra` int(10) DEFAULT '0',
  `pre_conveyance` int(10) DEFAULT '0',
  `pre_sas` int(10) DEFAULT '0',
  `pre_prof_tax` int(10) DEFAULT '0',
  `pre_pf` int(10) DEFAULT '0',
  `pre_tds` int(10) DEFAULT '0',
  `pre_financial_year` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `ctc` double DEFAULT '0',
  `39` varchar(10) DEFAULT NULL,
  `40` varchar(10) DEFAULT NULL,
  `41` varchar(10) DEFAULT NULL,
  `42` varchar(10) DEFAULT NULL,
  `43` varchar(10) DEFAULT NULL,
  `44` varchar(10) DEFAULT NULL,
  `45` varchar(10) DEFAULT NULL,
  `46` varchar(10) DEFAULT NULL,
  `47` varchar(10) DEFAULT NULL,
  `48` varchar(10) DEFAULT NULL,
  `49` varchar(10) DEFAULT NULL,
  `50` varchar(11) DEFAULT NULL,
  `51` varchar(11) DEFAULT NULL,
  `52` varchar(11) DEFAULT NULL,
  `eligible_esi` tinyint(4) DEFAULT '0',
  `effective_date` varchar(100) DEFAULT '0000-00-00',
  `0` int(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_empl_job` ###

INSERT INTO `fa_kv_empl_job` VALUES
('1', 'EMP-F-001', '1', '1', '0', '5', '14', '9', '2023-02-15', '2', '1', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('2', 'EMP-F-002', '1', '1', '0', '5', '14', '9', '2023-02-15', '1', '1', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('3', 'EMP-F-162', '1', '1', '0', '5', '1', '2', '2023-02-15', '1', '1', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('4', 'EMP-F-225', '1', '1', '0', '5', '22', '28', '2023-02-15', '1', '0', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('5', 'EMP-F-005', '1', '1', '0', '2', '14', '9', '2023-02-15', '1', '1', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('6', 'EMP-F-006', '1', '1', '0', '5', '14', '9', '2023-02-15', '1', '1', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('7', 'EMP-F-008', '1', '1', '0', '2', '3', '3', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('8', 'EMP-F-009', '1', '1', '0', '2', '3', '24', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('9', 'EMP-F-010', '1', '1', '0', '2', '3', '3', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('10', 'EMP-F-014', '1', '1', '0', '2', '9', '5', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('11', 'EMP-F-022', '1', '1', '0', '2', '1', '2', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('12', 'EMP-F-025', '1', '1', '0', '2', '8', '29', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('13', 'EMP-F-075', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('14', 'EMP-F-077', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('15', 'EMP-F-078', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('16', 'EMP-F-085', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('17', 'EMP-F-094', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('18', 'EMP-F-111', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('19', 'EMP-F-114', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('20', 'EMP-F-126', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('21', 'EMP-F-136', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('22', 'EMP-F-150', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('23', 'EMP-F-152', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('24', 'EMP-F-161', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('25', 'EMP-F-163', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('26', 'EMP-F-164', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('27', 'EMP-F-166', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('28', 'EMP-F-168', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('29', 'EMP-F-169', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('30', 'EMP-F-175', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('31', 'EMP-F-177', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('32', 'EMP-F-179', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('33', 'EMP-F-180', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('34', 'EMP-F-185', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('35', 'EMP-F-186', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('36', 'EMP-F-187', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('37', 'EMP-F-190', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('38', 'EMP-F-196', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('39', 'EMP-F-201', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('40', 'EMP-F-204', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('41', 'EMP-F-208', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('42', 'EMP-F-211', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('43', 'EMP-F-219', '0', '0', '0', '2', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('44', 'EMP-F-027', '1', '1', '0', '6', '11', '11', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('45', 'EMP-F-100', '1', '1', '0', '6', '12', '30', '2023-02-15', '2', '0', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('46', 'EMP-F-029', '1', '1', '0', '7', '13', '12', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('47', 'EMP-F-030', '1', '1', '0', '8', '14', '9', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('48', 'EMP-F-035', '1', '1', '0', '8', '3', '3', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('49', 'EMP-F-036', '1', '1', '0', '8', '3', '15', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('50', 'EMP-F-037', '1', '1', '0', '4', '3', '23', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('51', 'EMP-F-040', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('52', 'EMP-F-041', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('53', 'EMP-F-046', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('54', 'EMP-F-047', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('55', 'EMP-F-050', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('56', 'EMP-F-086', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('57', 'EMP-F-096', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('58', 'EMP-F-102', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('59', 'EMP-F-108', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('60', 'EMP-F-128', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('61', 'EMP-F-120', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('62', 'EMP-F-131', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('63', 'EMP-F-130', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('64', 'EMP-F-149', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('65', 'EMP-F-153', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('66', 'EMP-F-156', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('67', 'EMP-F-167', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('68', 'EMP-F-173', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('69', 'EMP-F-178', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('70', 'EMP-F-182', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('71', 'EMP-F-188', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('72', 'EMP-F-192', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('73', 'EMP-F-194', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('74', 'EMP-F-197', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('75', 'EMP-F-198', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('76', 'EMP-F-199', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('77', 'EMP-F-202', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('78', 'EMP-F-203', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('79', 'EMP-F-206', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('80', 'EMP-F-207', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('81', 'EMP-F-215', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('82', 'EMP-F-220', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('83', 'EMP-F-221', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('84', 'EMP-F-222', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('85', 'EMP-F-223', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('86', 'EMP-F-224', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('87', 'EMP-F-226', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('88', 'EMP-F-227', '0', '0', '0', '8', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('89', 'EMP-F-061', '0', '0', '0', '1', '0', '', '2023-02-15', '0', '0', '0', '', '', NULL, '', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '15-02-2023', '0'),
('90', 'EMP-F-013', '1', '1', '0', '1', '3', '15', '2023-02-15', '1', '0', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('91', 'EMP-F-062', '1', '1', '0', '9', '22', '28', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('92', 'EMP-F-063', '1', '1', '0', '10', '22', '28', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('93', 'EMP-F-064', '1', '1', '0', '11', '22', '28', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('94', 'EMP-F-065', '1', '1', '0', '12', '22', '28', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('95', 'EMP-F-067', '1', '1', '0', '12', '22', '28', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('96', 'EMP-F-217', '2', '1', '0', '13', '19', '26', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('97', 'EMP-F-218', '1', '1', '0', '13', '19', '26', '2023-02-15', '1', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0'),
('98', 'EMP-F-071', '2', '1', '0', '14', '20', '27', '2023-02-15', '2', '2', '1', '', '', NULL, '', '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '15-02-2023', '0');

### Structure of table `fa_kv_empl_loan` ###

DROP TABLE IF EXISTS `fa_kv_empl_loan`;

CREATE TABLE `fa_kv_empl_loan` (
  `id` int(10) NOT NULL,
  `empl_id` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `loan_amount` decimal(15,2) NOT NULL,
  `loan_type_id` int(5) NOT NULL,
  `periods` int(5) NOT NULL,
  `monthly_pay` decimal(15,2) NOT NULL,
  `periods_paid` int(5) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_empl_loan` ###


### Structure of table `fa_kv_empl_option` ###

DROP TABLE IF EXISTS `fa_kv_empl_option`;

CREATE TABLE `fa_kv_empl_option` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `option_name` varchar(150) NOT NULL,
  `option_value` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_empl_option` ###

INSERT INTO `fa_kv_empl_option` VALUES
('1', 'weekly_off', 'Sun'),
('2', 'empl_ref_type', '0'),
('3', 'salary_account', '5410'),
('4', 'paid_from_account', '1060'),
('5', 'expd_percentage_amt', '50'),
('6', 'weekly_off', 'Sun'),
('7', 'empl_ref_type', '0'),
('8', 'weekly_off', 'Sun'),
('9', 'empl_ref_type', '0');

### Structure of table `fa_kv_empl_salary` ###

DROP TABLE IF EXISTS `fa_kv_empl_salary`;

CREATE TABLE `fa_kv_empl_salary` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `empl_id` varchar(10) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(2) NOT NULL,
  `date` date NOT NULL,
  `gross` int(15) NOT NULL,
  `deduct_tot` float NOT NULL,
  `lop_amount` int(10) NOT NULL,
  `loan` int(10) NOT NULL,
  `adv_sal` int(10) NOT NULL,
  `net_pay` int(10) NOT NULL,
  `misc` int(10) NOT NULL,
  `ot_other_allowance` int(10) NOT NULL,
  `conveyance_allowance` float NOT NULL,
  `leave_encashment` float NOT NULL,
  `tds` float NOT NULL,
  `accom_hra_by_org` int(11) DEFAULT NULL,
  `is_arrear` tinyint(1) DEFAULT NULL,
  `paid_for_months_list` char(50) DEFAULT NULL,
  `paid_for_f_year` tinyint(4) DEFAULT NULL,
  `2` int(15) NOT NULL,
  `6` int(15) NOT NULL,
  `1` int(15) NOT NULL,
  `3` int(15) NOT NULL,
  `4` int(15) NOT NULL,
  `5` int(15) NOT NULL,
  `8` int(15) NOT NULL,
  `10` int(15) NOT NULL,
  `12` int(15) NOT NULL,
  `13` int(10) NOT NULL,
  `14` int(10) NOT NULL,
  `15` int(10) NOT NULL,
  `16` int(10) NOT NULL,
  `17` int(10) NOT NULL,
  `18` int(10) NOT NULL,
  `19` int(10) NOT NULL,
  `20` int(10) NOT NULL,
  `21` int(10) NOT NULL,
  `22` int(10) NOT NULL,
  `23` int(10) NOT NULL,
  `24` int(10) NOT NULL,
  `25` int(10) NOT NULL,
  `26` int(10) NOT NULL,
  `27` int(10) NOT NULL,
  `28` int(10) NOT NULL,
  `29` int(10) NOT NULL,
  `30` int(10) NOT NULL,
  `31` int(10) NOT NULL,
  `32` int(10) NOT NULL,
  `33` int(10) NOT NULL,
  `34` int(10) NOT NULL,
  `35` int(10) NOT NULL,
  `36` int(10) NOT NULL,
  `37` int(10) NOT NULL,
  `38` int(10) NOT NULL,
  `39` int(11) NOT NULL DEFAULT '0',
  `40` int(11) NOT NULL DEFAULT '0',
  `41` int(11) NOT NULL DEFAULT '0',
  `42` int(11) NOT NULL DEFAULT '0',
  `43` int(11) NOT NULL DEFAULT '0',
  `44` int(11) NOT NULL DEFAULT '0',
  `45` int(11) NOT NULL DEFAULT '0',
  `46` int(11) NOT NULL DEFAULT '0',
  `47` int(11) NOT NULL DEFAULT '0',
  `48` int(11) NOT NULL DEFAULT '0',
  `49` int(11) NOT NULL DEFAULT '0',
  `50` int(11) NOT NULL DEFAULT '0',
  `51` int(11) NOT NULL DEFAULT '0',
  `52` int(11) NOT NULL DEFAULT '0',
  `eligible_esi` tinyint(4) NOT NULL DEFAULT '0',
  `0` int(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_empl_salary` ###


### Structure of table `fa_kv_empl_salary_arear_by_month` ###

DROP TABLE IF EXISTS `fa_kv_empl_salary_arear_by_month`;

CREATE TABLE `fa_kv_empl_salary_arear_by_month` (
  `id` int(20) NOT NULL,
  `empl_id` varchar(10) NOT NULL,
  `sal_id` int(11) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(2) NOT NULL,
  `date` date NOT NULL,
  `gross` int(15) NOT NULL,
  `deduct_tot` float NOT NULL,
  `lop_amount` int(10) NOT NULL,
  `loan` int(10) NOT NULL,
  `adv_sal` int(10) NOT NULL,
  `net_pay` int(10) NOT NULL,
  `misc` int(10) NOT NULL,
  `ot_other_allowance` int(10) NOT NULL,
  `conveyance_allowance` float NOT NULL,
  `leave_encashment` float NOT NULL,
  `tds` float NOT NULL,
  `accom_hra_by_org` int(11) DEFAULT NULL,
  `is_arrear` tinyint(1) DEFAULT NULL,
  `paid_for_months_list` char(50) DEFAULT NULL,
  `paid_for_f_year` tinyint(4) DEFAULT NULL,
  `2` int(15) NOT NULL,
  `6` int(15) NOT NULL,
  `1` int(15) NOT NULL,
  `3` int(15) NOT NULL,
  `4` int(15) NOT NULL,
  `5` int(15) NOT NULL,
  `8` int(15) NOT NULL,
  `10` int(15) NOT NULL,
  `12` int(15) NOT NULL,
  `13` int(10) NOT NULL,
  `14` int(10) NOT NULL,
  `15` int(10) NOT NULL,
  `16` int(10) NOT NULL,
  `17` int(10) NOT NULL,
  `18` int(10) NOT NULL,
  `19` int(10) NOT NULL,
  `20` int(10) NOT NULL,
  `21` int(10) NOT NULL,
  `22` int(10) NOT NULL,
  `23` int(10) NOT NULL,
  `24` int(10) NOT NULL,
  `25` int(10) NOT NULL,
  `26` int(10) NOT NULL,
  `27` int(10) NOT NULL,
  `28` int(10) NOT NULL,
  `29` int(10) NOT NULL,
  `30` int(10) NOT NULL,
  `31` int(10) NOT NULL,
  `32` int(10) NOT NULL,
  `33` int(10) NOT NULL,
  `34` int(10) NOT NULL,
  `35` int(10) NOT NULL,
  `36` int(10) NOT NULL,
  `37` int(10) NOT NULL,
  `38` int(10) NOT NULL,
  `39` int(11) NOT NULL DEFAULT '0',
  `40` int(11) NOT NULL DEFAULT '0',
  `41` int(11) NOT NULL DEFAULT '0',
  `42` int(11) NOT NULL DEFAULT '0',
  `43` int(11) NOT NULL DEFAULT '0',
  `44` int(11) NOT NULL DEFAULT '0',
  `45` int(11) NOT NULL DEFAULT '0',
  `46` int(11) NOT NULL DEFAULT '0',
  `47` int(11) NOT NULL DEFAULT '0',
  `48` int(11) NOT NULL DEFAULT '0',
  `49` int(11) NOT NULL DEFAULT '0',
  `50` int(11) NOT NULL DEFAULT '0',
  `51` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_empl_salary_arear_by_month` ###


### Structure of table `fa_kv_empl_training` ###

DROP TABLE IF EXISTS `fa_kv_empl_training`;

CREATE TABLE `fa_kv_empl_training` (
  `id` int(5) NOT NULL,
  `empl_id` varchar(10) NOT NULL,
  `training_desc` varchar(60) NOT NULL,
  `course` varchar(50) NOT NULL,
  `cost` varchar(50) NOT NULL,
  `institute` varchar(60) NOT NULL,
  `s_date` date NOT NULL,
  `e_date` date NOT NULL,
  `notes` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_empl_training` ###


### Structure of table `fa_kv_encashment_request` ###

DROP TABLE IF EXISTS `fa_kv_encashment_request`;

CREATE TABLE `fa_kv_encashment_request` (
  `id` int(11) NOT NULL,
  `request_id` varchar(50) NOT NULL,
  `empl_id` varchar(50) NOT NULL,
  `leave_type` int(10) NOT NULL,
  `encash_days` int(10) NOT NULL,
  `encash_amt` int(10) NOT NULL,
  `encash_request_date` date NOT NULL,
  `remarks` text NOT NULL,
  `inactive` tinyint(4) NOT NULL DEFAULT '0',
  `reason` varchar(200) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `no_of_days_approved` int(10) NOT NULL,
  `approved_date` date NOT NULL,
  `comments` text NOT NULL,
  `approved_amount` int(11) NOT NULL,
  `left_days` int(11) NOT NULL,
  `is_paid` tinyint(4) NOT NULL DEFAULT '0',
  `cal_year` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_encashment_request` ###

INSERT INTO `fa_kv_encashment_request` VALUES
('1', 'r-1', 'EMP-S-002', '11', '11', '7634', '2019-05-22', '', '0', '1', '2', '10', '2019-05-22', '', '6940', '1', '0', '2019'),
('2', 'r-2', 'EMP-F-005', '11', '10', '6770', '2019-05-22', '', '0', '1', '1', '0', '0000-00-00', '', '0', '0', '0', '2019'),
('3', 'r-3', 'EMP-S-003', '11', '11', '4268', '2019-05-22', '', '0', '1', '5', '0', '0000-00-00', '', '0', '0', '0', '2019'),
('4', 'r-4', 'EMP-S-003', '11', '11', '7953', '2019-05-22', '', '0', '1', '2', '5', '2019-06-07', '', '6575', '6', '1', '2019'),
('5', 'r-5', 'EMP-F-001', '2', '5', '8220', '2019-05-28', '2019', '0', '2', '2', '5', '2019-05-28', '', '8220', '0', '1', '2019'),
('6', 'r-6', 'EMP-F-001', '2', '5', '8220', '2020-05-29', '', '0', '2', '5', '0', '0000-00-00', '', '0', '0', '0', '2020'),
('7', 'r-7', 'EMP-F-001', '11', '0', '0', '2019-05-29', '', '0', '3', '1', '0', '0000-00-00', '', '0', '0', '0', '2019'),
('8', 'r-8', 'EMP-F-011', '2', '4', '6576', '2019-06-07', '', '0', '2', '2', '4', '2019-06-07', '', '6576', '0', '1', '2019');

### Structure of table `fa_kv_holiday_master` ###

DROP TABLE IF EXISTS `fa_kv_holiday_master`;

CREATE TABLE `fa_kv_holiday_master` (
  `holiday_id` int(11) NOT NULL,
  `fisc_year` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `descpt` text NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `inactive` int(11) NOT NULL,
  PRIMARY KEY (`holiday_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_holiday_master` ###

INSERT INTO `fa_kv_holiday_master` VALUES
('0', '5', 'Eid', 'EID', '2021-05-14', '2021-05-14', '0');

### Structure of table `fa_kv_hrm_finance_setup` ###

DROP TABLE IF EXISTS `fa_kv_hrm_finance_setup`;

CREATE TABLE `fa_kv_hrm_finance_setup` (
  `id` int(10) NOT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `allowance_debit_gl_code` int(11) NOT NULL DEFAULT '0',
  `allowance_credit_gl_code` int(11) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_kv_hrm_finance_setup` ###

INSERT INTO `fa_kv_hrm_finance_setup` VALUES
('0', 'testing data', 'Salary', '0', '0', '0'),
('1', 'Basic Pay', 'Salary', '4111', '0', '0'),
('2', 'HRA', 'Salary', '4114', '0', '0'),
('3', 'Special Allowance', 'Salary', '4116', '0', '0'),
('4', 'Food Coupon', 'Salary', '4120', '0', '0'),
('5', 'TDS', 'Salary', '0', '1223', '0'),
('6', 'PLI', 'Salary', '4121', '0', '0'),
('7', 'EPF-Employer&#039;s contribution', 'Salary', '0', '1214', '0'),
('8', 'EPF-Employee&#039;s contribution', 'Salary', '0', '1214', '0'),
('9', 'ESIC-Employer&#039;s Contribution', 'Salary', '0', '1222', '0'),
('10', 'ESIC-Employee&#039;s contribution', 'Salary', '0', '1222', '0'),
('11', 'Salary Advance', 'Salary', '2217', '0', '0'),
('12', 'Food coupon Payable', 'Salary', '0', '1224', '0'),
('13', 'EPF-Employeer&#039;s contribution', 'Salary', '4119', '0', '0'),
('14', 'Prof Taxt', 'Salary', '0', '1225', '0'),
('15', 'Salary Payable', 'Salary', '0', '1219', '0'),
('16', 'ESIC-Employer&#039;s Contribution', 'Salary', '4113', '0', '0'),
('17', 'Leave Encashment', 'Salary', '4122', '0', '0'),
('18', 'tuition_fee', 'Course-Fee', '7125', '0', '0'),
('19', 'test', 'Salary', '1060', '1065', '1');

### Structure of table `fa_kv_hrm_tax` ###

DROP TABLE IF EXISTS `fa_kv_hrm_tax`;

CREATE TABLE `fa_kv_hrm_tax` (
  `id` int(10) NOT NULL,
  `min_sal` int(10) NOT NULL,
  `max_sal` int(10) NOT NULL,
  `percentage` int(10) NOT NULL,
  `offset` int(10) NOT NULL,
  `year` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_hrm_tax` ###


### Structure of table `fa_kv_leave_days` ###

DROP TABLE IF EXISTS `fa_kv_leave_days`;

CREATE TABLE `fa_kv_leave_days` (
  `id` smallint(6) unsigned NOT NULL,
  `employee_type` tinyint(1) NOT NULL DEFAULT '0',
  `leave_type` tinyint(1) NOT NULL DEFAULT '0',
  `accural_days` smallint(6) unsigned DEFAULT NULL,
  `weekend_status` tinyint(1) NOT NULL DEFAULT '0',
  `max_accumulation` smallint(6) unsigned DEFAULT NULL,
  `avail_leaves` smallint(6) unsigned DEFAULT NULL,
  `max_days` smallint(6) unsigned DEFAULT NULL,
  `min_days` smallint(6) unsigned DEFAULT NULL,
  `max_times_in_cal_year` int(10) unsigned DEFAULT NULL,
  `max_encash` smallint(6) unsigned DEFAULT NULL,
  `min_encash` smallint(6) unsigned DEFAULT NULL,
  `cal_year` int(10) unsigned DEFAULT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `c_f` tinyint(4) NOT NULL DEFAULT '0',
  `merg_status` tinyint(4) NOT NULL DEFAULT '0',
  `merg_to` int(10) NOT NULL DEFAULT '0',
  `merg_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_leave_days` ###

INSERT INTO `fa_kv_leave_days` VALUES
('1', '1', '1', '15', '0', '12', '0', '0', '0', '0', '0', '0', '2019', '0', '0', '0', '0', '0000-00-00'),
('2', '1', '11', '20', '0', '40', '0', '0', '0', '0', '0', '0', '2019', '0', '1', '0', '0', '0000-00-00'),
('3', '1', '2', '20', '0', '30', '0', '0', '0', '0', '0', '0', '2019', '0', '1', '0', '0', '0000-00-00'),
('4', '1', '3', '30', '0', '50', '0', '0', '0', '0', '0', '0', '2019', '0', '1', '0', '0', '0000-00-00'),
('5', '2', '1', '20', '0', '12', '0', '0', '0', '0', '0', '0', '2019', '0', '0', '0', '0', '0000-00-00'),
('6', '2', '11', '25', '0', '40', '0', '0', '0', '0', '0', '0', '2019', '0', '1', '0', '0', '0000-00-00'),
('7', '2', '2', '20', '0', '30', '0', '0', '0', '0', '0', '0', '2019', '0', '1', '0', '0', '0000-00-00');

### Structure of table `fa_kv_leave_encash` ###

DROP TABLE IF EXISTS `fa_kv_leave_encash`;

CREATE TABLE `fa_kv_leave_encash` (
  `id` int(11) NOT NULL,
  `employee_type` int(10) NOT NULL,
  `leave_type` int(10) NOT NULL,
  `occas_encash` varchar(100) CHARACTER SET latin1 NOT NULL,
  `freq` int(10) NOT NULL,
  `max_encash` int(10) NOT NULL,
  `min_encash` int(10) NOT NULL,
  `min_bal` double(4,2) NOT NULL,
  `inactive` tinyint(4) NOT NULL DEFAULT '0',
  `encash_based` varchar(100) CHARACTER SET latin1 NOT NULL,
  `cal_year` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 ;

### Data of table `fa_kv_leave_encash` ###

INSERT INTO `fa_kv_leave_encash` VALUES
('0', '1', '12', '3', '0', '20', '10', '5.00', '0', '41', '2023'),
('1', '1', '11', '3', '1', '30', '20', '5.00', '0', '1,4', '2023'),
('2', '2', '11', '3', '1', '20', '10', '2.00', '0', '1,4', '2023'),
('3', '1', '2', '2', '1', '5', '1', '1.00', '0', '39', '2023'),
('4', '2', '2', '2', '1', '5', '1', '1.00', '0', '39', '2023'),
('5', '1', '11', '4', '1', '8', '4', '2.00', '0', '1,4', '2023'),
('6', '1', '11', '2', '1', '9', '3', '1.00', '0', '39', '2023'),
('7', '2', '11', '1', '1', '6', '2', '2.00', '0', '39', '2023'),
('8', '1', '1', '3', '2', '2', '2', '2.00', '0', '', '2023');

### Structure of table `fa_kv_leave_master` ###

DROP TABLE IF EXISTS `fa_kv_leave_master`;

CREATE TABLE `fa_kv_leave_master` (
  `leave_id` int(11) NOT NULL AUTO_INCREMENT,
  `designation_group_id` int(11) NOT NULL DEFAULT '0',
  `desig_id` int(11) DEFAULT '0',
  `dept_id` int(11) NOT NULL DEFAULT '0',
  `type_leave` int(11) NOT NULL DEFAULT '0',
  `no_of_cls` decimal(8,1) NOT NULL,
  `no_of_pls` decimal(8,1) NOT NULL,
  `no_of_medical_ls` decimal(8,1) NOT NULL,
  `no_of_el` decimal(8,1) NOT NULL,
  `no_of_spl_cls` decimal(8,1) NOT NULL,
  `no_of_spl_cls_female` decimal(8,1) NOT NULL,
  `no_of_mat_ls` decimal(8,1) NOT NULL,
  `no_of_patern_ls` decimal(8,1) NOT NULL,
  `inactive` int(11) NOT NULL DEFAULT '0',
  `fisc_year` int(11) NOT NULL DEFAULT '0',
  `cal_year` varchar(11) DEFAULT NULL,
  `empl_id` char(30) DEFAULT NULL,
  `updated_date_ml` varchar(50) DEFAULT NULL,
  `updated_date_vl` varchar(50) DEFAULT NULL,
  `updated_date_el` varchar(50) DEFAULT NULL,
  `updated_date` varchar(50) DEFAULT NULL,
  `acess_cl` varchar(50) DEFAULT NULL,
  `acess_vl` varchar(50) DEFAULT NULL,
  `acess_ml` varchar(40) DEFAULT NULL,
  `acess_el` varchar(40) DEFAULT NULL,
  `acess_spl_male` varchar(40) DEFAULT NULL,
  `acess_spl_female` varchar(40) DEFAULT NULL,
  `acess_mat` varchar(40) DEFAULT NULL,
  `acess_pat` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_leave_master` ###

INSERT INTO `fa_kv_leave_master` VALUES
('1', '0', '0', '0', '0', '0.0', '0.0', '0.0', '25.5', '0.0', '0.0', '0.0', '0.0', '0', '5', '2019', 'EMP-F-001', '2020-01-16', '2020-01-26', '2020-01-01', '2020-01-26', '1', '1', '1', '1', '0', '0', '0', '0'),
('2', '0', '0', '0', '0', '2.0', '14.0', '20.0', '20.0', '0.0', '0.0', '0.0', '0.0', '0', '3', '2019', 'EMP-F-005', '2020-01-16', '2020-01-26', '2020-01-16', '2020-01-26', '0', '0', '0', '0', '0', '0', '0', '0'),
('3', '0', '0', '0', '0', '1.0', '1.0', '20.0', '16.0', '0.0', '0.0', '0.0', '0.0', '0', '3', '2019', 'EMP-S-002', '2020-01-16', '2019-01-01', '2020-01-11', '2020-01-16', '0', '0', '0', '0', '0', '0', '0', '0'),
('4', '0', '0', '0', '0', '1.0', '1.0', '20.0', '11.0', '0.0', '0.0', '0.0', '0.0', '0', '3', '2019', 'EMP-S-003', '2020-01-16', '2019-01-01', '2020-01-11', '2020-01-16', '0', '0', '0', '0', '0', '0', '0', '0'),
('5', '0', '0', '0', '0', '12.0', '9.0', '14.0', '14.0', '0.0', '0.0', '0.0', '0.0', '0', '3', '2019', 'EMP-F-011', '2020-08-04', '2020-07-25', '2020-08-04', '2020-08-09', '0', '0', '0', '0', '0', '0', '0', '0'),
('6', '0', '0', '0', '0', '0.0', '0.0', '0.0', '0.0', '0.0', '0.0', '0.0', '0.0', '0', '1', NULL, 'EMP-F-018', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('7', '0', '0', '0', '0', '11.0', '4.0', '3.0', '2.0', '1.0', '2.0', '0.0', '0.0', '0', '5', '2021', 'EMP-F-023', '2021-12-10', '2021-12-10', '2021-12-10', '2021-12-10', '1', '1', '1', '1', NULL, NULL, NULL, NULL);

### Structure of table `fa_kv_leave_request_status` ###

DROP TABLE IF EXISTS `fa_kv_leave_request_status`;

CREATE TABLE `fa_kv_leave_request_status` (
  `status_id` int(11) NOT NULL,
  `status_name` varchar(60) NOT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_leave_request_status` ###

INSERT INTO `fa_kv_leave_request_status` VALUES
('1', 'Waiting'),
('2', 'Approved'),
('3', 'Rejected'),
('4', 'Cancel Leave Request'),
('5', 'Approved Cancel Request');

### Structure of table `fa_kv_loan_types` ###

DROP TABLE IF EXISTS `fa_kv_loan_types`;

CREATE TABLE `fa_kv_loan_types` (
  `id` int(10) NOT NULL,
  `loan_name` varchar(200) NOT NULL,
  `interest_rate` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_loan_types` ###


### Structure of table `fa_kv_occasion_master` ###

DROP TABLE IF EXISTS `fa_kv_occasion_master`;

CREATE TABLE `fa_kv_occasion_master` (
  `id` int(11) NOT NULL,
  `occ_name` varchar(255) NOT NULL,
  `yes_no` tinyint(4) NOT NULL DEFAULT '0',
  `inactive` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_occasion_master` ###

INSERT INTO `fa_kv_occasion_master` VALUES
('1', 'Retirement', '1', '0'),
('2', 'Medical', '1', '0'),
('3', 'LTC', '1', '0'),
('4', 'Regular', '1', '0');

### Structure of table `fa_kv_states` ###

DROP TABLE IF EXISTS `fa_kv_states`;

CREATE TABLE `fa_kv_states` (
  `state_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `state_code` varchar(32) COLLATE utf8_bin NOT NULL,
  `state_name` varchar(128) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`state_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ;

### Data of table `fa_kv_states` ###

INSERT INTO `fa_kv_states` VALUES
('1', '1', 'BDS', 'Badakhshan'),
('2', '1', 'BDG', 'Badghis'),
('3', '1', 'BGL', 'Baghlan'),
('4', '1', 'BAL', 'Balkh'),
('5', '1', 'BAM', 'Bamian'),
('6', '1', 'FRA', 'Farah'),
('7', '1', 'FYB', 'Faryab'),
('8', '1', 'GHA', 'Ghazni'),
('9', '1', 'GHO', 'Ghowr'),
('10', '1', 'HEL', 'Helmand'),
('11', '1', 'HER', 'Delhi'),
('12', '1', 'JOW', 'Jowzjan'),
('13', '1', 'KAB', 'Kabul'),
('14', '1', 'KAN', 'Kandahar'),
('15', '1', 'KAP', 'Kapisa'),
('16', '1', 'KHO', 'Khost'),
('17', '1', 'KNR', 'Konar'),
('18', '1', 'KDZ', 'Kondoz'),
('19', '1', 'LAG', 'Laghman'),
('20', '1', 'LOW', 'Lowgar'),
('21', '1', 'NAN', 'Nangrahar'),
('22', '1', 'NIM', 'Nimruz'),
('23', '1', 'NUR', 'Nurestan'),
('24', '1', 'ORU', 'Oruzgan'),
('25', '1', 'PIA', 'Paktia'),
('26', '1', 'PKA', 'Paktika'),
('27', '1', 'PAR', 'Parwan'),
('28', '1', 'SAM', 'Samangan'),
('29', '1', 'SAR', 'Sar-e Pol'),
('30', '1', 'TAK', 'Takhar'),
('31', '1', 'WAR', 'Wardak'),
('32', '1', 'ZAB', 'Zabol'),
('33', '2', 'BR', 'Berat'),
('34', '2', 'BU', 'Bulqize'),
('35', '2', 'DL', 'Delvine'),
('36', '2', 'DV', 'Devoll'),
('37', '2', 'DI', 'Diber'),
('38', '2', 'DR', 'Durres'),
('39', '2', 'EL', 'Elbasan'),
('40', '2', 'ER', 'Kolonje'),
('41', '2', 'FR', 'Fier'),
('42', '2', 'GJ', 'Gjirokaster'),
('43', '2', 'GR', 'Gramsh'),
('44', '2', 'HA', 'Has'),
('45', '2', 'KA', 'Kavaje'),
('46', '2', 'KB', 'Kurbin'),
('47', '2', 'KC', 'Kucove'),
('48', '2', 'KO', 'Korce'),
('49', '2', 'KR', 'Kruje'),
('50', '2', 'KU', 'Kukes'),
('51', '2', 'LB', 'Librazhd'),
('52', '2', 'LE', 'Lezhe'),
('53', '2', 'LU', 'Lushnje'),
('54', '2', 'MM', 'Malesi e Madhe'),
('55', '2', 'MK', 'Mallakaster'),
('56', '2', 'MT', 'Mat'),
('57', '2', 'MR', 'Mirdite'),
('58', '2', 'PQ', 'Peqin'),
('59', '2', 'PR', 'Permet'),
('60', '2', 'PG', 'Pogradec'),
('61', '2', 'PU', 'Puke'),
('62', '2', 'SH', 'Shkoder'),
('63', '2', 'SK', 'Skrapar'),
('64', '2', 'SR', 'Sarande'),
('65', '2', 'TE', 'Tepelene'),
('66', '2', 'TP', 'Tropoje'),
('67', '2', 'TR', 'Tirane'),
('68', '2', 'VL', 'Vlore'),
('69', '3', 'ADR', 'Adrar'),
('70', '3', 'ADE', 'Ain Defla'),
('71', '3', 'ATE', 'Ain Temouchent'),
('72', '3', 'ALG', 'Alger'),
('73', '3', 'ANN', 'Annaba'),
('74', '3', 'BAT', 'Batna'),
('75', '3', 'BEC', 'Bechar'),
('76', '3', 'BEJ', 'Bejaia'),
('77', '3', 'BIS', 'Biskra'),
('78', '3', 'BLI', 'Blida'),
('79', '3', 'BBA', 'Bordj Bou Arreridj'),
('80', '3', 'BOA', 'Bouira'),
('81', '3', 'BMD', 'Boumerdes'),
('82', '3', 'CHL', 'Chlef'),
('83', '3', 'CON', 'Constantine'),
('84', '3', 'DJE', 'Djelfa'),
('85', '3', 'EBA', 'El Bayadh'),
('86', '3', 'EOU', 'El Oued'),
('87', '3', 'ETA', 'El Tarf'),
('88', '3', 'GHA', 'Ghardaia'),
('89', '3', 'GUE', 'Guelma'),
('90', '3', 'ILL', 'Illizi'),
('91', '3', 'JIJ', 'Jijel'),
('92', '3', 'KHE', 'Khenchela'),
('93', '3', 'LAG', 'Laghouat'),
('94', '3', 'MUA', 'Muaskar'),
('95', '3', 'MED', 'Medea'),
('96', '3', 'MIL', 'Mila'),
('97', '3', 'MOS', 'Mostaganem'),
('98', '3', 'MSI', 'M&#039;Sila'),
('99', '3', 'NAA', 'Naama'),
('100', '3', 'ORA', 'Oran'),
('101', '3', 'OUA', 'Ouargla'),
('102', '3', 'OEB', 'Oum el-Bouaghi'),
('103', '3', 'REL', 'Relizane'),
('104', '3', 'SAI', 'Saida'),
('105', '3', 'SET', 'Setif'),
('106', '3', 'SBA', 'Sidi Bel Abbes'),
('107', '3', 'SKI', 'Skikda'),
('108', '3', 'SAH', 'Souk Ahras'),
('109', '3', 'TAM', 'Tamanghasset'),
('110', '3', 'TEB', 'Tebessa'),
('111', '3', 'TIA', 'Tiaret'),
('112', '3', 'TIN', 'Tindouf'),
('113', '3', 'TIP', 'Tipaza'),
('114', '3', 'TIS', 'Tissemsilt'),
('115', '3', 'TOU', 'Tizi Ouzou'),
('116', '3', 'TLE', 'Tlemcen'),
('117', '4', 'E', 'Eastern'),
('118', '4', 'M', 'Manu&#039;a'),
('119', '4', 'R', 'Rose Island'),
('120', '4', 'S', 'Swains Island'),
('121', '4', 'W', 'Western'),
('122', '5', 'ALV', 'Andorra la Vella'),
('123', '5', 'CAN', 'Canillo'),
('124', '5', 'ENC', 'Encamp'),
('125', '5', 'ESE', 'Escaldes-Engordany'),
('126', '5', 'LMA', 'La Massana'),
('127', '5', 'ORD', 'Ordino'),
('128', '5', 'SJL', 'Sant Julia de Loria'),
('129', '6', 'BGO', 'Bengo'),
('130', '6', 'BGU', 'Benguela'),
('131', '6', 'BIE', 'Bie'),
('132', '6', 'CAB', 'Cabinda'),
('133', '6', 'CCU', 'Cuando-Cubango'),
('134', '6', 'CNO', 'Cuanza Norte'),
('135', '6', 'CUS', 'Cuanza Sul'),
('136', '6', 'CNN', 'Cunene'),
('137', '6', 'HUA', 'Huambo'),
('138', '6', 'HUI', 'Huila'),
('139', '6', 'LUA', 'Luanda'),
('140', '6', 'LNO', 'Lunda Norte'),
('141', '6', 'LSU', 'Lunda Sul'),
('142', '6', 'MAL', 'Malange'),
('143', '6', 'MOX', 'Moxico'),
('144', '6', 'NAM', 'Namibe'),
('145', '6', 'UIG', 'Uige'),
('146', '6', 'ZAI', 'Zaire'),
('147', '9', 'ASG', 'Saint George'),
('148', '9', 'ASJ', 'Saint John'),
('149', '9', 'ASM', 'Saint Mary'),
('150', '9', 'ASL', 'Saint Paul'),
('151', '9', 'ASR', 'Saint Peter'),
('152', '9', 'ASH', 'Saint Philip'),
('153', '9', 'BAR', 'Barbuda'),
('154', '9', 'RED', 'Redonda'),
('155', '10', 'AN', 'Antartida e Islas del Atlantico'),
('156', '10', 'BA', 'Buenos Aires'),
('157', '10', 'CA', 'Catamarca'),
('158', '10', 'CH', 'Chaco'),
('159', '10', 'CU', 'Chubut'),
('160', '10', 'CO', 'Cordoba'),
('161', '10', 'CR', 'Corrientes'),
('162', '10', 'DF', 'Distrito Federal'),
('163', '10', 'ER', 'Entre Rios'),
('164', '10', 'FO', 'Formosa'),
('165', '10', 'JU', 'Jujuy'),
('166', '10', 'LP', 'La Pampa'),
('167', '10', 'LR', 'La Rioja'),
('168', '10', 'ME', 'Mendoza'),
('169', '10', 'MI', 'Misiones'),
('170', '10', 'NE', 'Neuquen'),
('171', '10', 'RN', 'Rio Negro'),
('172', '10', 'SA', 'Salta'),
('173', '10', 'SJ', 'San Juan'),
('174', '10', 'SL', 'San Luis'),
('175', '10', 'SC', 'Santa Cruz'),
('176', '10', 'SF', 'Santa Fe'),
('177', '10', 'SD', 'Santiago del Estero'),
('178', '10', 'TF', 'Tierra del Fuego'),
('179', '10', 'TU', 'Tucuman'),
('180', '11', 'AGT', 'Aragatsotn'),
('181', '11', 'ARR', 'Ararat'),
('182', '11', 'ARM', 'Armavir'),
('183', '11', 'GEG', 'Geghark&#039;unik&#039;'),
('184', '11', 'KOT', 'Kotayk&#039;'),
('185', '11', 'LOR', 'Lorri'),
('186', '11', 'SHI', 'Shirak'),
('187', '11', 'SYU', 'Syunik&#039;'),
('188', '11', 'TAV', 'Tavush'),
('189', '11', 'VAY', 'Vayots&#039; Dzor'),
('190', '11', 'YER', 'Yerevan'),
('191', '13', 'ACT', 'Australian Capital Territory'),
('192', '13', 'NSW', 'New South Wales'),
('193', '13', 'NT', 'Northern Territory'),
('194', '13', 'QLD', 'Queensland'),
('195', '13', 'SA', 'South Australia'),
('196', '13', 'TAS', 'Tasmania'),
('197', '13', 'VIC', 'Victoria'),
('198', '13', 'WA', 'Western Australia'),
('199', '14', 'BUR', 'Burgenland'),
('200', '14', 'KAR', 'K�rnten'),
('201', '14', 'NOS', 'Nieder�sterreich'),
('202', '14', 'OOS', 'Ober�sterreich'),
('203', '14', 'SAL', 'Salzburg'),
('204', '14', 'STE', 'Steiermark'),
('205', '14', 'TIR', 'Tirol'),
('206', '14', 'VOR', 'Vorarlberg'),
('207', '14', 'WIE', 'Wien'),
('208', '15', 'AB', 'Ali Bayramli'),
('209', '15', 'ABS', 'Abseron'),
('210', '15', 'AGC', 'AgcabAdi'),
('211', '15', 'AGM', 'Agdam'),
('212', '15', 'AGS', 'Agdas'),
('213', '15', 'AGA', 'Agstafa'),
('214', '15', 'AGU', 'Agsu'),
('215', '15', 'AST', 'Astara'),
('216', '15', 'BA', 'Baki'),
('217', '15', 'BAB', 'BabAk'),
('218', '15', 'BAL', 'BalakAn'),
('219', '15', 'BAR', 'BArdA'),
('220', '15', 'BEY', 'Beylaqan'),
('221', '15', 'BIL', 'Bilasuvar'),
('222', '15', 'CAB', 'Cabrayil'),
('223', '15', 'CAL', 'Calilabab'),
('224', '15', 'CUL', 'Culfa'),
('225', '15', 'DAS', 'Daskasan'),
('226', '15', 'DAV', 'Davaci'),
('227', '15', 'FUZ', 'Fuzuli'),
('228', '15', 'GA', 'Ganca'),
('229', '15', 'GAD', 'Gadabay'),
('230', '15', 'GOR', 'Goranboy'),
('231', '15', 'GOY', 'Goycay'),
('232', '15', 'HAC', 'Haciqabul'),
('233', '15', 'IMI', 'Imisli'),
('234', '15', 'ISM', 'Ismayilli'),
('235', '15', 'KAL', 'Kalbacar'),
('236', '15', 'KUR', 'Kurdamir'),
('237', '15', 'LA', 'Lankaran'),
('238', '15', 'LAC', 'Lacin'),
('239', '15', 'LAN', 'Lankaran'),
('240', '15', 'LER', 'Lerik'),
('241', '15', 'MAS', 'Masalli'),
('242', '15', 'MI', 'Mingacevir'),
('243', '15', 'NA', 'Naftalan'),
('244', '15', 'NEF', 'Neftcala'),
('245', '15', 'OGU', 'Oguz'),
('246', '15', 'ORD', 'Ordubad'),
('247', '15', 'QAB', 'Qabala'),
('248', '15', 'QAX', 'Qax'),
('249', '15', 'QAZ', 'Qazax'),
('250', '15', 'QOB', 'Qobustan'),
('251', '15', 'QBA', 'Quba'),
('252', '15', 'QBI', 'Qubadli'),
('253', '15', 'QUS', 'Qusar'),
('254', '15', 'SA', 'Saki'),
('255', '15', 'SAT', 'Saatli'),
('256', '15', 'SAB', 'Sabirabad'),
('257', '15', 'SAD', 'Sadarak'),
('258', '15', 'SAH', 'Sahbuz'),
('259', '15', 'SAK', 'Saki'),
('260', '15', 'SAL', 'Salyan'),
('261', '15', 'SM', 'Sumqayit'),
('262', '15', 'SMI', 'Samaxi'),
('263', '15', 'SKR', 'Samkir'),
('264', '15', 'SMX', 'Samux'),
('265', '15', 'SAR', 'Sarur'),
('266', '15', 'SIY', 'Siyazan'),
('267', '15', 'SS', 'Susa'),
('268', '15', 'SUS', 'Susa'),
('269', '15', 'TAR', 'Tartar'),
('270', '15', 'TOV', 'Tovuz'),
('271', '15', 'UCA', 'Ucar'),
('272', '15', 'XA', 'Xankandi'),
('273', '15', 'XAC', 'Xacmaz'),
('274', '15', 'XAN', 'Xanlar'),
('275', '15', 'XIZ', 'Xizi'),
('276', '15', 'XCI', 'Xocali'),
('277', '15', 'XVD', 'Xocavand'),
('278', '15', 'YAR', 'Yardimli'),
('279', '15', 'YEV', 'Yevlax'),
('280', '15', 'ZAN', 'Zangilan'),
('281', '15', 'ZAQ', 'Zaqatala'),
('282', '15', 'ZAR', 'Zardab'),
('283', '15', 'NX', 'Naxcivan'),
('284', '16', 'ACK', 'Acklins'),
('285', '16', 'BER', 'Berry Islands'),
('286', '16', 'BIM', 'Bimini'),
('287', '16', 'BLK', 'Black Point'),
('288', '16', 'CAT', 'Cat Island'),
('289', '16', 'CAB', 'Central Abaco'),
('290', '16', 'CAN', 'Central Andros'),
('291', '16', 'CEL', 'Central Eleuthera'),
('292', '16', 'FRE', 'City of Freeport'),
('293', '16', 'CRO', 'Crooked Island'),
('294', '16', 'EGB', 'East Grand Bahama'),
('295', '16', 'EXU', 'Exuma'),
('296', '16', 'GRD', 'Grand Cay'),
('297', '16', 'HAR', 'Harbour Island'),
('298', '16', 'HOP', 'Hope Town'),
('299', '16', 'INA', 'Inagua'),
('300', '16', 'LNG', 'Long Island'),
('301', '16', 'MAN', 'Mangrove Cay'),
('302', '16', 'MAY', 'Mayaguana'),
('303', '16', 'MOO', 'Moore&#039;s Island'),
('304', '16', 'NAB', 'North Abaco'),
('305', '16', 'NAN', 'North Andros'),
('306', '16', 'NEL', 'North Eleuthera'),
('307', '16', 'RAG', 'Ragged Island'),
('308', '16', 'RUM', 'Rum Cay'),
('309', '16', 'SAL', 'San Salvador'),
('310', '16', 'SAB', 'South Abaco'),
('311', '16', 'SAN', 'South Andros'),
('312', '16', 'SEL', 'South Eleuthera'),
('313', '16', 'SWE', 'Spanish Wells'),
('314', '16', 'WGB', 'West Grand Bahama'),
('315', '17', 'CAP', 'Capital'),
('316', '17', 'CEN', 'Central'),
('317', '17', 'MUH', 'Muharraq'),
('318', '17', 'NOR', 'Northern'),
('319', '17', 'SOU', 'Southern'),
('320', '18', 'BAR', 'Barisal'),
('321', '18', 'CHI', 'Chittagong'),
('322', '18', 'DHA', 'Dhaka'),
('323', '18', 'KHU', 'Khulna'),
('324', '18', 'RAJ', 'Rajshahi'),
('325', '18', 'SYL', 'Sylhet'),
('326', '19', 'CC', 'Christ Church'),
('327', '19', 'AND', 'Saint Andrew'),
('328', '19', 'GEO', 'Saint George'),
('329', '19', 'JAM', 'Saint James'),
('330', '19', 'JOH', 'Saint John'),
('331', '19', 'JOS', 'Saint Joseph'),
('332', '19', 'LUC', 'Saint Lucy'),
('333', '19', 'MIC', 'Saint Michael'),
('334', '19', 'PET', 'Saint Peter'),
('335', '19', 'PHI', 'Saint Philip'),
('336', '19', 'THO', 'Saint Thomas'),
('337', '20', 'BR', 'Brestskaya (Brest)'),
('338', '20', 'HO', 'Homyel&#039;skaya (Homyel&#039;)'),
('339', '20', 'HM', 'Horad Minsk'),
('340', '20', 'HR', 'Hrodzyenskaya (Hrodna)'),
('341', '20', 'MA', 'Mahilyowskaya (Mahilyow)'),
('342', '20', 'MI', 'Minskaya'),
('343', '20', 'VI', 'Vitsyebskaya (Vitsyebsk)'),
('344', '21', 'VAN', 'Antwerpen'),
('345', '21', 'WBR', 'Brabant Wallon'),
('346', '21', 'WHT', 'Hainaut'),
('347', '21', 'WLG', 'Liege'),
('348', '21', 'VLI', 'Limburg'),
('349', '21', 'WLX', 'Luxembourg'),
('350', '21', 'WNA', 'Namur'),
('351', '21', 'VOV', 'Oost-Vlaanderen'),
('352', '21', 'VBR', 'Vlaams Brabant'),
('353', '21', 'VWV', 'West-Vlaanderen'),
('354', '22', 'BZ', 'Belize'),
('355', '22', 'CY', 'Cayo'),
('356', '22', 'CR', 'Corozal'),
('357', '22', 'OW', 'Orange Walk'),
('358', '22', 'SC', 'Stann Creek'),
('359', '22', 'TO', 'Toledo'),
('360', '23', 'AL', 'Alibori'),
('361', '23', 'AK', 'Atakora'),
('362', '23', 'AQ', 'Atlantique'),
('363', '23', 'BO', 'Borgou'),
('364', '23', 'CO', 'Collines'),
('365', '23', 'DO', 'Donga'),
('366', '23', 'KO', 'Kouffo'),
('367', '23', 'LI', 'Littoral'),
('368', '23', 'MO', 'Mono'),
('369', '23', 'OU', 'Oueme'),
('370', '23', 'PL', 'Plateau'),
('371', '23', 'ZO', 'Zou'),
('372', '24', 'DS', 'Devonshire'),
('373', '24', 'HC', 'Hamilton City'),
('374', '24', 'HA', 'Hamilton'),
('375', '24', 'PG', 'Paget'),
('376', '24', 'PB', 'Pembroke'),
('377', '24', 'GC', 'Saint George City'),
('378', '24', 'SG', 'Saint George&#039;s'),
('379', '24', 'SA', 'Sandys'),
('380', '24', 'SM', 'Smith&#039;s'),
('381', '24', 'SH', 'Southampton'),
('382', '24', 'WA', 'Warwick'),
('383', '25', 'BUM', 'Bumthang'),
('384', '25', 'CHU', 'Chukha'),
('385', '25', 'DAG', 'Dagana'),
('386', '25', 'GAS', 'Gasa'),
('387', '25', 'HAA', 'Haa'),
('388', '25', 'LHU', 'Lhuntse'),
('389', '25', 'MON', 'Mongar'),
('390', '25', 'PAR', 'Paro'),
('391', '25', 'PEM', 'Pemagatshel'),
('392', '25', 'PUN', 'Punakha'),
('393', '25', 'SJO', 'Samdrup Jongkhar'),
('394', '25', 'SAT', 'Samtse'),
('395', '25', 'SAR', 'Sarpang'),
('396', '25', 'THI', 'Thimphu'),
('397', '25', 'TRG', 'Trashigang'),
('398', '25', 'TRY', 'Trashiyangste'),
('399', '25', 'TRO', 'Trongsa'),
('400', '25', 'TSI', 'Tsirang'),
('401', '25', 'WPH', 'Wangdue Phodrang'),
('402', '25', 'ZHE', 'Zhemgang'),
('403', '26', 'BEN', 'Beni'),
('404', '26', 'CHU', 'Chuquisaca'),
('405', '26', 'COC', 'Cochabamba'),
('406', '26', 'LPZ', 'La Paz'),
('407', '26', 'ORU', 'Oruro'),
('408', '26', 'PAN', 'Pando'),
('409', '26', 'POT', 'Potosi'),
('410', '26', 'SCZ', 'Santa Cruz'),
('411', '26', 'TAR', 'Tarija'),
('412', '27', 'BRO', 'Brcko district'),
('413', '27', 'FUS', 'Unsko-Sanski Kanton'),
('414', '27', 'FPO', 'Posavski Kanton'),
('415', '27', 'FTU', 'Tuzlanski Kanton'),
('416', '27', 'FZE', 'Zenicko-Dobojski Kanton'),
('417', '27', 'FBP', 'Bosanskopodrinjski Kanton'),
('418', '27', 'FSB', 'Srednjebosanski Kanton'),
('419', '27', 'FHN', 'Hercegovacko-neretvanski Kanton'),
('420', '27', 'FZH', 'Zapadnohercegovacka Zupanija'),
('421', '27', 'FSA', 'Kanton Sarajevo'),
('422', '27', 'FZA', 'Zapadnobosanska'),
('423', '27', 'SBL', 'Banja Luka'),
('424', '27', 'SDO', 'Doboj'),
('425', '27', 'SBI', 'Bijeljina'),
('426', '27', 'SVL', 'Vlasenica'),
('427', '27', 'SSR', 'Sarajevo-Romanija or Sokolac'),
('428', '27', 'SFO', 'Foca'),
('429', '27', 'STR', 'Trebinje'),
('430', '28', 'CE', 'Central'),
('431', '28', 'GH', 'Ghanzi'),
('432', '28', 'KD', 'Kgalagadi'),
('433', '28', 'KT', 'Kgatleng'),
('434', '28', 'KW', 'Kweneng'),
('435', '28', 'NG', 'Ngamiland'),
('436', '28', 'NE', 'North East'),
('437', '28', 'NW', 'North West'),
('438', '28', 'SE', 'South East'),
('439', '28', 'SO', 'Southern'),
('440', '30', 'AC', 'Acre'),
('441', '30', 'AL', 'Alagoas'),
('442', '30', 'AP', 'Amapa'),
('443', '30', 'AM', 'Amazonas'),
('444', '30', 'BA', 'Bahia'),
('445', '30', 'CE', 'Ceara'),
('446', '30', 'DF', 'Distrito Federal'),
('447', '30', 'ES', 'Espirito Santo'),
('448', '30', 'GO', 'Goias'),
('449', '30', 'MA', 'Maranhao'),
('450', '30', 'MT', 'Mato Grosso'),
('451', '30', 'MS', 'Mato Grosso do Sul'),
('452', '30', 'MG', 'Minas Gerais'),
('453', '30', 'PA', 'Para'),
('454', '30', 'PB', 'Paraiba'),
('455', '30', 'PR', 'Parana'),
('456', '30', 'PE', 'Pernambuco'),
('457', '30', 'PI', 'Piaui'),
('458', '30', 'RJ', 'Rio de Janeiro'),
('459', '30', 'RN', 'Rio Grande do Norte'),
('460', '30', 'RS', 'Rio Grande do Sul'),
('461', '30', 'RO', 'Rondonia'),
('462', '30', 'RR', 'Roraima'),
('463', '30', 'SC', 'Santa Catarina'),
('464', '30', 'SP', 'Sao Paulo'),
('465', '30', 'SE', 'Sergipe'),
('466', '30', 'TO', 'Tocantins'),
('467', '31', 'PB', 'Peros Banhos'),
('468', '31', 'SI', 'Salomon Islands'),
('469', '31', 'NI', 'Nelsons Island'),
('470', '31', 'TB', 'Three Brothers'),
('471', '31', 'EA', 'Eagle Islands'),
('472', '31', 'DI', 'Danger Island'),
('473', '31', 'EG', 'Egmont Islands'),
('474', '31', 'DG', 'Diego Garcia'),
('475', '32', 'BEL', 'Belait'),
('476', '32', 'BRM', 'Brunei and Muara'),
('477', '32', 'TEM', 'Temburong'),
('478', '32', 'TUT', 'Tutong'),
('479', '33', '', 'Blagoevgrad'),
('480', '33', '', 'Burgas'),
('481', '33', '', 'Dobrich'),
('482', '33', '', 'Gabrovo'),
('483', '33', '', 'Haskovo'),
('484', '33', '', 'Kardjali'),
('485', '33', '', 'Kyustendil'),
('486', '33', '', 'Lovech'),
('487', '33', '', 'Montana'),
('488', '33', '', 'Pazardjik'),
('489', '33', '', 'Pernik'),
('490', '33', '', 'Pleven'),
('491', '33', '', 'Plovdiv'),
('492', '33', '', 'Razgrad'),
('493', '33', '', 'Shumen'),
('494', '33', '', 'Silistra'),
('495', '33', '', 'Sliven'),
('496', '33', '', 'Smolyan'),
('497', '33', '', 'Sofia'),
('498', '33', '', 'Sofia - town'),
('499', '33', '', 'Stara Zagora'),
('500', '33', '', 'Targovishte'),
('501', '33', '', 'Varna'),
('502', '33', '', 'Veliko Tarnovo'),
('503', '33', '', 'Vidin'),
('504', '33', '', 'Vratza'),
('505', '33', '', 'Yambol'),
('506', '34', 'BAL', 'Bale'),
('507', '34', 'BAM', 'Bam'),
('508', '34', 'BAN', 'Banwa'),
('509', '34', 'BAZ', 'Bazega'),
('510', '34', 'BOR', 'Bougouriba'),
('511', '34', 'BLG', 'Boulgou'),
('512', '34', 'BOK', 'Boulkiemde'),
('513', '34', 'COM', 'Comoe'),
('514', '34', 'GAN', 'Ganzourgou'),
('515', '34', 'GNA', 'Gnagna'),
('516', '34', 'GOU', 'Gourma'),
('517', '34', 'HOU', 'Houet'),
('518', '34', 'IOA', 'Ioba'),
('519', '34', 'KAD', 'Kadiogo'),
('520', '34', 'KEN', 'Kenedougou'),
('521', '34', 'KOD', 'Komondjari'),
('522', '34', 'KOP', 'Kompienga'),
('523', '34', 'KOS', 'Kossi'),
('524', '34', 'KOL', 'Koulpelogo'),
('525', '34', 'KOT', 'Kouritenga'),
('526', '34', 'KOW', 'Kourweogo'),
('527', '34', 'LER', 'Leraba'),
('528', '34', 'LOR', 'Loroum'),
('529', '34', 'MOU', 'Mouhoun'),
('530', '34', 'NAH', 'Nahouri'),
('531', '34', 'NAM', 'Namentenga'),
('532', '34', 'NAY', 'Nayala'),
('533', '34', 'NOU', 'Noumbiel'),
('534', '34', 'OUB', 'Oubritenga'),
('535', '34', 'OUD', 'Oudalan'),
('536', '34', 'PAS', 'Passore'),
('537', '34', 'PON', 'Poni'),
('538', '34', 'SAG', 'Sanguie'),
('539', '34', 'SAM', 'Sanmatenga'),
('540', '34', 'SEN', 'Seno'),
('541', '34', 'SIS', 'Sissili'),
('542', '34', 'SOM', 'Soum'),
('543', '34', 'SOR', 'Sourou'),
('544', '34', 'TAP', 'Tapoa'),
('545', '34', 'TUY', 'Tuy'),
('546', '34', 'YAG', 'Yagha'),
('547', '34', 'YAT', 'Yatenga'),
('548', '34', 'ZIR', 'Ziro'),
('549', '34', 'ZOD', 'Zondoma'),
('550', '34', 'ZOW', 'Zoundweogo'),
('551', '35', 'BB', 'Bubanza'),
('552', '35', 'BJ', 'Bujumbura'),
('553', '35', 'BR', 'Bururi'),
('554', '35', 'CA', 'Cankuzo'),
('555', '35', 'CI', 'Cibitoke'),
('556', '35', 'GI', 'Gitega'),
('557', '35', 'KR', 'Karuzi'),
('558', '35', 'KY', 'Kayanza'),
('559', '35', 'KI', 'Kirundo'),
('560', '35', 'MA', 'Makamba'),
('561', '35', 'MU', 'Muramvya'),
('562', '35', 'MY', 'Muyinga'),
('563', '35', 'MW', 'Mwaro'),
('564', '35', 'NG', 'Ngozi'),
('565', '35', 'RT', 'Rutana'),
('566', '35', 'RY', 'Ruyigi'),
('567', '36', 'PP', 'Phnom Penh'),
('568', '36', 'PS', 'Preah Seihanu (Kompong Som or Sihanoukville)'),
('569', '36', 'PA', 'Pailin'),
('570', '36', 'KB', 'Keb'),
('571', '36', 'BM', 'Banteay Meanchey'),
('572', '36', 'BA', 'Battambang'),
('573', '36', 'KM', 'Kampong Cham'),
('574', '36', 'KN', 'Kampong Chhnang'),
('575', '36', 'KU', 'Kampong Speu'),
('576', '36', 'KO', 'Kampong Som'),
('577', '36', 'KT', 'Kampong Thom'),
('578', '36', 'KP', 'Kampot'),
('579', '36', 'KL', 'Kandal'),
('580', '36', 'KK', 'Kaoh Kong'),
('581', '36', 'KR', 'Kratie'),
('582', '36', 'MK', 'Mondul Kiri'),
('583', '36', 'OM', 'Oddar Meancheay'),
('584', '36', 'PU', 'Pursat'),
('585', '36', 'PR', 'Preah Vihear'),
('586', '36', 'PG', 'Prey Veng'),
('587', '36', 'RK', 'Ratanak Kiri'),
('588', '36', 'SI', 'Siemreap'),
('589', '36', 'ST', 'Stung Treng'),
('590', '36', 'SR', 'Svay Rieng'),
('591', '36', 'TK', 'Takeo'),
('592', '37', 'ADA', 'Adamawa (Adamaoua)'),
('593', '37', 'CEN', 'Centre'),
('594', '37', 'EST', 'East (Est)'),
('595', '37', 'EXN', 'Extreme North (Extreme-Nord)'),
('596', '37', 'LIT', 'Littoral'),
('597', '37', 'NOR', 'North (Nord)'),
('598', '37', 'NOT', 'Northwest (Nord-Ouest)'),
('599', '37', 'OUE', 'West (Ouest)'),
('600', '37', 'SUD', 'South (Sud)'),
('601', '37', 'SOU', 'Southwest (Sud-Ouest).'),
('602', '38', 'AB', 'Alberta'),
('603', '38', 'BC', 'British Columbia'),
('604', '38', 'MB', 'Manitoba'),
('605', '38', 'NB', 'New Brunswick'),
('606', '38', 'NL', 'Newfoundland and Labrador'),
('607', '38', 'NT', 'Northwest Territories'),
('608', '38', 'NS', 'Nova Scotia'),
('609', '38', 'NU', 'Nunavut'),
('610', '38', 'ON', 'Ontario'),
('611', '38', 'PE', 'Prince Edward Island'),
('612', '38', 'QC', 'Qu�bec'),
('613', '38', 'SK', 'Saskatchewan'),
('614', '38', 'YT', 'Yukon Territory'),
('615', '39', 'BV', 'Boa Vista'),
('616', '39', 'BR', 'Brava'),
('617', '39', 'CS', 'Calheta de Sao Miguel'),
('618', '39', 'MA', 'Maio'),
('619', '39', 'MO', 'Mosteiros'),
('620', '39', 'PA', 'Paul'),
('621', '39', 'PN', 'Porto Novo'),
('622', '39', 'PR', 'Praia'),
('623', '39', 'RG', 'Ribeira Grande'),
('624', '39', 'SL', 'Sal'),
('625', '39', 'CA', 'Santa Catarina'),
('626', '39', 'CR', 'Santa Cruz'),
('627', '39', 'SD', 'Sao Domingos'),
('628', '39', 'SF', 'Sao Filipe'),
('629', '39', 'SN', 'Sao Nicolau'),
('630', '39', 'SV', 'Sao Vicente'),
('631', '39', 'TA', 'Tarrafal'),
('632', '40', 'CR', 'Creek'),
('633', '40', 'EA', 'Eastern'),
('634', '40', 'ML', 'Midland'),
('635', '40', 'ST', 'South Town'),
('636', '40', 'SP', 'Spot Bay'),
('637', '40', 'SK', 'Stake Bay'),
('638', '40', 'WD', 'West End'),
('639', '40', 'WN', 'Western'),
('640', '41', 'BBA', 'Bamingui-Bangoran'),
('641', '41', 'BKO', 'Basse-Kotto'),
('642', '41', 'HKO', 'Haute-Kotto'),
('643', '41', 'HMB', 'Haut-Mbomou'),
('644', '41', 'KEM', 'Kemo'),
('645', '41', 'LOB', 'Lobaye'),
('646', '41', 'MKD', 'Mambere-Kade�'),
('647', '41', 'MBO', 'Mbomou'),
('648', '41', 'NMM', 'Nana-Mambere'),
('649', '41', 'OMP', 'Ombella-M&#039;Poko'),
('650', '41', 'OUK', 'Ouaka'),
('651', '41', 'OUH', 'Ouham'),
('652', '41', 'OPE', 'Ouham-Pende'),
('653', '41', 'VAK', 'Vakaga'),
('654', '41', 'NGR', 'Nana-Grebizi'),
('655', '41', 'SMB', 'Sangha-Mbaere'),
('656', '41', 'BAN', 'Bangui'),
('657', '42', 'BA', 'Batha'),
('658', '42', 'BI', 'Biltine'),
('659', '42', 'BE', 'Borkou-Ennedi-Tibesti'),
('660', '42', 'CB', 'Chari-Baguirmi'),
('661', '42', 'GU', 'Guera'),
('662', '42', 'KA', 'Kanem'),
('663', '42', 'LA', 'Lac'),
('664', '42', 'LC', 'Logone Occidental'),
('665', '42', 'LR', 'Logone Oriental'),
('666', '42', 'MK', 'Mayo-Kebbi'),
('667', '42', 'MC', 'Moyen-Chari'),
('668', '42', 'OU', 'Ouaddai'),
('669', '42', 'SA', 'Salamat'),
('670', '42', 'TA', 'Tandjile'),
('671', '43', 'AI', 'Aisen del General Carlos Ibanez'),
('672', '43', 'AN', 'Antofagasta'),
('673', '43', 'AR', 'Araucania'),
('674', '43', 'AT', 'Atacama'),
('675', '43', 'BI', 'Bio-Bio'),
('676', '43', 'CO', 'Coquimbo'),
('677', '43', 'LI', 'Libertador General Bernardo O&#039;Hi'),
('678', '43', 'LL', 'Los Lagos'),
('679', '43', 'MA', 'Magallanes y de la Antartica Chi'),
('680', '43', 'ML', 'Maule'),
('681', '43', 'RM', 'Region Metropolitana'),
('682', '43', 'TA', 'Tarapaca'),
('683', '43', 'VS', 'Valparaiso'),
('684', '44', 'AN', 'Anhui'),
('685', '44', 'BE', 'Beijing'),
('686', '44', 'CH', 'Chongqing'),
('687', '44', 'FU', 'Fujian'),
('688', '44', 'GA', 'Gansu'),
('689', '44', 'GU', 'Guangdong'),
('690', '44', 'GX', 'Guangxi'),
('691', '44', 'GZ', 'Guizhou'),
('692', '44', 'HA', 'Hainan'),
('693', '44', 'HB', 'Hebei'),
('694', '44', 'HL', 'Heilongjiang'),
('695', '44', 'HE', 'Henan'),
('696', '44', 'HK', 'Hong Kong'),
('697', '44', 'HU', 'Hubei'),
('698', '44', 'HN', 'Hunan'),
('699', '44', 'IM', 'Inner Mongolia'),
('700', '44', 'JI', 'Jiangsu'),
('701', '44', 'JX', 'Jiangxi'),
('702', '44', 'JL', 'Jilin'),
('703', '44', 'LI', 'Liaoning'),
('704', '44', 'MA', 'Macau'),
('705', '44', 'NI', 'Ningxia'),
('706', '44', 'SH', 'Shaanxi'),
('707', '44', 'SA', 'Shandong'),
('708', '44', 'SG', 'Shanghai'),
('709', '44', 'SX', 'Shanxi'),
('710', '44', 'SI', 'Sichuan'),
('711', '44', 'TI', 'Tianjin'),
('712', '44', 'XI', 'Xinjiang'),
('713', '44', 'YU', 'Yunnan'),
('714', '44', 'ZH', 'Zhejiang'),
('715', '46', 'D', 'Direction Island'),
('716', '46', 'H', 'Home Island'),
('717', '46', 'O', 'Horsburgh Island'),
('718', '46', 'S', 'South Island'),
('719', '46', 'W', 'West Island'),
('720', '47', 'AMZ', 'Amazonas'),
('721', '47', 'ANT', 'Antioquia'),
('722', '47', 'ARA', 'Arauca'),
('723', '47', 'ATL', 'Atlantico'),
('724', '47', 'BDC', 'Bogota D.C.'),
('725', '47', 'BOL', 'Bolivar'),
('726', '47', 'BOY', 'Boyaca'),
('727', '47', 'CAL', 'Caldas'),
('728', '47', 'CAQ', 'Caqueta'),
('729', '47', 'CAS', 'Casanare'),
('730', '47', 'CAU', 'Cauca'),
('731', '47', 'CES', 'Cesar'),
('732', '47', 'CHO', 'Choco'),
('733', '47', 'COR', 'Cordoba'),
('734', '47', 'CAM', 'Cundinamarca'),
('735', '47', 'GNA', 'Guainia'),
('736', '47', 'GJR', 'Guajira'),
('737', '47', 'GVR', 'Guaviare'),
('738', '47', 'HUI', 'Huila'),
('739', '47', 'MAG', 'Magdalena'),
('740', '47', 'MET', 'Meta'),
('741', '47', 'NAR', 'Narino'),
('742', '47', 'NDS', 'Norte de Santander'),
('743', '47', 'PUT', 'Putumayo'),
('744', '47', 'QUI', 'Quindio'),
('745', '47', 'RIS', 'Risaralda'),
('746', '47', 'SAP', 'San Andres y Providencia'),
('747', '47', 'SAN', 'Santander'),
('748', '47', 'SUC', 'Sucre'),
('749', '47', 'TOL', 'Tolima'),
('750', '47', 'VDC', 'Valle del Cauca'),
('751', '47', 'VAU', 'Vaupes'),
('752', '47', 'VIC', 'Vichada'),
('753', '48', 'G', 'Grande Comore'),
('754', '48', 'A', 'Anjouan'),
('755', '48', 'M', 'Moheli'),
('756', '49', 'BO', 'Bouenza'),
('757', '49', 'BR', 'Brazzaville'),
('758', '49', 'CU', 'Cuvette'),
('759', '49', 'CO', 'Cuvette-Ouest'),
('760', '49', 'KO', 'Kouilou'),
('761', '49', 'LE', 'Lekoumou'),
('762', '49', 'LI', 'Likouala'),
('763', '49', 'NI', 'Niari'),
('764', '49', 'PL', 'Plateaux'),
('765', '49', 'PO', 'Pool'),
('766', '49', 'SA', 'Sangha'),
('767', '50', 'PU', 'Pukapuka'),
('768', '50', 'RK', 'Rakahanga'),
('769', '50', 'MK', 'Manihiki'),
('770', '50', 'PE', 'Penrhyn'),
('771', '50', 'NI', 'Nassau Island'),
('772', '50', 'SU', 'Surwarrow'),
('773', '50', 'PA', 'Palmerston'),
('774', '50', 'AI', 'Aitutaki'),
('775', '50', 'MA', 'Manuae'),
('776', '50', 'TA', 'Takutea'),
('777', '50', 'MT', 'Mitiaro'),
('778', '50', 'AT', 'Atiu'),
('779', '50', 'MU', 'Mauke'),
('780', '50', 'RR', 'Rarotonga'),
('781', '50', 'MG', 'Mangaia'),
('782', '51', 'AL', 'Alajuela'),
('783', '51', 'CA', 'Cartago'),
('784', '51', 'GU', 'Guanacaste'),
('785', '51', 'HE', 'Heredia'),
('786', '51', 'LI', 'Limon'),
('787', '51', 'PU', 'Puntarenas'),
('788', '51', 'SJ', 'San Jose'),
('789', '52', 'ABE', 'Abengourou'),
('790', '52', 'ABI', 'Abidjan'),
('791', '52', 'ABO', 'Aboisso'),
('792', '52', 'ADI', 'Adiake'),
('793', '52', 'ADZ', 'Adzope'),
('794', '52', 'AGB', 'Agboville'),
('795', '52', 'AGN', 'Agnibilekrou'),
('796', '52', 'ALE', 'Alepe'),
('797', '52', 'BOC', 'Bocanda'),
('798', '52', 'BAN', 'Bangolo'),
('799', '52', 'BEO', 'Beoumi'),
('800', '52', 'BIA', 'Biankouma'),
('801', '52', 'BDK', 'Bondoukou'),
('802', '52', 'BGN', 'Bongouanou'),
('803', '52', 'BFL', 'Bouafle'),
('804', '52', 'BKE', 'Bouake'),
('805', '52', 'BNA', 'Bouna'),
('806', '52', 'BDL', 'Boundiali'),
('807', '52', 'DKL', 'Dabakala'),
('808', '52', 'DBU', 'Dabou'),
('809', '52', 'DAL', 'Daloa'),
('810', '52', 'DAN', 'Danane'),
('811', '52', 'DAO', 'Daoukro'),
('812', '52', 'DIM', 'Dimbokro'),
('813', '52', 'DIV', 'Divo'),
('814', '52', 'DUE', 'Duekoue'),
('815', '52', 'FER', 'Ferkessedougou'),
('816', '52', 'GAG', 'Gagnoa'),
('817', '52', 'GBA', 'Grand-Bassam'),
('818', '52', 'GLA', 'Grand-Lahou'),
('819', '52', 'GUI', 'Guiglo'),
('820', '52', 'ISS', 'Issia'),
('821', '52', 'JAC', 'Jacqueville'),
('822', '52', 'KAT', 'Katiola'),
('823', '52', 'KOR', 'Korhogo'),
('824', '52', 'LAK', 'Lakota'),
('825', '52', 'MAN', 'Man'),
('826', '52', 'MKN', 'Mankono'),
('827', '52', 'MBA', 'Mbahiakro'),
('828', '52', 'ODI', 'Odienne'),
('829', '52', 'OUM', 'Oume'),
('830', '52', 'SAK', 'Sakassou'),
('831', '52', 'SPE', 'San-Pedro'),
('832', '52', 'SAS', 'Sassandra'),
('833', '52', 'SEG', 'Seguela'),
('834', '52', 'SIN', 'Sinfra'),
('835', '52', 'SOU', 'Soubre'),
('836', '52', 'TAB', 'Tabou'),
('837', '52', 'TAN', 'Tanda'),
('838', '52', 'TIE', 'Tiebissou'),
('839', '52', 'TIN', 'Tingrela'),
('840', '52', 'TIA', 'Tiassale'),
('841', '52', 'TBA', 'Touba'),
('842', '52', 'TLP', 'Toulepleu'),
('843', '52', 'TMD', 'Toumodi'),
('844', '52', 'VAV', 'Vavoua'),
('845', '52', 'YAM', 'Yamoussoukro'),
('846', '52', 'ZUE', 'Zuenoula'),
('847', '53', 'BB', 'Bjelovar-Bilogora'),
('848', '53', 'CZ', 'City of Zagreb'),
('849', '53', 'DN', 'Dubrovnik-Neretva'),
('850', '53', 'IS', 'Istra'),
('851', '53', 'KA', 'Karlovac'),
('852', '53', 'KK', 'Koprivnica-Krizevci'),
('853', '53', 'KZ', 'Krapina-Zagorje'),
('854', '53', 'LS', 'Lika-Senj'),
('855', '53', 'ME', 'Medimurje'),
('856', '53', 'OB', 'Osijek-Baranja'),
('857', '53', 'PS', 'Pozega-Slavonia'),
('858', '53', 'PG', 'Primorje-Gorski Kotar'),
('859', '53', 'SI', 'Sibenik'),
('860', '53', 'SM', 'Sisak-Moslavina'),
('861', '53', 'SB', 'Slavonski Brod-Posavina'),
('862', '53', 'SD', 'Split-Dalmatia'),
('863', '53', 'VA', 'Varazdin'),
('864', '53', 'VP', 'Virovitica-Podravina'),
('865', '53', 'VS', 'Vukovar-Srijem'),
('866', '53', 'ZK', 'Zadar-Knin'),
('867', '53', 'ZA', 'Zagreb'),
('868', '54', 'CA', 'Camaguey'),
('869', '54', 'CD', 'Ciego de Avila'),
('870', '54', 'CI', 'Cienfuegos'),
('871', '54', 'CH', 'Ciudad de La Habana'),
('872', '54', 'GR', 'Granma'),
('873', '54', 'GU', 'Guantanamo'),
('874', '54', 'HO', 'Holguin'),
('875', '54', 'IJ', 'Isla de la Juventud'),
('876', '54', 'LH', 'La Habana'),
('877', '54', 'LT', 'Las Tunas'),
('878', '54', 'MA', 'Matanzas'),
('879', '54', 'PR', 'Pinar del Rio'),
('880', '54', 'SS', 'Sancti Spiritus'),
('881', '54', 'SC', 'Santiago de Cuba'),
('882', '54', 'VC', 'Villa Clara'),
('883', '55', 'F', 'Famagusta'),
('884', '55', 'K', 'Kyrenia'),
('885', '55', 'A', 'Larnaca'),
('886', '55', 'I', 'Limassol'),
('887', '55', 'N', 'Nicosia'),
('888', '55', 'P', 'Paphos'),
('889', '56', 'U', 'Ustecky'),
('890', '56', 'C', 'Jihocesky'),
('891', '56', 'B', 'Jihomoravsky'),
('892', '56', 'K', 'Karlovarsky'),
('893', '56', 'H', 'Kralovehradecky'),
('894', '56', 'L', 'Liberecky'),
('895', '56', 'T', 'Moravskoslezsky'),
('896', '56', 'M', 'Olomoucky'),
('897', '56', 'E', 'Pardubicky'),
('898', '56', 'P', 'Plzensky'),
('899', '56', 'A', 'Praha'),
('900', '56', 'S', 'Stredocesky'),
('901', '56', 'J', 'Vysocina'),
('902', '56', 'Z', 'Zlinsky'),
('903', '57', 'AR', 'Arhus'),
('904', '57', 'BH', 'Bornholm'),
('905', '57', 'CO', 'Copenhagen'),
('906', '57', 'FO', 'Faroe Islands'),
('907', '57', 'FR', 'Frederiksborg'),
('908', '57', 'FY', 'Fyn'),
('909', '57', 'KO', 'Kobenhavn'),
('910', '57', 'NO', 'Nordjylland'),
('911', '57', 'RI', 'Ribe'),
('912', '57', 'RK', 'Ringkobing'),
('913', '57', 'RO', 'Roskilde'),
('914', '57', 'SO', 'Sonderjylland'),
('915', '57', 'ST', 'Storstrom'),
('916', '57', 'VK', 'Vejle'),
('917', '57', 'VJ', 'Vestj�lland'),
('918', '57', 'VB', 'Viborg'),
('919', '58', 'S', '`Ali Sabih'),
('920', '58', 'K', 'Dikhil'),
('921', '58', 'J', 'Djibouti'),
('922', '58', 'O', 'Obock'),
('923', '58', 'T', 'Tadjoura'),
('924', '59', 'AND', 'Saint Andrew Parish'),
('925', '59', 'DAV', 'Saint David Parish'),
('926', '59', 'GEO', 'Saint George Parish'),
('927', '59', 'JOH', 'Saint John Parish'),
('928', '59', 'JOS', 'Saint Joseph Parish'),
('929', '59', 'LUK', 'Saint Luke Parish'),
('930', '59', 'MAR', 'Saint Mark Parish'),
('931', '59', 'PAT', 'Saint Patrick Parish'),
('932', '59', 'PAU', 'Saint Paul Parish'),
('933', '59', 'PET', 'Saint Peter Parish'),
('934', '60', 'DN', 'Distrito Nacional'),
('935', '60', 'AZ', 'Azua'),
('936', '60', 'BC', 'Baoruco'),
('937', '60', 'BH', 'Barahona'),
('938', '60', 'DJ', 'Dajabon'),
('939', '60', 'DU', 'Duarte'),
('940', '60', 'EL', 'Elias Pina'),
('941', '60', 'SY', 'El Seybo'),
('942', '60', 'ET', 'Espaillat'),
('943', '60', 'HM', 'Hato Mayor'),
('944', '60', 'IN', 'Independencia'),
('945', '60', 'AL', 'La Altagracia'),
('946', '60', 'RO', 'La Romana'),
('947', '60', 'VE', 'La Vega'),
('948', '60', 'MT', 'Maria Trinidad Sanchez'),
('949', '60', 'MN', 'Monsenor Nouel'),
('950', '60', 'MC', 'Monte Cristi'),
('951', '60', 'MP', 'Monte Plata'),
('952', '60', 'PD', 'Pedernales'),
('953', '60', 'PR', 'Peravia (Bani)'),
('954', '60', 'PP', 'Puerto Plata'),
('955', '60', 'SL', 'Salcedo'),
('956', '60', 'SM', 'Samana'),
('957', '60', 'SH', 'Sanchez Ramirez'),
('958', '60', 'SC', 'San Cristobal'),
('959', '60', 'JO', 'San Jose de Ocoa'),
('960', '60', 'SJ', 'San Juan'),
('961', '60', 'PM', 'San Pedro de Macoris'),
('962', '60', 'SA', 'Santiago'),
('963', '60', 'ST', 'Santiago Rodriguez'),
('964', '60', 'SD', 'Santo Domingo'),
('965', '60', 'VA', 'Valverde'),
('966', '61', 'AL', 'Aileu'),
('967', '61', 'AN', 'Ainaro'),
('968', '61', 'BA', 'Baucau'),
('969', '61', 'BO', 'Bobonaro'),
('970', '61', 'CO', 'Cova Lima'),
('971', '61', 'DI', 'Dili'),
('972', '61', 'ER', 'Ermera'),
('973', '61', 'LA', 'Lautem'),
('974', '61', 'LI', 'Liquica'),
('975', '61', 'MT', 'Manatuto'),
('976', '61', 'MF', 'Manufahi'),
('977', '61', 'OE', 'Oecussi'),
('978', '61', 'VI', 'Viqueque'),
('979', '62', 'AZU', 'Azuay'),
('980', '62', 'BOL', 'Bolivar'),
('981', '62', 'CAN', 'Ca�ar'),
('982', '62', 'CAR', 'Carchi'),
('983', '62', 'CHI', 'Chimborazo'),
('984', '62', 'COT', 'Cotopaxi'),
('985', '62', 'EOR', 'El Oro'),
('986', '62', 'ESM', 'Esmeraldas'),
('987', '62', 'GPS', 'Gal�pagos'),
('988', '62', 'GUA', 'Guayas'),
('989', '62', 'IMB', 'Imbabura'),
('990', '62', 'LOJ', 'Loja'),
('991', '62', 'LRO', 'Los Rios'),
('992', '62', 'MAN', 'Manab�'),
('993', '62', 'MSA', 'Morona Santiago'),
('994', '62', 'NAP', 'Napo'),
('995', '62', 'ORE', 'Orellana'),
('996', '62', 'PAS', 'Pastaza'),
('997', '62', 'PIC', 'Pichincha'),
('998', '62', 'SUC', 'Sucumb�os'),
('999', '62', 'TUN', 'Tungurahua'),
('1000', '62', 'ZCH', 'Zamora Chinchipe'),
('1001', '63', 'DHY', 'Ad Daqahliyah'),
('1002', '63', 'BAM', 'Al Bahr al Ahmar'),
('1003', '63', 'BHY', 'Al Buhayrah'),
('1004', '63', 'FYM', 'Al Fayyum'),
('1005', '63', 'GBY', 'Al Gharbiyah'),
('1006', '63', 'IDR', 'Al Iskandariyah'),
('1007', '63', 'IML', 'Al Isma&#039;iliyah'),
('1008', '63', 'JZH', 'Al Jizah'),
('1009', '63', 'MFY', 'Al Minufiyah'),
('1010', '63', 'MNY', 'Al Minya'),
('1011', '63', 'QHR', 'Al Qahirah'),
('1012', '63', 'QLY', 'Al Qalyubiyah'),
('1013', '63', 'WJD', 'Al Wadi al Jadid'),
('1014', '63', 'SHQ', 'Ash Sharqiyah'),
('1015', '63', 'SWY', 'As Suways'),
('1016', '63', 'ASW', 'Aswan'),
('1017', '63', 'ASY', 'Asyut'),
('1018', '63', 'BSW', 'Bani Suwayf'),
('1019', '63', 'BSD', 'Bur Sa&#039;id'),
('1020', '63', 'DMY', 'Dumyat'),
('1021', '63', 'JNS', 'Janub Sina&#039;'),
('1022', '63', 'KSH', 'Kafr ash Shaykh'),
('1023', '63', 'MAT', 'Matruh'),
('1024', '63', 'QIN', 'Qina'),
('1025', '63', 'SHS', 'Shamal Sina&#039;'),
('1026', '63', 'SUH', 'Suhaj'),
('1027', '64', 'AH', 'Ahuachapan'),
('1028', '64', 'CA', 'Cabanas'),
('1029', '64', 'CH', 'Chalatenango'),
('1030', '64', 'CU', 'Cuscatlan'),
('1031', '64', 'LB', 'La Libertad'),
('1032', '64', 'PZ', 'La Paz'),
('1033', '64', 'UN', 'La Union'),
('1034', '64', 'MO', 'Morazan'),
('1035', '64', 'SM', 'San Miguel'),
('1036', '64', 'SS', 'San Salvador'),
('1037', '64', 'SV', 'San Vicente'),
('1038', '64', 'SA', 'Santa Ana'),
('1039', '64', 'SO', 'Sonsonate'),
('1040', '64', 'US', 'Usulutan'),
('1041', '65', 'AN', 'Provincia Annobon'),
('1042', '65', 'BN', 'Provincia Bioko Norte'),
('1043', '65', 'BS', 'Provincia Bioko Sur'),
('1044', '65', 'CS', 'Provincia Centro Sur'),
('1045', '65', 'KN', 'Provincia Kie-Ntem'),
('1046', '65', 'LI', 'Provincia Litoral'),
('1047', '65', 'WN', 'Provincia Wele-Nzas'),
('1048', '66', 'MA', 'Central (Maekel)'),
('1049', '66', 'KE', 'Anseba (Keren)'),
('1050', '66', 'DK', 'Southern Red Sea (Debub-Keih-Bahri)'),
('1051', '66', 'SK', 'Northern Red Sea (Semien-Keih-Bahri)'),
('1052', '66', 'DE', 'Southern (Debub)'),
('1053', '66', 'BR', 'Gash-Barka (Barentu)'),
('1054', '67', 'HA', 'Harjumaa (Tallinn)'),
('1055', '67', 'HI', 'Hiiumaa (Kardla)'),
('1056', '67', 'IV', 'Ida-Virumaa (Johvi)'),
('1057', '67', 'JA', 'Jarvamaa (Paide)'),
('1058', '67', 'JO', 'Jogevamaa (Jogeva)'),
('1059', '67', 'LV', 'Laane-Virumaa (Rakvere)'),
('1060', '67', 'LA', 'Laanemaa (Haapsalu)'),
('1061', '67', 'PA', 'Parnumaa (Parnu)'),
('1062', '67', 'PO', 'Polvamaa (Polva)'),
('1063', '67', 'RA', 'Raplamaa (Rapla)'),
('1064', '67', 'SA', 'Saaremaa (Kuessaare)'),
('1065', '67', 'TA', 'Tartumaa (Tartu)'),
('1066', '67', 'VA', 'Valgamaa (Valga)'),
('1067', '67', 'VI', 'Viljandimaa (Viljandi)'),
('1068', '67', 'VO', 'Vorumaa (Voru)'),
('1069', '68', 'AF', 'Afar'),
('1070', '68', 'AH', 'Amhara'),
('1071', '68', 'BG', 'Benishangul-Gumaz'),
('1072', '68', 'GB', 'Gambela'),
('1073', '68', 'HR', 'Hariai'),
('1074', '68', 'OR', 'Oromia'),
('1075', '68', 'SM', 'Somali'),
('1076', '68', 'SN', 'Southern Nations - Nationalities and Peoples Region'),
('1077', '68', 'TG', 'Tigray'),
('1078', '68', 'AA', 'Addis Ababa'),
('1079', '68', 'DD', 'Dire Dawa'),
('1080', '71', 'C', 'Central Division'),
('1081', '71', 'N', 'Northern Division'),
('1082', '71', 'E', 'Eastern Division'),
('1083', '71', 'W', 'Western Division'),
('1084', '71', 'R', 'Rotuma'),
('1085', '72', 'AL', 'Ahvenanmaan Laani'),
('1086', '72', 'ES', 'Etela-Suomen Laani'),
('1087', '72', 'IS', 'Ita-Suomen Laani'),
('1088', '72', 'LS', 'Lansi-Suomen Laani'),
('1089', '72', 'LA', 'Lapin Lanani'),
('1090', '72', 'OU', 'Oulun Laani'),
('1091', '73', 'AL', 'Alsace'),
('1092', '73', 'AQ', 'Aquitaine'),
('1093', '73', 'AU', 'Auvergne'),
('1094', '73', 'BR', 'Brittany'),
('1095', '73', 'BU', 'Burgundy'),
('1096', '73', 'CE', 'Center Loire Valley'),
('1097', '73', 'CH', 'Champagne'),
('1098', '73', 'CO', 'Corse'),
('1099', '73', 'FR', 'France Comte'),
('1100', '73', 'LA', 'Languedoc Roussillon'),
('1101', '73', 'LI', 'Limousin'),
('1102', '73', 'LO', 'Lorraine'),
('1103', '73', 'MI', 'Midi Pyrenees'),
('1104', '73', 'NO', 'Nord Pas de Calais'),
('1105', '73', 'NR', 'Normandy'),
('1106', '73', 'PA', 'Paris / Ill de France'),
('1107', '73', 'PI', 'Picardie'),
('1108', '73', 'PO', 'Poitou Charente'),
('1109', '73', 'PR', 'Provence'),
('1110', '73', 'RH', 'Rhone Alps'),
('1111', '73', 'RI', 'Riviera'),
('1112', '73', 'WE', 'Western Loire Valley'),
('1113', '74', 'Et', 'Etranger'),
('1114', '74', '01', 'Ain'),
('1115', '74', '02', 'Aisne'),
('1116', '74', '03', 'Allier'),
('1117', '74', '04', 'Alpes de Haute Provence'),
('1118', '74', '05', 'Hautes-Alpes'),
('1119', '74', '06', 'Alpes Maritimes'),
('1120', '74', '07', 'Ard�che'),
('1121', '74', '08', 'Ardennes'),
('1122', '74', '09', 'Ari�ge'),
('1123', '74', '10', 'Aube'),
('1124', '74', '11', 'Aude'),
('1125', '74', '12', 'Aveyron'),
('1126', '74', '13', 'Bouches du Rh�ne'),
('1127', '74', '14', 'Calvados'),
('1128', '74', '15', 'Cantal'),
('1129', '74', '16', 'Charente'),
('1130', '74', '17', 'Charente Maritime'),
('1131', '74', '18', 'Cher'),
('1132', '74', '19', 'Corr�ze'),
('1133', '74', '2A', 'Corse du Sud'),
('1134', '74', '2B', 'Haute Corse'),
('1135', '74', '21', 'C�te d&#039;or'),
('1136', '74', '22', 'C�tes d&#039;Armor'),
('1137', '74', '23', 'Creuse'),
('1138', '74', '24', 'Dordogne'),
('1139', '74', '25', 'Doubs'),
('1140', '74', '26', 'Dr�me'),
('1141', '74', '27', 'Eure'),
('1142', '74', '28', 'Eure et Loir'),
('1143', '74', '29', 'Finist�re'),
('1144', '74', '30', 'Gard'),
('1145', '74', '31', 'Haute Garonne'),
('1146', '74', '32', 'Gers'),
('1147', '74', '33', 'Gironde'),
('1148', '74', '34', 'H�rault'),
('1149', '74', '35', 'Ille et Vilaine'),
('1150', '74', '36', 'Indre'),
('1151', '74', '37', 'Indre et Loire'),
('1152', '74', '38', 'Is�re'),
('1153', '74', '39', 'Jura'),
('1154', '74', '40', 'Landes'),
('1155', '74', '41', 'Loir et Cher'),
('1156', '74', '42', 'Loire'),
('1157', '74', '43', 'Haute Loire'),
('1158', '74', '44', 'Loire Atlantique'),
('1159', '74', '45', 'Loiret'),
('1160', '74', '46', 'Lot'),
('1161', '74', '47', 'Lot et Garonne'),
('1162', '74', '48', 'Loz�re'),
('1163', '74', '49', 'Maine et Loire'),
('1164', '74', '50', 'Manche'),
('1165', '74', '51', 'Marne'),
('1166', '74', '52', 'Haute Marne'),
('1167', '74', '53', 'Mayenne'),
('1168', '74', '54', 'Meurthe et Moselle'),
('1169', '74', '55', 'Meuse'),
('1170', '74', '56', 'Morbihan'),
('1171', '74', '57', 'Moselle'),
('1172', '74', '58', 'Ni�vre'),
('1173', '74', '59', 'Nord'),
('1174', '74', '60', 'Oise'),
('1175', '74', '61', 'Orne'),
('1176', '74', '62', 'Pas de Calais'),
('1177', '74', '63', 'Puy de D�me'),
('1178', '74', '64', 'Pyr�n�es Atlantiques'),
('1179', '74', '65', 'Hautes Pyr�n�es'),
('1180', '74', '66', 'Pyr�n�es Orientales'),
('1181', '74', '67', 'Bas Rhin'),
('1182', '74', '68', 'Haut Rhin'),
('1183', '74', '69', 'Rh�ne'),
('1184', '74', '70', 'Haute Sa�ne'),
('1185', '74', '71', 'Sa�ne et Loire'),
('1186', '74', '72', 'Sarthe'),
('1187', '74', '73', 'Savoie'),
('1188', '74', '74', 'Haute Savoie'),
('1189', '74', '75', 'Paris'),
('1190', '74', '76', 'Seine Maritime'),
('1191', '74', '77', 'Seine et Marne'),
('1192', '74', '78', 'Yvelines'),
('1193', '74', '79', 'Deux S�vres'),
('1194', '74', '80', 'Somme'),
('1195', '74', '81', 'Tarn'),
('1196', '74', '82', 'Tarn et Garonne'),
('1197', '74', '83', 'Var'),
('1198', '74', '84', 'Vaucluse'),
('1199', '74', '85', 'Vend�e'),
('1200', '74', '86', 'Vienne'),
('1201', '74', '87', 'Haute Vienne'),
('1202', '74', '88', 'Vosges'),
('1203', '74', '89', 'Yonne'),
('1204', '74', '90', 'Territoire de Belfort'),
('1205', '74', '91', 'Essonne'),
('1206', '74', '92', 'Hauts de Seine'),
('1207', '74', '93', 'Seine St-Denis'),
('1208', '74', '94', 'Val de Marne'),
('1209', '74', '95', 'Val d&#039;Oise'),
('1210', '76', 'M', 'Archipel des Marquises'),
('1211', '76', 'T', 'Archipel des Tuamotu'),
('1212', '76', 'I', 'Archipel des Tubuai'),
('1213', '76', 'V', 'Iles du Vent'),
('1214', '76', 'S', 'Iles Sous-le-Vent'),
('1215', '77', 'C', 'Iles Crozet'),
('1216', '77', 'K', 'Iles Kerguelen'),
('1217', '77', 'A', 'Ile Amsterdam'),
('1218', '77', 'P', 'Ile Saint-Paul'),
('1219', '77', 'D', 'Adelie Land'),
('1220', '78', 'ES', 'Estuaire'),
('1221', '78', 'HO', 'Haut-Ogooue'),
('1222', '78', 'MO', 'Moyen-Ogooue'),
('1223', '78', 'NG', 'Ngounie'),
('1224', '78', 'NY', 'Nyanga'),
('1225', '78', 'OI', 'Ogooue-Ivindo'),
('1226', '78', 'OL', 'Ogooue-Lolo'),
('1227', '78', 'OM', 'Ogooue-Maritime'),
('1228', '78', 'WN', 'Woleu-Ntem'),
('1229', '79', 'BJ', 'Banjul'),
('1230', '79', 'BS', 'Basse'),
('1231', '79', 'BR', 'Brikama'),
('1232', '79', 'JA', 'Janjangbure'),
('1233', '79', 'KA', 'Kanifeng'),
('1234', '79', 'KE', 'Kerewan'),
('1235', '79', 'KU', 'Kuntaur'),
('1236', '79', 'MA', 'Mansakonko'),
('1237', '79', 'LR', 'Lower River'),
('1238', '79', 'CR', 'Central River'),
('1239', '79', 'NB', 'North Bank'),
('1240', '79', 'UR', 'Upper River'),
('1241', '79', 'WE', 'Western'),
('1242', '80', 'AB', 'Abkhazia'),
('1243', '80', 'AJ', 'Ajaria'),
('1244', '80', 'TB', 'Tbilisi'),
('1245', '80', 'GU', 'Guria'),
('1246', '80', 'IM', 'Imereti'),
('1247', '80', 'KA', 'Kakheti'),
('1248', '80', 'KK', 'Kvemo Kartli'),
('1249', '80', 'MM', 'Mtskheta-Mtianeti'),
('1250', '80', 'RL', 'Racha Lechkhumi and Kvemo Svanet'),
('1251', '80', 'SZ', 'Samegrelo-Zemo Svaneti'),
('1252', '80', 'SJ', 'Samtskhe-Javakheti'),
('1253', '80', 'SK', 'Shida Kartli'),
('1254', '81', 'BAW', 'Baden-W�rttemberg'),
('1255', '81', 'BAY', 'Bayern'),
('1256', '81', 'BER', 'Berlin'),
('1257', '81', 'BRG', 'Brandenburg'),
('1258', '81', 'BRE', 'Bremen'),
('1259', '81', 'HAM', 'Hamburg'),
('1260', '81', 'HES', 'Hessen'),
('1261', '81', 'MEC', 'Mecklenburg-Vorpommern'),
('1262', '81', 'NDS', 'Niedersachsen'),
('1263', '81', 'NRW', 'Nordrhein-Westfalen'),
('1264', '81', 'RHE', 'Rheinland-Pfalz'),
('1265', '81', 'SAR', 'Saarland'),
('1266', '81', 'SAS', 'Sachsen'),
('1267', '81', 'SAC', 'Sachsen-Anhalt'),
('1268', '81', 'SCN', 'Schleswig-Holstein'),
('1269', '81', 'THE', 'Th�ringen'),
('1270', '82', 'AS', 'Ashanti Region'),
('1271', '82', 'BA', 'Brong-Ahafo Region'),
('1272', '82', 'CE', 'Central Region'),
('1273', '82', 'EA', 'Eastern Region'),
('1274', '82', 'GA', 'Greater Accra Region'),
('1275', '82', 'NO', 'Northern Region'),
('1276', '82', 'UE', 'Upper East Region'),
('1277', '82', 'UW', 'Upper West Region'),
('1278', '82', 'VO', 'Volta Region'),
('1279', '82', 'WE', 'Western Region'),
('1280', '84', 'AT', 'Attica'),
('1281', '84', 'CN', 'Central Greece'),
('1282', '84', 'CM', 'Central Macedonia'),
('1283', '84', 'CR', 'Crete'),
('1284', '84', 'EM', 'East Macedonia and Thrace'),
('1285', '84', 'EP', 'Epirus'),
('1286', '84', 'II', 'Ionian Islands'),
('1287', '84', 'NA', 'North Aegean'),
('1288', '84', 'PP', 'Peloponnesos'),
('1289', '84', 'SA', 'South Aegean'),
('1290', '84', 'TH', 'Thessaly'),
('1291', '84', 'WG', 'West Greece'),
('1292', '84', 'WM', 'West Macedonia'),
('1293', '85', 'A', 'Avannaa'),
('1294', '85', 'T', 'Tunu'),
('1295', '85', 'K', 'Kitaa'),
('1296', '86', 'A', 'Saint Andrew'),
('1297', '86', 'D', 'Saint David'),
('1298', '86', 'G', 'Saint George'),
('1299', '86', 'J', 'Saint John'),
('1300', '86', 'M', 'Saint Mark'),
('1301', '86', 'P', 'Saint Patrick'),
('1302', '86', 'C', 'Carriacou'),
('1303', '86', 'Q', 'Petit Martinique'),
('1304', '89', 'AV', 'Alta Verapaz'),
('1305', '89', 'BV', 'Baja Verapaz'),
('1306', '89', 'CM', 'Chimaltenango'),
('1307', '89', 'CQ', 'Chiquimula'),
('1308', '89', 'PE', 'El Peten'),
('1309', '89', 'PR', 'El Progreso'),
('1310', '89', 'QC', 'El Quiche'),
('1311', '89', 'ES', 'Escuintla'),
('1312', '89', 'GU', 'Guatemala'),
('1313', '89', 'HU', 'Huehuetenango'),
('1314', '89', 'IZ', 'Izabal'),
('1315', '89', 'JA', 'Jalapa'),
('1316', '89', 'JU', 'Jutiapa'),
('1317', '89', 'QZ', 'Quetzaltenango'),
('1318', '89', 'RE', 'Retalhuleu'),
('1319', '89', 'ST', 'Sacatepequez'),
('1320', '89', 'SM', 'San Marcos'),
('1321', '89', 'SR', 'Santa Rosa'),
('1322', '89', 'SO', 'Solola'),
('1323', '89', 'SU', 'Suchitepequez'),
('1324', '89', 'TO', 'Totonicapan'),
('1325', '89', 'ZA', 'Zacapa'),
('1326', '90', 'CNK', 'Conakry'),
('1327', '90', 'BYL', 'Beyla'),
('1328', '90', 'BFA', 'Boffa'),
('1329', '90', 'BOK', 'Boke'),
('1330', '90', 'COY', 'Coyah'),
('1331', '90', 'DBL', 'Dabola'),
('1332', '90', 'DLB', 'Dalaba'),
('1333', '90', 'DGR', 'Dinguiraye'),
('1334', '90', 'DBR', 'Dubreka'),
('1335', '90', 'FRN', 'Faranah'),
('1336', '90', 'FRC', 'Forecariah'),
('1337', '90', 'FRI', 'Fria'),
('1338', '90', 'GAO', 'Gaoual'),
('1339', '90', 'GCD', 'Gueckedou'),
('1340', '90', 'KNK', 'Kankan'),
('1341', '90', 'KRN', 'Kerouane'),
('1342', '90', 'KND', 'Kindia'),
('1343', '90', 'KSD', 'Kissidougou'),
('1344', '90', 'KBA', 'Koubia'),
('1345', '90', 'KDA', 'Koundara'),
('1346', '90', 'KRA', 'Kouroussa'),
('1347', '90', 'LAB', 'Labe'),
('1348', '90', 'LLM', 'Lelouma'),
('1349', '90', 'LOL', 'Lola'),
('1350', '90', 'MCT', 'Macenta'),
('1351', '90', 'MAL', 'Mali'),
('1352', '90', 'MAM', 'Mamou'),
('1353', '90', 'MAN', 'Mandiana'),
('1354', '90', 'NZR', 'Nzerekore'),
('1355', '90', 'PIT', 'Pita'),
('1356', '90', 'SIG', 'Siguiri'),
('1357', '90', 'TLM', 'Telimele'),
('1358', '90', 'TOG', 'Tougue'),
('1359', '90', 'YOM', 'Yomou'),
('1360', '91', 'BF', 'Bafata Region'),
('1361', '91', 'BB', 'Biombo Region'),
('1362', '91', 'BS', 'Bissau Region'),
('1363', '91', 'BL', 'Bolama Region'),
('1364', '91', 'CA', 'Cacheu Region'),
('1365', '91', 'GA', 'Gabu Region'),
('1366', '91', 'OI', 'Oio Region'),
('1367', '91', 'QU', 'Quinara Region'),
('1368', '91', 'TO', 'Tombali Region'),
('1369', '92', 'BW', 'Barima-Waini'),
('1370', '92', 'CM', 'Cuyuni-Mazaruni'),
('1371', '92', 'DM', 'Demerara-Mahaica'),
('1372', '92', 'EC', 'East Berbice-Corentyne'),
('1373', '92', 'EW', 'Essequibo Islands-West Demerara'),
('1374', '92', 'MB', 'Mahaica-Berbice'),
('1375', '92', 'PM', 'Pomeroon-Supenaam'),
('1376', '92', 'PI', 'Potaro-Siparuni'),
('1377', '92', 'UD', 'Upper Demerara-Berbice'),
('1378', '92', 'UT', 'Upper Takutu-Upper Essequibo'),
('1379', '93', 'AR', 'Artibonite'),
('1380', '93', 'CE', 'Centre'),
('1381', '93', 'GA', 'Grand&#039;Anse'),
('1382', '93', 'ND', 'Nord'),
('1383', '93', 'NE', 'Nord-Est'),
('1384', '93', 'NO', 'Nord-Ouest'),
('1385', '93', 'OU', 'Ouest'),
('1386', '93', 'SD', 'Sud'),
('1387', '93', 'SE', 'Sud-Est'),
('1388', '94', 'F', 'Flat Island'),
('1389', '94', 'M', 'McDonald Island'),
('1390', '94', 'S', 'Shag Island'),
('1391', '94', 'H', 'Heard Island'),
('1392', '95', 'AT', 'Atlantida'),
('1393', '95', 'CH', 'Choluteca'),
('1394', '95', 'CL', 'Colon'),
('1395', '95', 'CM', 'Comayagua'),
('1396', '95', 'CP', 'Copan'),
('1397', '95', 'CR', 'Cortes'),
('1398', '95', 'PA', 'El Paraiso'),
('1399', '95', 'FM', 'Francisco Morazan'),
('1400', '95', 'GD', 'Gracias a Dios'),
('1401', '95', 'IN', 'Intibuca'),
('1402', '95', 'IB', 'Islas de la Bahia (Bay Islands)'),
('1403', '95', 'PZ', 'La Paz'),
('1404', '95', 'LE', 'Lempira'),
('1405', '95', 'OC', 'Ocotepeque'),
('1406', '95', 'OL', 'Olancho'),
('1407', '95', 'SB', 'Santa Barbara'),
('1408', '95', 'VA', 'Valle'),
('1409', '95', 'YO', 'Yoro'),
('1410', '96', 'HCW', 'Central and Western Hong Kong Island'),
('1411', '96', 'HEA', 'Eastern Hong Kong Island'),
('1412', '96', 'HSO', 'Southern Hong Kong Island'),
('1413', '96', 'HWC', 'Wan Chai Hong Kong Island'),
('1414', '96', 'KKC', 'Kowloon City Kowloon'),
('1415', '96', 'KKT', 'Kwun Tong Kowloon'),
('1416', '96', 'KSS', 'Sham Shui Po Kowloon'),
('1417', '96', 'KWT', 'Wong Tai Sin Kowloon'),
('1418', '96', 'KYT', 'Yau Tsim Mong Kowloon'),
('1419', '96', 'NIS', 'Islands New Territories'),
('1420', '96', 'NKT', 'Kwai Tsing New Territories'),
('1421', '96', 'NNO', 'North New Territories'),
('1422', '96', 'NSK', 'Sai Kung New Territories'),
('1423', '96', 'NST', 'Sha Tin New Territories'),
('1424', '96', 'NTP', 'Tai Po New Territories'),
('1425', '96', 'NTW', 'Tsuen Wan New Territories'),
('1426', '96', 'NTM', 'Tuen Mun New Territories'),
('1427', '96', 'NYL', 'Yuen Long New Territories'),
('1428', '97', 'BK', 'Bacs-Kiskun'),
('1429', '97', 'BA', 'Baranya'),
('1430', '97', 'BE', 'Bekes'),
('1431', '97', 'BS', 'Bekescsaba'),
('1432', '97', 'BZ', 'Borsod-Abauj-Zemplen'),
('1433', '97', 'BU', 'Budapest'),
('1434', '97', 'CS', 'Csongrad'),
('1435', '97', 'DE', 'Debrecen'),
('1436', '97', 'DU', 'Dunaujvaros'),
('1437', '97', 'EG', 'Eger'),
('1438', '97', 'FE', 'Fejer'),
('1439', '97', 'GY', 'Gyor'),
('1440', '97', 'GM', 'Gyor-Moson-Sopron'),
('1441', '97', 'HB', 'Hajdu-Bihar'),
('1442', '97', 'HE', 'Heves'),
('1443', '97', 'HO', 'Hodmezovasarhely'),
('1444', '97', 'JN', 'Jasz-Nagykun-Szolnok'),
('1445', '97', 'KA', 'Kaposvar'),
('1446', '97', 'KE', 'Kecskemet'),
('1447', '97', 'KO', 'Komarom-Esztergom'),
('1448', '97', 'MI', 'Miskolc'),
('1449', '97', 'NA', 'Nagykanizsa'),
('1450', '97', 'NO', 'Nograd'),
('1451', '97', 'NY', 'Nyiregyhaza'),
('1452', '97', 'PE', 'Pecs'),
('1453', '97', 'PS', 'Pest'),
('1454', '97', 'SO', 'Somogy'),
('1455', '97', 'SP', 'Sopron'),
('1456', '97', 'SS', 'Szabolcs-Szatmar-Bereg'),
('1457', '97', 'SZ', 'Szeged'),
('1458', '97', 'SE', 'Szekesfehervar'),
('1459', '97', 'SL', 'Szolnok'),
('1460', '97', 'SM', 'Szombathely'),
('1461', '97', 'TA', 'Tatabanya'),
('1462', '97', 'TO', 'Tolna'),
('1463', '97', 'VA', 'Vas'),
('1464', '97', 'VE', 'Veszprem'),
('1465', '97', 'ZA', 'Zala'),
('1466', '97', 'ZZ', 'Zalaegerszeg'),
('1467', '98', 'AL', 'Austurland'),
('1468', '98', 'HF', 'Hofuoborgarsvaeoi'),
('1469', '98', 'NE', 'Norourland eystra'),
('1470', '98', 'NV', 'Norourland vestra'),
('1471', '98', 'SL', 'Suourland'),
('1472', '98', 'SN', 'Suournes'),
('1473', '98', 'VF', 'Vestfiroir'),
('1474', '98', 'VL', 'Vesturland'),
('1475', '99', 'AN', 'Andaman and Nicobar Islands'),
('1476', '99', 'AP', 'Andhra Pradesh'),
('1477', '99', 'AR', 'Arunachal Pradesh'),
('1478', '99', 'AS', 'Assam'),
('1479', '99', 'BI', 'Bihar'),
('1480', '99', 'CH', 'Chandigarh'),
('1481', '99', 'DA', 'Dadra and Nagar Haveli'),
('1482', '99', 'DM', 'Daman and Diu'),
('1483', '99', 'DE', 'Delhi'),
('1484', '99', 'GO', 'Goa'),
('1485', '99', 'GU', 'Gujarat'),
('1486', '99', 'HA', 'Haryana'),
('1487', '99', 'HP', 'Himachal Pradesh'),
('1488', '99', 'JA', 'Jammu and Kashmir'),
('1489', '99', 'KA', 'Karnataka'),
('1490', '99', 'KE', 'Kerala'),
('1491', '99', 'LI', 'Lakshadweep Islands'),
('1492', '99', 'MP', 'Madhya Pradesh'),
('1493', '99', 'MA', 'Maharashtra'),
('1494', '99', 'MN', 'Manipur'),
('1495', '99', 'ME', 'Meghalaya'),
('1496', '99', 'MI', 'Mizoram'),
('1497', '99', 'NA', 'Nagaland'),
('1498', '99', 'OR', 'Orissa'),
('1499', '99', 'PO', 'Pondicherry');
INSERT INTO `fa_kv_states` VALUES
('1500', '99', 'PU', 'Punjab'),
('1501', '99', 'RA', 'Rajasthan'),
('1502', '99', 'SI', 'Sikkim'),
('1503', '99', 'TN', 'Tamil Nadu'),
('1504', '99', 'TR', 'Tripura'),
('1505', '99', 'UP', 'Uttar Pradesh'),
('1506', '99', 'WB', 'West Bengal'),
('1507', '100', 'AC', 'Aceh'),
('1508', '100', 'BA', 'Bali'),
('1509', '100', 'BT', 'Banten'),
('1510', '100', 'BE', 'Bengkulu'),
('1511', '100', 'BD', 'BoDeTaBek'),
('1512', '100', 'GO', 'Gorontalo'),
('1513', '100', 'JK', 'Jakarta Raya'),
('1514', '100', 'JA', 'Jambi'),
('1515', '100', 'JB', 'Jawa Barat'),
('1516', '100', 'JT', 'Jawa Tengah'),
('1517', '100', 'JI', 'Jawa Timur'),
('1518', '100', 'KB', 'Kalimantan Barat'),
('1519', '100', 'KS', 'Kalimantan Selatan'),
('1520', '100', 'KT', 'Kalimantan Tengah'),
('1521', '100', 'KI', 'Kalimantan Timur'),
('1522', '100', 'BB', 'Kepulauan Bangka Belitung'),
('1523', '100', 'LA', 'Lampung'),
('1524', '100', 'MA', 'Maluku'),
('1525', '100', 'MU', 'Maluku Utara'),
('1526', '100', 'NB', 'Nusa Tenggara Barat'),
('1527', '100', 'NT', 'Nusa Tenggara Timur'),
('1528', '100', 'PA', 'Papua'),
('1529', '100', 'RI', 'Riau'),
('1530', '100', 'SN', 'Sulawesi Selatan'),
('1531', '100', 'ST', 'Sulawesi Tengah'),
('1532', '100', 'SG', 'Sulawesi Tenggara'),
('1533', '100', 'SA', 'Sulawesi Utara'),
('1534', '100', 'SB', 'Sumatera Barat'),
('1535', '100', 'SS', 'Sumatera Selatan'),
('1536', '100', 'SU', 'Sumatera Utara'),
('1537', '100', 'YO', 'Yogyakarta'),
('1538', '101', 'TEH', 'Tehran'),
('1539', '101', 'QOM', 'Qom'),
('1540', '101', 'MKZ', 'Markazi'),
('1541', '101', 'QAZ', 'Qazvin'),
('1542', '101', 'GIL', 'Gilan'),
('1543', '101', 'ARD', 'Ardabil'),
('1544', '101', 'ZAN', 'Zanjan'),
('1545', '101', 'EAZ', 'East Azarbaijan'),
('1546', '101', 'WEZ', 'West Azarbaijan'),
('1547', '101', 'KRD', 'Kurdistan'),
('1548', '101', 'HMD', 'Hamadan'),
('1549', '101', 'KRM', 'Kermanshah'),
('1550', '101', 'ILM', 'Ilam'),
('1551', '101', 'LRS', 'Lorestan'),
('1552', '101', 'KZT', 'Khuzestan'),
('1553', '101', 'CMB', 'Chahar Mahaal and Bakhtiari'),
('1554', '101', 'KBA', 'Kohkiluyeh and Buyer Ahmad'),
('1555', '101', 'BSH', 'Bushehr'),
('1556', '101', 'FAR', 'Fars'),
('1557', '101', 'HRM', 'Hormozgan'),
('1558', '101', 'SBL', 'Sistan and Baluchistan'),
('1559', '101', 'KRB', 'Kerman'),
('1560', '101', 'YZD', 'Yazd'),
('1561', '101', 'EFH', 'Esfahan'),
('1562', '101', 'SMN', 'Semnan'),
('1563', '101', 'MZD', 'Mazandaran'),
('1564', '101', 'GLS', 'Golestan'),
('1565', '101', 'NKH', 'North Khorasan'),
('1566', '101', 'RKH', 'Razavi Khorasan'),
('1567', '101', 'SKH', 'South Khorasan'),
('1568', '102', 'BD', 'Baghdad'),
('1569', '102', 'SD', 'Salah ad Din'),
('1570', '102', 'DY', 'Diyala'),
('1571', '102', 'WS', 'Wasit'),
('1572', '102', 'MY', 'Maysan'),
('1573', '102', 'BA', 'Al Basrah'),
('1574', '102', 'DQ', 'Dhi Qar'),
('1575', '102', 'MU', 'Al Muthanna'),
('1576', '102', 'QA', 'Al Qadisyah'),
('1577', '102', 'BB', 'Babil'),
('1578', '102', 'KB', 'Al Karbala'),
('1579', '102', 'NJ', 'An Najaf'),
('1580', '102', 'AB', 'Al Anbar'),
('1581', '102', 'NN', 'Ninawa'),
('1582', '102', 'DH', 'Dahuk'),
('1583', '102', 'AL', 'Arbil'),
('1584', '102', 'TM', 'At Ta&#039;mim'),
('1585', '102', 'SL', 'As Sulaymaniyah'),
('1586', '103', 'CA', 'Carlow'),
('1587', '103', 'CV', 'Cavan'),
('1588', '103', 'CL', 'Clare'),
('1589', '103', 'CO', 'Cork'),
('1590', '103', 'DO', 'Donegal'),
('1591', '103', 'DU', 'Dublin'),
('1592', '103', 'GA', 'Galway'),
('1593', '103', 'KE', 'Kerry'),
('1594', '103', 'KI', 'Kildare'),
('1595', '103', 'KL', 'Kilkenny'),
('1596', '103', 'LA', 'Laois'),
('1597', '103', 'LE', 'Leitrim'),
('1598', '103', 'LI', 'Limerick'),
('1599', '103', 'LO', 'Longford'),
('1600', '103', 'LU', 'Louth'),
('1601', '103', 'MA', 'Mayo'),
('1602', '103', 'ME', 'Meath'),
('1603', '103', 'MO', 'Monaghan'),
('1604', '103', 'OF', 'Offaly'),
('1605', '103', 'RO', 'Roscommon'),
('1606', '103', 'SL', 'Sligo'),
('1607', '103', 'TI', 'Tipperary'),
('1608', '103', 'WA', 'Waterford'),
('1609', '103', 'WE', 'Westmeath'),
('1610', '103', 'WX', 'Wexford'),
('1611', '103', 'WI', 'Wicklow'),
('1612', '104', 'BS', 'Be&#039;er Sheva'),
('1613', '104', 'BH', 'Bika&#039;at Hayarden'),
('1614', '104', 'EA', 'Eilat and Arava'),
('1615', '104', 'GA', 'Galil'),
('1616', '104', 'HA', 'Haifa'),
('1617', '104', 'JM', 'Jehuda Mountains'),
('1618', '104', 'JE', 'Jerusalem'),
('1619', '104', 'NE', 'Negev'),
('1620', '104', 'SE', 'Semaria'),
('1621', '104', 'SH', 'Sharon'),
('1622', '104', 'TA', 'Tel Aviv (Gosh Dan)'),
('1643', '106', 'CLA', 'Clarendon Parish'),
('1644', '106', 'HAN', 'Hanover Parish'),
('1645', '106', 'KIN', 'Kingston Parish'),
('1646', '106', 'MAN', 'Manchester Parish'),
('1647', '106', 'POR', 'Portland Parish'),
('1648', '106', 'AND', 'Saint Andrew Parish'),
('1649', '106', 'ANN', 'Saint Ann Parish'),
('1650', '106', 'CAT', 'Saint Catherine Parish'),
('1651', '106', 'ELI', 'Saint Elizabeth Parish'),
('1652', '106', 'JAM', 'Saint James Parish'),
('1653', '106', 'MAR', 'Saint Mary Parish'),
('1654', '106', 'THO', 'Saint Thomas Parish'),
('1655', '106', 'TRL', 'Trelawny Parish'),
('1656', '106', 'WML', 'Westmoreland Parish'),
('1657', '107', 'AI', 'Aichi'),
('1658', '107', 'AK', 'Akita'),
('1659', '107', 'AO', 'Aomori'),
('1660', '107', 'CH', 'Chiba'),
('1661', '107', 'EH', 'Ehime'),
('1662', '107', 'FK', 'Fukui'),
('1663', '107', 'FU', 'Fukuoka'),
('1664', '107', 'FS', 'Fukushima'),
('1665', '107', 'GI', 'Gifu'),
('1666', '107', 'GU', 'Gumma'),
('1667', '107', 'HI', 'Hiroshima'),
('1668', '107', 'HO', 'Hokkaido'),
('1669', '107', 'HY', 'Hyogo'),
('1670', '107', 'IB', 'Ibaraki'),
('1671', '107', 'IS', 'Ishikawa'),
('1672', '107', 'IW', 'Iwate'),
('1673', '107', 'KA', 'Kagawa'),
('1674', '107', 'KG', 'Kagoshima'),
('1675', '107', 'KN', 'Kanagawa'),
('1676', '107', 'KO', 'Kochi'),
('1677', '107', 'KU', 'Kumamoto'),
('1678', '107', 'KY', 'Kyoto'),
('1679', '107', 'MI', 'Mie'),
('1680', '107', 'MY', 'Miyagi'),
('1681', '107', 'MZ', 'Miyazaki'),
('1682', '107', 'NA', 'Nagano'),
('1683', '107', 'NG', 'Nagasaki'),
('1684', '107', 'NR', 'Nara'),
('1685', '107', 'NI', 'Niigata'),
('1686', '107', 'OI', 'Oita'),
('1687', '107', 'OK', 'Okayama'),
('1688', '107', 'ON', 'Okinawa'),
('1689', '107', 'OS', 'Osaka'),
('1690', '107', 'SA', 'Saga'),
('1691', '107', 'SI', 'Saitama'),
('1692', '107', 'SH', 'Shiga'),
('1693', '107', 'SM', 'Shimane'),
('1694', '107', 'SZ', 'Shizuoka'),
('1695', '107', 'TO', 'Tochigi'),
('1696', '107', 'TS', 'Tokushima'),
('1697', '107', 'TK', 'Tokyo'),
('1698', '107', 'TT', 'Tottori'),
('1699', '107', 'TY', 'Toyama'),
('1700', '107', 'WA', 'Wakayama'),
('1701', '107', 'YA', 'Yamagata'),
('1702', '107', 'YM', 'Yamaguchi'),
('1703', '107', 'YN', 'Yamanashi'),
('1704', '108', 'AM', '&#039;Amman'),
('1705', '108', 'AJ', 'Ajlun'),
('1706', '108', 'AA', 'Al &#039;Aqabah'),
('1707', '108', 'AB', 'Al Balqa&#039;'),
('1708', '108', 'AK', 'Al Karak'),
('1709', '108', 'AL', 'Al Mafraq'),
('1710', '108', 'AT', 'At Tafilah'),
('1711', '108', 'AZ', 'Az Zarqa&#039;'),
('1712', '108', 'IR', 'Irbid'),
('1713', '108', 'JA', 'Jarash'),
('1714', '108', 'MA', 'Ma&#039;an'),
('1715', '108', 'MD', 'Madaba'),
('1716', '109', 'AL', 'Almaty'),
('1717', '109', 'AC', 'Almaty City'),
('1718', '109', 'AM', 'Aqmola'),
('1719', '109', 'AQ', 'Aqtobe'),
('1720', '109', 'AS', 'Astana City'),
('1721', '109', 'AT', 'Atyrau'),
('1722', '109', 'BA', 'Batys Qazaqstan'),
('1723', '109', 'BY', 'Bayqongyr City'),
('1724', '109', 'MA', 'Mangghystau'),
('1725', '109', 'ON', 'Ongtustik Qazaqstan'),
('1726', '109', 'PA', 'Pavlodar'),
('1727', '109', 'QA', 'Qaraghandy'),
('1728', '109', 'QO', 'Qostanay'),
('1729', '109', 'QY', 'Qyzylorda'),
('1730', '109', 'SH', 'Shyghys Qazaqstan'),
('1731', '109', 'SO', 'Soltustik Qazaqstan'),
('1732', '109', 'ZH', 'Zhambyl'),
('1733', '110', 'CE', 'Central'),
('1734', '110', 'CO', 'Coast'),
('1735', '110', 'EA', 'Eastern'),
('1736', '110', 'NA', 'Nairobi Area'),
('1737', '110', 'NE', 'North Eastern'),
('1738', '110', 'NY', 'Nyanza'),
('1739', '110', 'RV', 'Rift Valley'),
('1740', '110', 'WE', 'Western'),
('1741', '111', 'AG', 'Abaiang'),
('1742', '111', 'AM', 'Abemama'),
('1743', '111', 'AK', 'Aranuka'),
('1744', '111', 'AO', 'Arorae'),
('1745', '111', 'BA', 'Banaba'),
('1746', '111', 'BE', 'Beru'),
('1747', '111', 'bT', 'Butaritari'),
('1748', '111', 'KA', 'Kanton'),
('1749', '111', 'KR', 'Kiritimati'),
('1750', '111', 'KU', 'Kuria'),
('1751', '111', 'MI', 'Maiana'),
('1752', '111', 'MN', 'Makin'),
('1753', '111', 'ME', 'Marakei'),
('1754', '111', 'NI', 'Nikunau'),
('1755', '111', 'NO', 'Nonouti'),
('1756', '111', 'ON', 'Onotoa'),
('1757', '111', 'TT', 'Tabiteuea'),
('1758', '111', 'TR', 'Tabuaeran'),
('1759', '111', 'TM', 'Tamana'),
('1760', '111', 'TW', 'Tarawa'),
('1761', '111', 'TE', 'Teraina'),
('1762', '112', 'CHA', 'Chagang-do'),
('1763', '112', 'HAB', 'Hamgyong-bukto'),
('1764', '112', 'HAN', 'Hamgyong-namdo'),
('1765', '112', 'HWB', 'Hwanghae-bukto'),
('1766', '112', 'HWN', 'Hwanghae-namdo'),
('1767', '112', 'KAN', 'Kangwon-do'),
('1768', '112', 'PYB', 'P&#039;yongan-bukto'),
('1769', '112', 'PYN', 'P&#039;yongan-namdo'),
('1770', '112', 'YAN', 'Ryanggang-do (Yanggang-do)'),
('1771', '112', 'NAJ', 'Rason Directly Governed City'),
('1772', '112', 'PYO', 'P&#039;yongyang Special City'),
('1773', '113', 'CO', 'Ch&#039;ungch&#039;ong-bukto'),
('1774', '113', 'CH', 'Ch&#039;ungch&#039;ong-namdo'),
('1775', '113', 'CD', 'Cheju-do'),
('1776', '113', 'CB', 'Cholla-bukto'),
('1777', '113', 'CN', 'Cholla-namdo'),
('1778', '113', 'IG', 'Inch&#039;on-gwangyoksi'),
('1779', '113', 'KA', 'Kangwon-do'),
('1780', '113', 'KG', 'Kwangju-gwangyoksi'),
('1781', '113', 'KD', 'Kyonggi-do'),
('1782', '113', 'KB', 'Kyongsang-bukto'),
('1783', '113', 'KN', 'Kyongsang-namdo'),
('1784', '113', 'PG', 'Pusan-gwangyoksi'),
('1785', '113', 'SO', 'Soul-t&#039;ukpyolsi'),
('1786', '113', 'TA', 'Taegu-gwangyoksi'),
('1787', '113', 'TG', 'Taejon-gwangyoksi'),
('1788', '114', 'AL', 'Al &#039;Asimah'),
('1789', '114', 'AA', 'Al Ahmadi'),
('1790', '114', 'AF', 'Al Farwaniyah'),
('1791', '114', 'AJ', 'Al Jahra&#039;'),
('1792', '114', 'HA', 'Hawalli'),
('1793', '115', 'GB', 'Bishkek'),
('1794', '115', 'B', 'Batken'),
('1795', '115', 'C', 'Chu'),
('1796', '115', 'J', 'Jalal-Abad'),
('1797', '115', 'N', 'Naryn'),
('1798', '115', 'O', 'Osh'),
('1799', '115', 'T', 'Talas'),
('1800', '115', 'Y', 'Ysyk-Kol'),
('1801', '116', 'VT', 'Vientiane'),
('1802', '116', 'AT', 'Attapu'),
('1803', '116', 'BK', 'Bokeo'),
('1804', '116', 'BL', 'Bolikhamxai'),
('1805', '116', 'CH', 'Champasak'),
('1806', '116', 'HO', 'Houaphan'),
('1807', '116', 'KH', 'Khammouan'),
('1808', '116', 'LM', 'Louang Namtha'),
('1809', '116', 'LP', 'Louangphabang'),
('1810', '116', 'OU', 'Oudomxai'),
('1811', '116', 'PH', 'Phongsali'),
('1812', '116', 'SL', 'Salavan'),
('1813', '116', 'SV', 'Savannakhet'),
('1814', '116', 'VI', 'Vientiane'),
('1815', '116', 'XA', 'Xaignabouli'),
('1816', '116', 'XE', 'Xekong'),
('1817', '116', 'XI', 'Xiangkhoang'),
('1818', '116', 'XN', 'Xaisomboun'),
('1819', '117', 'AIZ', 'Aizkraukles Rajons'),
('1820', '117', 'ALU', 'Aluksnes Rajons'),
('1821', '117', 'BAL', 'Balvu Rajons'),
('1822', '117', 'BAU', 'Bauskas Rajons'),
('1823', '117', 'CES', 'Cesu Rajons'),
('1824', '117', 'DGR', 'Daugavpils Rajons'),
('1825', '117', 'DOB', 'Dobeles Rajons'),
('1826', '117', 'GUL', 'Gulbenes Rajons'),
('1827', '117', 'JEK', 'Jekabpils Rajons'),
('1828', '117', 'JGR', 'Jelgavas Rajons'),
('1829', '117', 'KRA', 'Kraslavas Rajons'),
('1830', '117', 'KUL', 'Kuldigas Rajons'),
('1831', '117', 'LPR', 'Liepajas Rajons'),
('1832', '117', 'LIM', 'Limbazu Rajons'),
('1833', '117', 'LUD', 'Ludzas Rajons'),
('1834', '117', 'MAD', 'Madonas Rajons'),
('1835', '117', 'OGR', 'Ogres Rajons'),
('1836', '117', 'PRE', 'Preilu Rajons'),
('1837', '117', 'RZR', 'Rezeknes Rajons'),
('1838', '117', 'RGR', 'Rigas Rajons'),
('1839', '117', 'SAL', 'Saldus Rajons'),
('1840', '117', 'TAL', 'Talsu Rajons'),
('1841', '117', 'TUK', 'Tukuma Rajons'),
('1842', '117', 'VLK', 'Valkas Rajons'),
('1843', '117', 'VLM', 'Valmieras Rajons'),
('1844', '117', 'VSR', 'Ventspils Rajons'),
('1845', '117', 'DGV', 'Daugavpils'),
('1846', '117', 'JGV', 'Jelgava'),
('1847', '117', 'JUR', 'Jurmala'),
('1848', '117', 'LPK', 'Liepaja'),
('1849', '117', 'RZK', 'Rezekne'),
('1850', '117', 'RGA', 'Riga'),
('1851', '117', 'VSL', 'Ventspils'),
('1852', '119', 'BE', 'Berea'),
('1853', '119', 'BB', 'Butha-Buthe'),
('1854', '119', 'LE', 'Leribe'),
('1855', '119', 'MF', 'Mafeteng'),
('1856', '119', 'MS', 'Maseru'),
('1857', '119', 'MH', 'Mohale&#039;s Hoek'),
('1858', '119', 'MK', 'Mokhotlong'),
('1859', '119', 'QN', 'Qacha&#039;s Nek'),
('1860', '119', 'QT', 'Quthing'),
('1861', '119', 'TT', 'Thaba-Tseka'),
('1862', '120', 'BI', 'Bomi'),
('1863', '120', 'BG', 'Bong'),
('1864', '120', 'GB', 'Grand Bassa'),
('1865', '120', 'CM', 'Grand Cape Mount'),
('1866', '120', 'GG', 'Grand Gedeh'),
('1867', '120', 'GK', 'Grand Kru'),
('1868', '120', 'LO', 'Lofa'),
('1869', '120', 'MG', 'Margibi'),
('1870', '120', 'ML', 'Maryland'),
('1871', '120', 'MS', 'Montserrado'),
('1872', '120', 'NB', 'Nimba'),
('1873', '120', 'RC', 'River Cess'),
('1874', '120', 'SN', 'Sinoe'),
('1875', '121', 'AJ', 'Ajdabiya'),
('1876', '121', 'AZ', 'Al &#039;Aziziyah'),
('1877', '121', 'FA', 'Al Fatih'),
('1878', '121', 'JA', 'Al Jabal al Akhdar'),
('1879', '121', 'JU', 'Al Jufrah'),
('1880', '121', 'KH', 'Al Khums'),
('1881', '121', 'KU', 'Al Kufrah'),
('1882', '121', 'NK', 'An Nuqat al Khams'),
('1883', '121', 'AS', 'Ash Shati&#039;'),
('1884', '121', 'AW', 'Awbari'),
('1885', '121', 'ZA', 'Az Zawiyah'),
('1886', '121', 'BA', 'Banghazi'),
('1887', '121', 'DA', 'Darnah'),
('1888', '121', 'GD', 'Ghadamis'),
('1889', '121', 'GY', 'Gharyan'),
('1890', '121', 'MI', 'Misratah'),
('1891', '121', 'MZ', 'Murzuq'),
('1892', '121', 'SB', 'Sabha'),
('1893', '121', 'SW', 'Sawfajjin'),
('1894', '121', 'SU', 'Surt'),
('1895', '121', 'TL', 'Tarabulus (Tripoli)'),
('1896', '121', 'TH', 'Tarhunah'),
('1897', '121', 'TU', 'Tubruq'),
('1898', '121', 'YA', 'Yafran'),
('1899', '121', 'ZL', 'Zlitan'),
('1900', '122', 'V', 'Vaduz'),
('1901', '122', 'A', 'Schaan'),
('1902', '122', 'B', 'Balzers'),
('1903', '122', 'N', 'Triesen'),
('1904', '122', 'E', 'Eschen'),
('1905', '122', 'M', 'Mauren'),
('1906', '122', 'T', 'Triesenberg'),
('1907', '122', 'R', 'Ruggell'),
('1908', '122', 'G', 'Gamprin'),
('1909', '122', 'L', 'Schellenberg'),
('1910', '122', 'P', 'Planken'),
('1911', '123', 'AL', 'Alytus'),
('1912', '123', 'KA', 'Kaunas'),
('1913', '123', 'KL', 'Klaipeda'),
('1914', '123', 'MA', 'Marijampole'),
('1915', '123', 'PA', 'Panevezys'),
('1916', '123', 'SI', 'Siauliai'),
('1917', '123', 'TA', 'Taurage'),
('1918', '123', 'TE', 'Telsiai'),
('1919', '123', 'UT', 'Utena'),
('1920', '123', 'VI', 'Vilnius'),
('1921', '124', 'DD', 'Diekirch'),
('1922', '124', 'DC', 'Clervaux'),
('1923', '124', 'DR', 'Redange'),
('1924', '124', 'DV', 'Vianden'),
('1925', '124', 'DW', 'Wiltz'),
('1926', '124', 'GG', 'Grevenmacher'),
('1927', '124', 'GE', 'Echternach'),
('1928', '124', 'GR', 'Remich'),
('1929', '124', 'LL', 'Luxembourg'),
('1930', '124', 'LC', 'Capellen'),
('1931', '124', 'LE', 'Esch-sur-Alzette'),
('1932', '124', 'LM', 'Mersch'),
('1933', '125', 'OLF', 'Our Lady Fatima Parish'),
('1934', '125', 'ANT', 'St. Anthony Parish'),
('1935', '125', 'LAZ', 'St. Lazarus Parish'),
('1936', '125', 'CAT', 'Cathedral Parish'),
('1937', '125', 'LAW', 'St. Lawrence Parish'),
('1938', '127', 'AN', 'Antananarivo'),
('1939', '127', 'AS', 'Antsiranana'),
('1940', '127', 'FN', 'Fianarantsoa'),
('1941', '127', 'MJ', 'Mahajanga'),
('1942', '127', 'TM', 'Toamasina'),
('1943', '127', 'TL', 'Toliara'),
('1944', '128', 'BLK', 'Balaka'),
('1945', '128', 'BLT', 'Blantyre'),
('1946', '128', 'CKW', 'Chikwawa'),
('1947', '128', 'CRD', 'Chiradzulu'),
('1948', '128', 'CTP', 'Chitipa'),
('1949', '128', 'DDZ', 'Dedza'),
('1950', '128', 'DWA', 'Dowa'),
('1951', '128', 'KRG', 'Karonga'),
('1952', '128', 'KSG', 'Kasungu'),
('1953', '128', 'LKM', 'Likoma'),
('1954', '128', 'LLG', 'Lilongwe'),
('1955', '128', 'MCG', 'Machinga'),
('1956', '128', 'MGC', 'Mangochi'),
('1957', '128', 'MCH', 'Mchinji'),
('1958', '128', 'MLJ', 'Mulanje'),
('1959', '128', 'MWZ', 'Mwanza'),
('1960', '128', 'MZM', 'Mzimba'),
('1961', '128', 'NTU', 'Ntcheu'),
('1962', '128', 'NKB', 'Nkhata Bay'),
('1963', '128', 'NKH', 'Nkhotakota'),
('1964', '128', 'NSJ', 'Nsanje'),
('1965', '128', 'NTI', 'Ntchisi'),
('1966', '128', 'PHL', 'Phalombe'),
('1967', '128', 'RMP', 'Rumphi'),
('1968', '128', 'SLM', 'Salima'),
('1969', '128', 'THY', 'Thyolo'),
('1970', '128', 'ZBA', 'Zomba'),
('1971', '129', 'JO', 'Johor'),
('1972', '129', 'KE', 'Kedah'),
('1973', '129', 'KL', 'Kelantan'),
('1974', '129', 'LA', 'Labuan'),
('1975', '129', 'ME', 'Melaka'),
('1976', '129', 'NS', 'Negeri Sembilan'),
('1977', '129', 'PA', 'Pahang'),
('1978', '129', 'PE', 'Perak'),
('1979', '129', 'PR', 'Perlis'),
('1980', '129', 'PP', 'Pulau Pinang'),
('1981', '129', 'SA', 'Sabah'),
('1982', '129', 'SR', 'Sarawak'),
('1983', '129', 'SE', 'Selangor'),
('1984', '129', 'TE', 'Terengganu'),
('1985', '129', 'WP', 'Wilayah Persekutuan'),
('1986', '130', 'THU', 'Thiladhunmathi Uthuru'),
('1987', '130', 'THD', 'Thiladhunmathi Dhekunu'),
('1988', '130', 'MLU', 'Miladhunmadulu Uthuru'),
('1989', '130', 'MLD', 'Miladhunmadulu Dhekunu'),
('1990', '130', 'MAU', 'Maalhosmadulu Uthuru'),
('1991', '130', 'MAD', 'Maalhosmadulu Dhekunu'),
('1992', '130', 'FAA', 'Faadhippolhu'),
('1993', '130', 'MAA', 'Male Atoll'),
('1994', '130', 'AAU', 'Ari Atoll Uthuru'),
('1995', '130', 'AAD', 'Ari Atoll Dheknu'),
('1996', '130', 'FEA', 'Felidhe Atoll'),
('1997', '130', 'MUA', 'Mulaku Atoll'),
('1998', '130', 'NAU', 'Nilandhe Atoll Uthuru'),
('1999', '130', 'NAD', 'Nilandhe Atoll Dhekunu'),
('2000', '130', 'KLH', 'Kolhumadulu'),
('2001', '130', 'HDH', 'Hadhdhunmathi'),
('2002', '130', 'HAU', 'Huvadhu Atoll Uthuru'),
('2003', '130', 'HAD', 'Huvadhu Atoll Dhekunu'),
('2004', '130', 'FMU', 'Fua Mulaku'),
('2005', '130', 'ADD', 'Addu'),
('2006', '131', 'GA', 'Gao'),
('2007', '131', 'KY', 'Kayes'),
('2008', '131', 'KD', 'Kidal'),
('2009', '131', 'KL', 'Koulikoro'),
('2010', '131', 'MP', 'Mopti'),
('2011', '131', 'SG', 'Segou'),
('2012', '131', 'SK', 'Sikasso'),
('2013', '131', 'TB', 'Tombouctou'),
('2014', '131', 'CD', 'Bamako Capital District'),
('2015', '132', 'ATT', 'Attard'),
('2016', '132', 'BAL', 'Balzan'),
('2017', '132', 'BGU', 'Birgu'),
('2018', '132', 'BKK', 'Birkirkara'),
('2019', '132', 'BRZ', 'Birzebbuga'),
('2020', '132', 'BOR', 'Bormla'),
('2021', '132', 'DIN', 'Dingli'),
('2022', '132', 'FGU', 'Fgura'),
('2023', '132', 'FLO', 'Floriana'),
('2024', '132', 'GDJ', 'Gudja'),
('2025', '132', 'GZR', 'Gzira'),
('2026', '132', 'GRG', 'Gargur'),
('2027', '132', 'GXQ', 'Gaxaq'),
('2028', '132', 'HMR', 'Hamrun'),
('2029', '132', 'IKL', 'Iklin'),
('2030', '132', 'ISL', 'Isla'),
('2031', '132', 'KLK', 'Kalkara'),
('2032', '132', 'KRK', 'Kirkop'),
('2033', '132', 'LIJ', 'Lija'),
('2034', '132', 'LUQ', 'Luqa'),
('2035', '132', 'MRS', 'Marsa'),
('2036', '132', 'MKL', 'Marsaskala'),
('2037', '132', 'MXL', 'Marsaxlokk'),
('2038', '132', 'MDN', 'Mdina'),
('2039', '132', 'MEL', 'Melliea'),
('2040', '132', 'MGR', 'Mgarr'),
('2041', '132', 'MST', 'Mosta'),
('2042', '132', 'MQA', 'Mqabba'),
('2043', '132', 'MSI', 'Msida'),
('2044', '132', 'MTF', 'Mtarfa'),
('2045', '132', 'NAX', 'Naxxar'),
('2046', '132', 'PAO', 'Paola'),
('2047', '132', 'PEM', 'Pembroke'),
('2048', '132', 'PIE', 'Pieta'),
('2049', '132', 'QOR', 'Qormi'),
('2050', '132', 'QRE', 'Qrendi'),
('2051', '132', 'RAB', 'Rabat'),
('2053', '99', 'TEL', 'Telangana'),
('2054', '1', 'JD', 'MD'),
('2055', '99', 'JH', 'Jharkhand');

### Structure of table `fa_kv_tour_request` ###

DROP TABLE IF EXISTS `fa_kv_tour_request`;

CREATE TABLE `fa_kv_tour_request` (
  `tr_id` int(11) NOT NULL,
  `tr_request_id` char(25) DEFAULT NULL,
  `tr_emp_desig_id` smallint(6) NOT NULL,
  `tr_emp_dept_id` smallint(6) NOT NULL,
  `tr_emp_desig_group_id` smallint(6) NOT NULL,
  `tr_employee_id` char(20) DEFAULT NULL,
  `tr_single_group` tinyint(1) NOT NULL,
  `tr_request_for` tinyint(1) NOT NULL,
  `tr_no_of_paxs` smallint(4) NOT NULL,
  `tr_request_date` date NOT NULL,
  `tr_place_of_visit` varchar(300) NOT NULL,
  `tr_fromdate` datetime NOT NULL,
  `tr_todate` datetime NOT NULL,
  `tr_no_of_days` smallint(3) NOT NULL,
  `tr_purpose_of_visit` varchar(1000) NOT NULL,
  `tr_transport_by_company` tinyint(1) NOT NULL,
  `tr_mode_of_transport` varchar(50) DEFAULT NULL,
  `tr_accommodation_by` tinyint(2) DEFAULT NULL,
  `tr_advance_required` decimal(10,2) DEFAULT NULL,
  `tr_advance_in` tinyint(2) DEFAULT NULL,
  `tr_comment_by_approval` varchar(500) DEFAULT NULL,
  `tr_status` tinyint(2) NOT NULL DEFAULT '1',
  `tr_attachment_path` varchar(300) DEFAULT NULL,
  `tr_added_date` datetime NOT NULL,
  `tr_last_updated` datetime DEFAULT NULL,
  `tr_updated_by` datetime DEFAULT NULL,
  PRIMARY KEY (`tr_id`),
  UNIQUE KEY `tr_request_id` (`tr_request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_tour_request` ###

INSERT INTO `fa_kv_tour_request` VALUES
('1', 'TR-01-2019-002', '1', '1', '1', 'EMP-S-002', '1', '1', '1', '2019-01-15', 'HYD', '2019-01-21 12:00:00', '2019-01-25 12:00:00', '5', 'Skill Development', '0', NULL, '1', '0.00', '1', 'Approved', '2', '2019/01/TR-01-2019-002.pdf', '2019-01-15 08:11:34', NULL, NULL);

### Structure of table `fa_kv_tour_requestform` ###

DROP TABLE IF EXISTS `fa_kv_tour_requestform`;

CREATE TABLE `fa_kv_tour_requestform` (
  `id` int(11) NOT NULL,
  `from_place` varchar(50) NOT NULL,
  `fdate_time` varchar(50) NOT NULL,
  `to_place` varchar(50) NOT NULL,
  `tdate_time` varchar(50) NOT NULL,
  `des_mode` varchar(50) NOT NULL,
  `class` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL,
  `updated_amount` float NOT NULL,
  `remark` varchar(50) NOT NULL,
  `file` varchar(50) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `tour_id` varchar(50) NOT NULL,
  `bill_id` varchar(50) NOT NULL,
  `submit_date` date NOT NULL,
  `status` int(10) NOT NULL DEFAULT '0',
  `admin_remark` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_tour_requestform` ###

INSERT INTO `fa_kv_tour_requestform` VALUES
('144', 'patna', '2019-07-05 10:05', 'Delhi', '2019-07-05 21:30', 'Flight', 'Eco', '5600', '5600', '', '', 'transport', 'TRD-07-2019-117', 'T_Bill_TRD-07-2019-117', '2019-07-05', '3', 'Approved'),
('145', 'Office dfs', '2019-08-26 09:00', 'PWC d', '2019-08-26 18:05', 'Bike df', '', '000', '0', 'Own Bike ert', '', 'conveyance', 'TRD-08-2019-118', 'T_Bill_TRD-08-2019-118', '2019-08-26', '0', NULL),
('146', 'patna', '2020-01-25 16:00', 'delhi', '2020-01-28 09:55', 'meeting', '', '1350', '0', '', '', 'food', 'TRD-01-2020-119', 'T_Bill_TRD-01-2020-119', '2020-01-27', '0', NULL);

### Structure of table `fa_kv_type_leave_master` ###

DROP TABLE IF EXISTS `fa_kv_type_leave_master`;

CREATE TABLE `fa_kv_type_leave_master` (
  `type_id` int(11) NOT NULL,
  `leave_type` varchar(120) NOT NULL,
  `desciption` text NOT NULL,
  `inactive` int(11) NOT NULL DEFAULT '0',
  `field_name` varchar(100) NOT NULL,
  `code` varchar(5) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_kv_type_leave_master` ###

INSERT INTO `fa_kv_type_leave_master` VALUES
('1', 'Casual Leave', 'Casual Leave', '0', '', 'CL'),
('2', 'Medical Leave', 'Medical Leave', '0', '', 'ML'),
('3', 'Vacation Leave', 'Vacation Leave', '0', '', 'VL'),
('4', 'Special Casual Leave', 'Special Casual Leave', '0', '', 'SCL'),
('5', 'Maternity Leave', 'Maternity Leave', '0', '', 'MTL'),
('6', 'Paternity leave', 'Paternity leave', '0', '', 'PTL'),
('7', 'Compensatory Leave', 'Comp off', '0', '', 'WO'),
('9', 'Half Day CL', 'Half Day Casual Leave', '0', '', 'HCL'),
('11', 'Earned Leave', 'Earned Leave', '0', '', 'EL');

### Structure of table `fa_loc_stock` ###

DROP TABLE IF EXISTS `fa_loc_stock`;

CREATE TABLE `fa_loc_stock` (
  `loc_code` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `stock_id` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `reorder_level` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`loc_code`,`stock_id`),
  KEY `stock_id` (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_loc_stock` ###


### Structure of table `fa_locations` ###

DROP TABLE IF EXISTS `fa_locations`;

CREATE TABLE `fa_locations` (
  `loc_code` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `location_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `delivery_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone2` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fax` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contact` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fixed_asset` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`loc_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_locations` ###

INSERT INTO `fa_locations` VALUES
('PAT', 'PATNA', '258 Nehru Nagar Patna 800013', '9835251162', '', '', '', 'Praveen', '0', '0');

### Structure of table `fa_maintenance_department` ###

DROP TABLE IF EXISTS `fa_maintenance_department`;

CREATE TABLE `fa_maintenance_department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `depart_id` int(11) NOT NULL,
  `desiggroup_id` int(11) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `empl_id` varchar(11) NOT NULL,
  `inactive` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_maintenance_department` ###


### Structure of table `fa_maintenance_help_desk` ###

DROP TABLE IF EXISTS `fa_maintenance_help_desk`;

CREATE TABLE `fa_maintenance_help_desk` (
  `help_id` int(11) NOT NULL AUTO_INCREMENT,
  `helpdesk_date` varchar(40) NOT NULL,
  `category` int(11) NOT NULL,
  `dept_id` int(11) NOT NULL,
  `desgroup_id` int(11) NOT NULL,
  `desig_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `stu_name` varchar(120) NOT NULL,
  `issues` text NOT NULL,
  `maintain_dept_id` int(11) NOT NULL,
  `status` int(2) NOT NULL,
  `inactive` int(11) NOT NULL,
  PRIMARY KEY (`help_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 ;

### Data of table `fa_maintenance_help_desk` ###

INSERT INTO `fa_maintenance_help_desk` VALUES
('1', '01/16/2019', '1', '1', '2', '3', '0', '', 'Battery backup issue', '1', '0', '0'),
('2', '21-01-2020', '1', '1', '2', '3', '0', '', '', '1', '0', '0'),
('3', '21-01-2020', '1', '2', '7', '15', '0', '', 'xghfgh', '2', '0', '0'),
('4', '27-01-2022', '1', '1', '1', '1', '0', '', 'System Not Working', '0', '0', '0'),
('5', '08-02-2022', '1', '1', '2', '3', '0', '', 'System not working', '9', '0', '0');

### Structure of table `fa_manual_sal_deduction` ###

DROP TABLE IF EXISTS `fa_manual_sal_deduction`;

CREATE TABLE `fa_manual_sal_deduction` (
  `id` int(10) NOT NULL,
  `leave_type` int(10) NOT NULL,
  `leave_count` float(4,1) NOT NULL DEFAULT '0.0',
  `leave_adjusted` float(4,1) NOT NULL DEFAULT '0.0',
  `days_deducted` float(4,1) NOT NULL DEFAULT '0.0',
  `updated_date` date NOT NULL,
  `added_date` date NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `empl_id` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_manual_sal_deduction` ###


### Structure of table `fa_movement_types` ###

DROP TABLE IF EXISTS `fa_movement_types`;

CREATE TABLE `fa_movement_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

### Data of table `fa_movement_types` ###

INSERT INTO `fa_movement_types` VALUES
('1', 'Local', '0'),
('2', 'User', '0');

### Structure of table `fa_name_return_master` ###

DROP TABLE IF EXISTS `fa_name_return_master`;

CREATE TABLE `fa_name_return_master` (
  `id` int(11) NOT NULL,
  `return_name` varchar(150) NOT NULL,
  `return_desc` varchar(150) NOT NULL,
  `inactive` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_name_return_master` ###

INSERT INTO `fa_name_return_master` VALUES
('1', 'Bihar Govt.', 'Bihar Govt. Dept.', '0'),
('2', 'Central Depts', 'Central Department', '0'),
('3', 'Income Tax', 'Income Tax Department', '0'),
('4', 'Company Registar', 'Company Registar', '0'),
('5', 'Quarterly Board Meeting', 'Quarterly Board Meeting', '0'),
('6', 'Monthly Board meeting', 'Monthly Board meeting', '0'),
('7', 'Monthly Review Meeting', 'Monthly Review Meeting', '0'),
('8', 'Monthly Team Meeting', 'Monthly Team Meeting', '1'),
('9', 'One', 'one teex', '0'),
('10', 'Two', 'sesdf', '0'),
('11', 'Yjty', 'tyty', '0');

### Structure of table `fa_overtime` ###

DROP TABLE IF EXISTS `fa_overtime`;

CREATE TABLE `fa_overtime` (
  `overtime_id` int(11) NOT NULL,
  `overtime_name` varchar(100) NOT NULL,
  `overtime_rate` float NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`overtime_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;

### Data of table `fa_overtime` ###


### Structure of table `fa_payment_terms` ###

DROP TABLE IF EXISTS `fa_payment_terms`;

CREATE TABLE `fa_payment_terms` (
  `terms_indicator` int(11) NOT NULL,
  `terms` char(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `days_before_due` smallint(6) NOT NULL DEFAULT '0',
  `day_in_following_month` smallint(6) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`terms_indicator`),
  UNIQUE KEY `terms` (`terms`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_payment_terms` ###

INSERT INTO `fa_payment_terms` VALUES
('1', 'Due 15th Of the Following Month', '0', '17', '0'),
('2', 'Due By End Of The Following Month', '0', '30', '0'),
('3', 'Payment due within 10 days', '10', '0', '0'),
('4', 'Cash Only', '1', '0', '0');

### Structure of table `fa_payroll_account` ###

DROP TABLE IF EXISTS `fa_payroll_account`;

CREATE TABLE `fa_payroll_account` (
  `account_id` int(11) NOT NULL,
  `account_code` int(11) NOT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;

### Data of table `fa_payroll_account` ###


### Structure of table `fa_payroll_structure` ###

DROP TABLE IF EXISTS `fa_payroll_structure`;

CREATE TABLE `fa_payroll_structure` (
  `salary_scale_id` int(11) NOT NULL,
  `payroll_rule` text NOT NULL,
  KEY `salary_scale_id` (`salary_scale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;

### Data of table `fa_payroll_structure` ###


### Structure of table `fa_payslip` ###

DROP TABLE IF EXISTS `fa_payslip`;

CREATE TABLE `fa_payslip` (
  `payslip_no` int(11) NOT NULL,
  `trans_no` int(11) NOT NULL DEFAULT '0',
  `emp_id` int(11) NOT NULL,
  `generated_date` date NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `leaves` int(11) NOT NULL,
  `deductable_leaves` int(11) NOT NULL,
  `payable_amount` double NOT NULL DEFAULT '0',
  `salary_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`payslip_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;

### Data of table `fa_payslip` ###


### Structure of table `fa_payslip_details` ###

DROP TABLE IF EXISTS `fa_payslip_details`;

CREATE TABLE `fa_payslip_details` (
  `payslip_no` int(11) NOT NULL,
  `detail` int(11) NOT NULL DEFAULT '0',
  `amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`payslip_no`,`detail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;

### Data of table `fa_payslip_details` ###


### Structure of table `fa_prevent_maintain_entry` ###

DROP TABLE IF EXISTS `fa_prevent_maintain_entry`;

CREATE TABLE `fa_prevent_maintain_entry` (
  `prevent_id` int(11) NOT NULL AUTO_INCREMENT,
  `maintain_date` varchar(30) NOT NULL,
  `utility_id` varchar(250) NOT NULL,
  `frequency_id` int(11) NOT NULL,
  `contractor_id` int(11) NOT NULL,
  `prv_ob_date` varchar(30) NOT NULL,
  `prv_ob_1` text NOT NULL,
  `prv_ob_2` text NOT NULL,
  `prv_ob_3` text NOT NULL,
  `status` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `sub_cat_id` int(11) NOT NULL,
  PRIMARY KEY (`prevent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

### Data of table `fa_prevent_maintain_entry` ###

INSERT INTO `fa_prevent_maintain_entry` VALUES
('1', '24-04-2023', 'AC-STAR-EMP-SPLIT', '1', '1', '24-04-2023', 'test', 'test', 'test', '0', '1', '45');

### Structure of table `fa_prevent_maintain_params` ###

DROP TABLE IF EXISTS `fa_prevent_maintain_params`;

CREATE TABLE `fa_prevent_maintain_params` (
  `param_id` int(11) NOT NULL AUTO_INCREMENT,
  `prevent_id` int(11) NOT NULL,
  `parameters` int(11) NOT NULL,
  PRIMARY KEY (`param_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

### Data of table `fa_prevent_maintain_params` ###

INSERT INTO `fa_prevent_maintain_params` VALUES
('1', '1', '1');

### Structure of table `fa_prevent_new_items` ###

DROP TABLE IF EXISTS `fa_prevent_new_items`;

CREATE TABLE `fa_prevent_new_items` (
  `new_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `prevent_id` int(11) NOT NULL,
  `n_item` varchar(100) NOT NULL,
  `n_qty` float NOT NULL,
  `n_bill_date` varchar(30) NOT NULL,
  `n_billno` varchar(100) NOT NULL,
  `n_contractor` varchar(100) NOT NULL,
  `n_comments` text NOT NULL,
  PRIMARY KEY (`new_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_prevent_new_items` ###


### Structure of table `fa_preventmaintain_entry_items` ###

DROP TABLE IF EXISTS `fa_preventmaintain_entry_items`;

CREATE TABLE `fa_preventmaintain_entry_items` (
  `items_id` int(11) NOT NULL AUTO_INCREMENT,
  `prevent_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `sub_cat_id` int(11) NOT NULL,
  `item_id` varchar(100) NOT NULL,
  `quantity` float NOT NULL,
  `stock_qty` float NOT NULL,
  PRIMARY KEY (`items_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

### Data of table `fa_preventmaintain_entry_items` ###

INSERT INTO `fa_preventmaintain_entry_items` VALUES
('1', '1', '0', '0', 'Select', '0', '0');

### Structure of table `fa_prices` ###

DROP TABLE IF EXISTS `fa_prices`;

CREATE TABLE `fa_prices` (
  `id` int(11) NOT NULL,
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sales_type_id` int(11) NOT NULL DEFAULT '0',
  `curr_abrev` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `price` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `price` (`stock_id`,`sales_type_id`,`curr_abrev`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_prices` ###

INSERT INTO `fa_prices` VALUES
('0', '003', '1', 'INR', '500');

### Structure of table `fa_print_profiles` ###

DROP TABLE IF EXISTS `fa_print_profiles`;

CREATE TABLE `fa_print_profiles` (
  `id` smallint(6) unsigned NOT NULL,
  `profile` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `report` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `printer` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `profile` (`profile`,`report`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_print_profiles` ###


### Structure of table `fa_printers` ###

DROP TABLE IF EXISTS `fa_printers`;

CREATE TABLE `fa_printers` (
  `id` tinyint(3) unsigned NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `queue` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `host` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `port` smallint(11) unsigned NOT NULL,
  `timeout` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_printers` ###

INSERT INTO `fa_printers` VALUES
('1', 'QL500', 'Label printer', 'QL500', 'server', '127', '20'),
('2', 'Samsung', 'Main network printer', 'scx4521F', 'server', '515', '5'),
('3', 'Local', 'Local print server at user IP', 'lp', '', '515', '10');

### Structure of table `fa_process_maintain_params` ###

DROP TABLE IF EXISTS `fa_process_maintain_params`;

CREATE TABLE `fa_process_maintain_params` (
  `param_id` int(11) NOT NULL AUTO_INCREMENT,
  `process_id` int(11) NOT NULL,
  `parameters` int(11) NOT NULL,
  PRIMARY KEY (`param_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_process_maintain_params` ###


### Structure of table `fa_process_maintenance` ###

DROP TABLE IF EXISTS `fa_process_maintenance`;

CREATE TABLE `fa_process_maintenance` (
  `process_id` int(11) NOT NULL AUTO_INCREMENT,
  `maintain_date` varchar(30) NOT NULL,
  `utility_id` int(11) NOT NULL,
  `frequency_id` int(11) NOT NULL,
  `contractor_id` int(11) NOT NULL,
  `ob_date` varchar(30) NOT NULL,
  `ob_1` varchar(200) NOT NULL,
  `ob_2` varchar(200) NOT NULL,
  `ob_3` varchar(200) NOT NULL,
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`process_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_process_maintenance` ###


### Structure of table `fa_process_maintenance_items` ###

DROP TABLE IF EXISTS `fa_process_maintenance_items`;

CREATE TABLE `fa_process_maintenance_items` (
  `items_id` int(11) NOT NULL AUTO_INCREMENT,
  `process_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `sub_cat_id` int(11) NOT NULL,
  `item_id` varchar(150) NOT NULL,
  `quantity` float NOT NULL,
  `stock_qty` float NOT NULL,
  PRIMARY KEY (`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_process_maintenance_items` ###


### Structure of table `fa_processmaintain_new_items` ###

DROP TABLE IF EXISTS `fa_processmaintain_new_items`;

CREATE TABLE `fa_processmaintain_new_items` (
  `new_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `process_id` int(11) NOT NULL,
  `n_item` varchar(100) NOT NULL,
  `n_qty` float NOT NULL,
  `n_bill_date` varchar(30) NOT NULL,
  `n_billno` varchar(100) NOT NULL,
  `n_contractor` varchar(100) NOT NULL,
  `n_comments` text NOT NULL,
  PRIMARY KEY (`new_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_processmaintain_new_items` ###


### Structure of table `fa_product_master` ###

DROP TABLE IF EXISTS `fa_product_master`;

CREATE TABLE `fa_product_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(100) NOT NULL,
  `inactive` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

### Data of table `fa_product_master` ###

INSERT INTO `fa_product_master` VALUES
('1', 'South Block', '', '0');

### Structure of table `fa_publisher` ###

DROP TABLE IF EXISTS `fa_publisher`;

CREATE TABLE `fa_publisher` (
  `pub_id` int(11) NOT NULL,
  `pub_code` varchar(50) NOT NULL,
  `pub_name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`pub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;

### Data of table `fa_publisher` ###

INSERT INTO `fa_publisher` VALUES
('1', 'BB', 'BHARTI BHAVAN', '1'),
('2', 'SCC', 'S.CHAND &amp; COMPANY', '1'),
('3', 'EPH', 'EURASIA PUB HOUSE', '1'),
('4', 'N', 'NCERT', '1'),
('5', 'PRP', 'PRACHI PUBLICATION', '1'),
('6', 'SOP', 'SOUVENIR PUB', '1'),
('7', 'TRB', 'TRUMAN BOOK CO', '1'),
('8', 'PRA', 'PRADEEP PUB', '1'),
('9', 'DRC', 'DHANPAT RAI &amp; CO', '1'),
('10', 'RKP', 'RAJ KAMAL PRAKASHAN', '1'),
('11', 'RP', 'RADHAKRISHN PRAKASHN', '1'),
('12', 'LOK', 'LOK BHARTI', '1'),
('13', 'BEB', 'BEST BOOK PUB', '1'),
('14', 'RS', 'RACHANA SAGAR', '1'),
('15', 'EP', 'EVERGREEN PUBLICATION', '1'),
('16', 'OUP', 'OXFORD UNIVERSITY PRESS', '1'),
('17', 'SCH', 'SULTAN CHAND', '1'),
('18', 'SWH', 'SARASWATI HOUSE', '1'),
('19', 'SRI', 'SRIJAN PUBLICATION', '1'),
('20', 'OAS', 'OASIS EDUCATIONAL SERVICES P L', '1'),
('21', 'HIN', 'HOLIFAITH INTER NATIONAL', '1'),
('22', 'CBS', 'C.B.S.EDUCATION', '1'),
('23', 'GR1', 'G R BATHLA &amp; SONS', '1'),
('24', 'JWS', 'JOHN WELL &amp;SONS CO', '1'),
('25', 'MOP', 'MODERN PUBLICATION', '1'),
('26', 'PE2', 'PEARSON EDUCATION', '1'),
('27', 'GKB', 'G.K.BATHLA &amp; SONS', '1'),
('28', 'TMH', 'TMH', '1'),
('29', 'TRU', 'TRUMANS PUBLICATION', '1'),
('30', 'SC1', 'S CHAND &amp; CO', '1'),
('31', 'PTP', 'PITAMBER PUBLICATION', '1'),
('32', 'RAT', 'RATNA SAGAR', '1'),
('33', 'HFT', 'HOLI FAITH', '1'),
('34', 'AP7', 'ARCHANA PRAKASHAN', '1'),
('36', 'LUX', 'LUXMI PUBLICATION', '1'),
('37', 'MBT', 'MBT  N DELHI', '1'),
('38', 'NP', 'NAVDEEP PUBLICATION', '1'),
('39', 'GOY', 'GOYAL PUB', '1'),
('40', 'NEP', 'NEELAM PUBLICATION', '1'),
('41', 'LAX', 'LAXMI PUBLICATION', '1'),
('42', 'PP', 'PITAMBER PRAKASHAN', '1'),
('43', 'OP', 'OSWAL PUBLICATION', '1'),
('44', 'SA2', 'SARASWATI', '1'),
('45', 'OXU', 'OXFORD UNIVERSIT PRESS', '1'),
('46', 'OES', 'OASI EDUCATIONAL SERVICE LTD', '1'),
('47', 'GPP', 'GONAL PRINTER &amp; PUBLICATION', '1'),
('48', 'SDS', 'SHIV DAS &amp; SONS', '1'),
('49', 'MB3', 'MBD', '1'),
('50', 'JP1', 'JIWAN PUBLICATION', '1'),
('51', 'ASP', 'ASHOKA PUBLISHING HOUSE', '1'),
('52', 'YP', 'YURESHIYA PUBLISHING', '1'),
('53', 'APB', 'ARYA PUBLICATION', '1'),
('54', 'GB', 'GOYAL BROTHERS', '1'),
('55', 'ABD', 'ARYA BOOK DEPOT', '1'),
('56', 'SAC', 'SULTANCHAND AND COMPANY', '1'),
('57', 'TMP', 'TATA MACROHILL PUBLICATION', '1'),
('58', 'VI2', 'VIDYA PRAKASHAN', '1'),
('59', 'KM', 'KITAB MAHAL', '1'),
('60', 'S&amp;P', 'SUCHNA &amp; PRASARAN MANTRALAY', '1'),
('61', 'IEE', 'INDIAN EDULT EDU ASSCIATION', '1'),
('62', 'IIO', 'INDIAN INSTI OF PUBL ADM', '1'),
('63', 'NBC', 'NALANDA BOOK CENTER', '1'),
('64', 'CSD', 'COOPRATIVE &amp; SUGARCAME DEPT', '1'),
('65', 'GPL', 'GYANPETH PVT LTD', '1'),
('66', 'TLA', 'THE LIBRAL ART PRESS', '1'),
('67', 'PB5', 'PIRAMID BOOK', '1'),
('68', 'VP9', 'VEENA PUSTAK MANDIR', '1'),
('69', 'IP', 'INTERNATIONAL PRAKASHAN', '1'),
('70', 'FLP', 'FOREIGN LANGUAGE PUBLICATION', '1'),
('71', 'NB1', 'NBT', '1'),
('72', 'OT', 'ORRISA TOURISM', '1'),
('73', 'LPP', 'LUXMI PUSTKALAY PATNA', '1'),
('74', 'RPV', 'RAMESHWAR PRASAD VISHWABANDHU', '1'),
('75', 'SF', 'STUDENT FRENDS', '1'),
('76', 'CBE', 'C B S E N D', '1'),
('77', 'BLO', 'BLOSSOMS', '1'),
('78', 'AB2', 'ARYA BOOK DEPO', '1'),
('79', 'JSW', 'JANMUKTI SANGHARSH WAHINI', '1'),
('80', 'SPM', 'SHARMA PUSTAK MANDIR', '1'),
('81', 'SJC', 'SARAN JELA CONGRES S S SAMITI', '1'),
('82', 'ADP', 'ADHUNIK PRAKASHAN', '1'),
('83', 'RP;', 'RADHA PUBLICATION', '1'),
('84', 'KN', 'KALA NIKETAN', '1'),
('85', 'HMK', 'HND MADHYAM KARYANWAYN NIDESH', '1'),
('86', 'SA5', 'SAHITYAGAR', '1'),
('87', 'PP;', 'PEPULAS PUBLICATION HOUSE', '1'),
('88', 'SP.', 'SHAYAM PRAKASHAN', '1'),
('89', 'W&amp;C', 'WADHA &amp; CO', '1'),
('90', 'SPU', 'SAHETYA BHAWAN PUB', '1'),
('91', 'NPP', 'NOVOSTI PRESS PUBLISHING', '1'),
('92', 'P&amp;S', 'PRAKASH &amp; SANS', '1'),
('93', 'WI', 'WILY INDIA', '1'),
('94', 'CBC', 'CHILDREN BOOK CENTRE', '1'),
('95', 'PR2', 'PREMIER PUBLICATION', '1'),
('96', 'ALP', 'ALLIED PUBLICATION', '1'),
('97', 'PI', 'PRACHI INDIA', '1'),
('98', 'D&amp;C', 'DINESH &amp; CO', '1'),
('99', 'BR2', 'BIHAR RASTRABHASA PARESAD', '1'),
('100', 'GS2', 'GANDHI SANGHRALAY', '1'),
('101', 'NBT', 'NATIONAL BOOK TRUST', '1'),
('102', 'AP6', 'ARAVIND PRAKASHAN', '1'),
('103', 'RP\\', 'RAJA POCKET BOOKS', '1'),
('104', 'ABK', 'AKHIL BHARTIYA KALA KENDRA', '1'),
('105', 'SS8', 'S SAHJANAND S', '1'),
('106', 'PB6', 'PRAKASHAN BIBHAG', '1'),
('107', 'UP2', 'UMESH PRAKASHAN', '1'),
('108', 'ORL', 'ORIENT LANGMAN', '1'),
('109', 'RK.', 'RADHA KRISHAN PRAKASHAN', '1'),
('110', 'SP&#039;', 'SHAKTI PRAKASHAN', '1'),
('111', 'RKN', 'RAMKRISHNA MATH', '1'),
('112', 'R&amp;S', 'RAJPAL &amp; SONS', '1'),
('113', 'PD', 'PUBLICATION DEVISION', '1'),
('114', 'ANP', 'ANAMIKA PUBLISHERS', '1'),
('115', 'LBP', 'LOK BHARTI PRAKASHAN', '1'),
('116', 'JKP', 'J K PRINTERS', '1'),
('117', 'SS0', 'SARWODAY SAHITYA PUB', '1'),
('118', 'SAA', 'SAHITY AKADAMI', '1'),
('119', 'HP5', 'HIND POCKET BOOKS', '1'),
('120', 'SPH', 'SCHOLAR PUBLISHING HOUSE', '1'),
('121', 'BVB', 'BAL VIGYAN BHARATI', '1'),
('122', 'HPP', 'HINDI PRACHARAK PRAKASHAN', '1'),
('123', 'NPH', 'NATIONAL PUBLIC HOUSE', '1'),
('124', 'MAH', 'MAHESH PRAKASHAN', '1'),
('125', 'RKM', 'RAM KRISHN MATH', '1'),
('126', 'PP2', 'PRABHAT PRAKASHAN', '1'),
('127', 'RH', 'RAJ PUB. HOUSE', '1'),
('128', 'TAR', 'TARUN PUB', '1'),
('129', 'AP2', 'ARTI PRAKAHAN', '1'),
('130', 'GK', 'GRANTHMALA KARYALAY', '1'),
('131', 'AP8', 'ASHOK PRAKASHAN', '1'),
('132', 'RAN', 'RANJAN PRAKASHAN', '1'),
('133', 'SP', 'SAKUN PRAKASHAN', '1'),
('134', 'BSP', 'BAL SAHITY PRAKASHAN', '1'),
('135', 'SS5', 'SUBODH SAHITYA PRAKASHAN', '1'),
('136', 'PC', 'PRACHARAK CLUB', '1'),
('137', 'BHG', 'BIHAR HINDI GRANTH AKADAMI', '1'),
('138', 'APG', 'ASHA PRAKASHAN GREH', '1'),
('139', 'SB3', 'SARASWATI BHANDAR', '1'),
('140', 'BN', 'BHARTI NIKETAN', '1'),
('141', 'OP5', 'OJHA PRAKASHAN', '1'),
('142', 'BPH', 'BHARAT PUB HOUSE', '1'),
('143', 'VP', 'VIKASH PRAKASHAN', '1'),
('144', 'PPO', 'POONAM PRAKASHAN MANDIR', '1'),
('145', 'NP1', 'NAGRI PRACHARNI SANSTHA', '1'),
('146', 'RB2', 'REGAL BOOK DEPO', '1'),
('147', 'KP', 'KRITI PRAKAHAN', '1'),
('148', 'AVI', 'AVICHAL PUB HOUSE', '1'),
('149', 'BW', 'BROWN WATSON', '1'),
('150', 'GOO', 'GOODWILL PUB.', '1'),
('151', 'H', 'HEINEMAN', '1'),
('152', 'BPM', 'BINOD PUSTAK MANDIR', '1'),
('153', 'KHS', 'KENDRIYA HINDI SANSTHAN', '1'),
('154', 'RAH', 'RAHUL PRAKASHAN', '1'),
('155', 'MB2', 'MALHOTRA BOOK DEPOT', '1'),
('156', 'PS6', 'PRAKASAN SANSTHAN', '1'),
('157', 'GM', 'GOOD MAN', '1'),
('158', 'HPC', 'HINDI PRAKASHAN CHAPRA', '1'),
('159', 'SS6', 'SANGET SADAN PRAKASHAN', '1'),
('160', 'GG', 'GANGA GRAMASAR', '1'),
('161', 'RP-', 'RUBY PRAKASHAN', '1'),
('162', 'DFB', 'DELHI FOOD BOOK CENTER', '1'),
('163', 'HP3', 'HINDI POCKET BOOKS', '1'),
('164', 'PUR', 'PURWANCHAL PRAASHAN', '1'),
('165', 'RAA', 'R S A A PRAKASAN', '1'),
('166', 'BGN', 'BHARTIYA GRAM NIKETAN', '1'),
('167', 'HPS', 'HINDI PRCHARAK SANKHYA', '1'),
('168', 'BG2', 'BHARTIYA GRANTH NIKETAN', '1'),
('169', 'RAS', 'RAJPAL AND SANS', '1'),
('170', 'MPW', 'MAYUR PAPER WORKS', '1'),
('171', 'PP.', 'PREM PRAKASAN MANDER', '1'),
('172', 'ASH', 'ASHA PRAKASHAN', '1'),
('173', 'SS', 'SAHITY SADAN', '1'),
('174', 'DP9', 'DHINGRA PUB HOUSE', '1'),
('175', 'SAH', 'SAHNI PUBLICATION', '1'),
('176', 'PM', 'PUSTAK MAHAL', '1'),
('177', 'JP4', 'JAWAHAR PRAKASHAN', '1'),
('178', 'PG', 'PRACHARAK GRANTHAWALI', '1'),
('179', 'VM', 'VANI MANDIR', '1'),
('180', 'ABP', 'ABHIWAYAKTI PRAKASHAN', '1'),
('181', 'PS', 'PRAKASHAN SANSTHAN', '1'),
('182', 'USA', 'U S A INTERNATIONAL', '1'),
('183', 'GP2', 'GYANDA PRAKASHAN', '1'),
('184', 'SP[', 'SOWENIYAR PUBLICATION', '1'),
('185', 'AP;', 'AMIT PRAKASHA', '1'),
('186', 'HPB', 'HINDI PAKET BOOKS', '1'),
('187', 'SS3', 'SAHITYA SGAR', '1'),
('188', 'SUK', 'SUKRITI PRAKASHAN', '1'),
('189', 'RP1', 'RAJKAMAL PRAKASHAN', '1'),
('190', 'FRA', 'FRANK BROS &amp; CO', '1'),
('191', 'BS2', 'BAL SADAN', '1'),
('192', 'PP&#039;', 'PARAG PRAKASHAN', '1'),
('193', 'RK3', 'RADHA KRISHN PRAKASHAN', '1'),
('194', 'RNB', 'RASTREYA NATYA BIDYALAY', '1'),
('195', 'RST', 'RAJENDRA SMARAK TRUST', '1'),
('196', 'JEV', 'JEEVAN PRAKASHAN', '1'),
('197', 'BC5', 'BRIGHT CAREAR', '1'),
('198', 'SD1', 'S DINESH &amp; CO', '1'),
('199', 'SON', 'SONI PUBLICATION', '1'),
('200', 'NCT', 'N C E R T', '1'),
('201', 'CSL', 'CURENT SAENTEFIC LITRECHER', '1'),
('202', 'HP4', 'HIMACHAL PUSTAK BHANDAR', '1'),
('203', 'AP0', 'ANKUR PRAKASHAN', '1'),
('204', 'SPT', 'SMT PARMATMA TAPOVAN', '1'),
('205', 'VP2', 'VANI PRAKASHAN', '1'),
('206', 'SPA', 'SAHITYANJALI PRA ALLAHABAD', '1'),
('207', 'SK', 'SANGET KARYALAY', '1'),
('208', 'HP2', 'HEM PRAKASHAN', '1'),
('209', 'ALK', 'ALKA PRAKASHAN', '1'),
('210', 'DPB', 'DAYMAND PAKET BOOK', '1'),
('211', 'MB6', 'MITTAL BOOK DEPO', '1'),
('212', 'CB2', 'COSMOS BOOKLINE', '1'),
('213', 'CBL', 'COSMOS BOOK LINE', '1'),
('214', 'JCP', 'JAY CEE PUBLICATION', '1'),
('215', 'VP1', 'VOHRA PUBLISHERS', '1'),
('216', 'AP&#039;', 'ACADEMIC PUBLICATION', '1'),
('217', 'SEP', 'SEASONS PUBLICATION', '1'),
('218', 'JM', 'JEEVAN MANDIR', '1'),
('219', 'KNF', 'KAPITAL NEWS &amp; FEATURS', '1'),
('220', 'SP5', 'SAHITY PARIHAD', '1'),
('221', 'GM2', 'GYAN MANDIR', '1'),
('222', 'PR4', 'PRAGATI PRAKASHAN', '1'),
('223', 'PB7', 'PRAKASHAN BIBHAG S &amp; P M', '1'),
('224', 'SSS', 'SARV SEVA SANGH PRAKASHAN', '1'),
('225', 'BTA', 'BHEKHARI THAKUR ASRAM', '1'),
('226', 'GJS', 'GANDHI JANM SHATABDI S G PRA', '1'),
('227', 'SB', 'SHIKSHA BHARATI', '1'),
('228', 'ANU', 'ANUPAM PRAKASHAN', '1'),
('229', 'RBP', 'RASTRA BHASA PRAKASHAN', '1'),
('230', 'RDG', 'RAMJEEDAS GUPTA', '1'),
('231', 'KB1', 'KABIR BICHAR', '1'),
('232', 'CBT', 'CHILDREN BOOK TRUST', '1'),
('233', 'BSM', 'BHARATIYAN SAHITY MANDIR', '1'),
('234', 'MAM', 'MAC MILLIAM', '1'),
('235', 'LP1', 'LEARNER PRESS', '1'),
('236', 'V', 'VARUN PUBLICATION', '1'),
('237', 'SP+', 'SHYAM PRAKASHAN', '1'),
('238', 'M&amp;G', 'MORRISON &amp; GISS LTD', '1'),
('239', 'OPB', 'ORIENT PAPER BOOKS', '1'),
('240', 'ABH', 'ABHAY PUBLICATION', '1'),
('241', 'BVP', 'BHARTIYA VIDYA PUBLICATION', '1'),
('242', 'INW', 'IVOR NICHOLSON &amp; WATSON', '1'),
('243', 'GGH', 'GEORGE G HARRAP CO LTD', '1'),
('244', 'TNS', 'THOMAS NELSON &amp; SONS LTD', '1'),
('245', 'GS1', 'GHANSHYAM SAHAN', '1'),
('246', 'RMV', 'RAMKRISHN MISHAN VIVEKANAND', '1'),
('247', 'TS5', 'THE STUDENT STERES', '1'),
('248', 'NJP', 'NAV JEEVAN PUBLICATION', '1'),
('249', 'FL1', 'FOREIGN LANGUAGE PUBLI', '1'),
('250', 'NB2', 'NEW BOOK COMPENY', '1'),
('251', 'UP', 'UNIVERSITY PRESS', '1'),
('252', 'VPB', 'VIKING PONGUIN BOOKS INDIA', '1'),
('253', 'DP6', 'DAYNAMIC PRAKASHAN', '1'),
('254', 'RB', 'ROLI BOOKS', '1'),
('255', 'DWS', 'DR WULKE SMIRTI GRANTH SAMITE', '1'),
('256', 'SS-', 'S S S HETKARI SAMAJ', '1'),
('257', 'HP7', 'HINDI PRACHARAK PUB PVT LTD', '1'),
('258', 'VPD', 'VOHRA PUB &amp; DISTEBUTERS', '1'),
('259', 'BST', 'BIHAR STATE TEST BOOK PUB CORP', '1'),
('260', 'MAD', 'MAHANT AWADHESNATH D N DAS', '1'),
('261', 'JSM', 'JEEVAN SEKSHA MUDRANALAY', '1'),
('262', 'P&amp;', 'PRASAD &amp; SANTATI', '1'),
('263', 'KAP', 'KAMAL PRAKASHAN', '1'),
('264', 'RPB', 'RAJA PAKE BOOKS', '1'),
('265', 'BB3', 'BISHWA BIJAY PRAKASHAN', '1'),
('266', 'RV', 'RAWANG VILAS', '1'),
('267', 'DB', 'DAYMOND BOOKS', '1'),
('268', 'MP1', 'MARUTI PRAKASH', '1'),
('269', 'NL2', 'NEW LIGHT PUB', '1'),
('270', 'TTP', 'TINY TOT PUBLICATION', '1'),
('271', 'SC4', 'SCHOLASTIC', '1'),
('272', 'R&amp;C', 'RUPA &amp; CO', '1'),
('273', 'PUF', 'PUFFIN', '1'),
('274', 'SRS', 'SHRISTI PUB', '1'),
('275', 'PP', 'PROGRESS PUBLICATION', '1'),
('276', '', 'RADUGA PUBLICATION', '1'),
('277', 'RP2', 'DHINGRA PUBLICATION', '1'),
('278', 'DP', 'LEARNERS PRES PVT LTD', '1'),
('279', 'LP5', 'REBO PUBLICATION', '1'),
('280', 'REP', 'OUATEL BOOKS LTD', '1'),
('281', 'OBL', 'WALDMAN &amp; SONS', '1'),
('282', 'W&amp;S', 'A TEMPLAR BOOK', '1'),
('283', 'ATB', 'GUL MOHAR ORIENT LONGMAN', '1'),
('284', 'GMO', 'MANOJ PAKET BOOKS', '1'),
('285', 'MPB', 'RAM NARAYAN LAL BENI PD', '1'),
('286', 'RNL', 'FATHES MULARS HOMEO POER DESP', '1'),
('287', 'HMH', 'U P HND GRANTH AKADMI', '1'),
('288', 'UPH', 'J &amp; J D KAME LABOURATERY', '1'),
('289', 'J&amp;J', 'MACMILLAN INDIA', '1'),
('290', 'MI', 'MANISHA', '1'),
('291', 'MAN', 'AFFILIATED CASWEST PRES P LTD', '1'),
('292', 'ACP', 'NATIONAL ACADEMY OF SC', '1'),
('293', 'NAO', 'MAYA PRAKASHAN', '1'),
('294', 'MP9', 'H B C FOR SC ED', '1'),
('295', 'HB2', 'SHEKHAR PHATAK &amp; ASO', '1'),
('296', 'SP&amp;', 'RASTREYA VIG &amp; PRO SAN PARESA', '1'),
('297', 'HVP', 'WAWLENTERY H ASSO OF INDIA', '1'),
('298', 'WHI', 'VIGYAN PRASAR', '1'),
('299', 'VIP', 'SHRIJ BINDESHWARI SINGH', '1'),
('300', 'SB7', 'MODERN PAPER BOOKS', '1'),
('301', 'MP7', 'JAGAT SANKHDHER', '1'),
('302', 'JS', 'THE ENGLISH BOOK DEPO', '1'),
('303', 'TEB', 'D B TARAPELA &amp; OTHERS', '1'),
('304', 'DBT', 'ROUTLDGE &amp; KEGAN PAUL  LTD', '1'),
('305', 'R&amp;K', 'RAJSTHAN PRAKASHAN', '1'),
('306', 'RS5', 'MITCHELL BEAZLEY', '1'),
('307', 'MB5', 'HEALTH HARNONY', '1'),
('308', 'HH1', 'NARSERY PUBLICATION HOME', '1'),
('309', 'NP3', 'KIRAN PUB', '1'),
('310', 'KP6', 'STERLING PUB', '1'),
('311', 'SP', 'UNIVERN BOOKS', '1'),
('312', '', 'SASTA SAHITYA MANDAL', '1'),
('313', 'UB2', 'NEW SAHETYA', '1'),
('314', 'SSM', 'GERG BROTHERS', '1'),
('315', 'NS2', 'MOTILAL VANARASI DAS', '1'),
('316', 'GB2', 'ATMARAM &amp; SONS', '1'),
('317', 'MVD', 'PENGUIN BOOK DEPO', '1'),
('318', 'A&amp;S', 'IROR NICHOLSAN WATSEN', '1'),
('319', 'PB8', 'GANDHI S P V A P KENDRA', '1'),
('320', 'IN1', 'GHUGH PUBLICATION', '1'),
('321', 'GSP', 'JANKI PRAKASHAN', '1'),
('322', 'GP3', 'I I OF I TRADE', '1'),
('323', 'JP6', 'INTERNATIONAL LAW ASSOCEATION', '1'),
('324', 'II1', 'CRONECAL BOOKS', '1'),
('325', 'ILA', 'MALYALA MANORAMA COMPANY', '1'),
('326', 'CB4', 'MINESTRY OF FINANSE', '1'),
('327', 'MMC', 'NEW VEKASH PUB', '1'),
('328', 'MOF', 'GAURAV PUB HOUSE', '1'),
('329', 'NV2', 'MANNU GRAPHIC', '1'),
('330', 'GPH', 'I C O A R', '1'),
('331', 'MG', 'GAURAV PUB.', '1'),
('332', 'ICO', 'BHOOMGUSY PUB', '1'),
('333', 'GAU', 'SHAYAM PRESS', '1'),
('334', 'BGP', 'ENCYCLOPAEDIA BRITANICA', '1'),
('335', 'SH1', 'BRIJBASI ART PRESS', '1'),
('336', 'ENC', 'PENTAGON PRESS', '1'),
('337', 'BAP', 'GOODS &amp; GROES', '1'),
('338', 'PEN', 'PARRAGAN PUBLIHING', '1'),
('339', 'G&amp;G', 'POPULAR PRAKASHAN', '1'),
('340', 'PP3', 'ARUN SHOURIE', '1'),
('341', 'PP1', 'SARAN JILA BHAJPA', '1'),
('342', 'AS5', 'LIONS CLUB CHAPRA', '1'),
('343', 'SJB', 'JAGDAM MAHAVIDYALAY', '1'),
('344', 'LCC', 'VISHWAJEET COMPUTER', '1'),
('345', 'JM1', 'RAJYA STAREYA BAL VIGYAN', '1'),
('346', 'VC', 'AKHAND MAHAYOG SANSTHAN', '1'),
('347', 'RSB', 'BHARGAW BOOK DEPO', '1'),
('348', 'AMS', 'SHAHNI PUB', '1'),
('349', 'BBD', 'ANMOL PUB', '1'),
('350', 'SP]', 'LANDMARK BOOKS', '1'),
('351', 'ANM', 'SAHNI BROTHERS', '1'),
('352', 'LAN', 'THE STUDENT STORES', '1'),
('353', 'SBR', 'WORDS WORTH CLAME', '1'),
('354', 'TS1', 'WATERMILL CLAMEC', '1'),
('355', 'WWE', 'PINKY BOOK DISTRIBUTORS', '1'),
('356', 'WC', 'KRISHNAMURTI FOUNDATION INDIA', '1'),
('357', 'PBD', 'ARCLAIBALD CONSTABLE', '1'),
('358', 'KFI', 'PARICHAY OVERSEN', '1'),
('359', 'AC', 'UBS PUB DISTRIBUTION', '1'),
('360', 'PO', 'SURJEET PUB', '1'),
('361', 'UPD', 'JAICO PUBLICATION', '1'),
('362', 'SUR', 'HARPER COLLINS PUBLICATION', '1'),
('363', 'JP5', 'HARCOURT BRAK &amp; COMPANY', '1'),
('364', 'HCP', 'VIKING', '1'),
('365', 'HB7', 'WORDS WORTH CLANIC', '1'),
('366', 'VIK', 'RADHA PUB HOUSE', '1'),
('367', 'WWC', '2M PUBLICATION HOUSE', '1'),
('368', 'R P', 'BLOOMSBURY', '1'),
('369', '2MP', 'VIDYA BIHAR', '1'),
('370', 'BL2', 'MAHESHWARI BEERCHAND MISHR', '1'),
('371', 'VB', 'RAJHANSH PRAKASHAN', '1'),
('372', 'MBM', 'LOKBHRATI PRAKASHAN', '1'),
('373', 'RP8', 'GREMRATNEM', '1'),
('374', 'LP', 'MADHUBAN PUBLI', '1'),
('375', 'GRE', 'GOLDEN G PUB.', '1'),
('376', 'MP5', 'DREAM LAND PUB', '1'),
('377', 'GOP', 'SIKSHA BHARTI', '1'),
('378', 'DL1', 'ATUL PUB', '1'),
('379', 'SB5', 'UNICORN BOOKS', '1'),
('380', 'ATU', 'BPB PUB', '1'),
('381', 'UB', 'PRENTIS HALL OF INDIA', '1'),
('382', 'BPB', 'NAVDEEP PRAKASHAN', '1'),
('383', 'PHO', 'TARAN PRAKASHAN', '1'),
('384', 'NAP', 'THREE STAR PUB', '1'),
('385', 'TRP', 'FLAMING BOOKS', '1'),
('386', 'THS', 'ARTI PUBLICATION', '1'),
('387', 'FLB', 'PRACHI INDIA LTD', '1'),
('388', 'ART', 'G G P', '1'),
('389', 'PIL', 'POCKET BOOKS', '1'),
('390', 'GGP', 'HENRY FROWDE', '1'),
('391', 'POB', 'INDIAN ACADIMY OF SCIENCE', '1'),
('392', 'HF', 'THE NATIONAL ACADMEY OF SCI', '1'),
('393', 'ICS', 'MINISTRY OF NONCONVEN ENE SOU', '1'),
('394', 'TNA', 'NELKAMAL PUBLICATION', '1'),
('395', 'MON', 'SOCIETY OF LIFE SCIENCE', '1'),
('396', 'NKP', 'CONSTABLE &amp; CO', '1'),
('397', 'SOL', 'GRAND RICHERDS', '1'),
('398', 'C&amp;C', 'REDFOX', '1'),
('399', 'GR', 'CROST PUB HOUSE', '1'),
('400', 'RED', 'TANNU BOOKS', '1'),
('401', 'CP2', 'UBS PUBLICATION', '1'),
('402', 'TB', 'PURNELL BOOK PREDUETION', '1'),
('403', 'UBS', 'BOOK PALACE', '1'),
('404', 'PB0', 'A WATERMIL CLAMIC', '1'),
('405', 'BOK', 'PUNEET ENTERPRISES', '1'),
('406', 'AWC', 'BLACKIE &amp; SON', '1'),
('407', 'PE5', 'A MINSTREL BOOK', '1'),
('408', 'BS', 'HWARD PUB.', '1'),
('409', 'AM2', 'ST MARTINS PAPER BOOK', '1'),
('410', 'HWP', 'A TARGET BOOK', '1'),
('411', 'SMP', 'AN ARCHWEY PAPER BOOK', '1'),
('412', 'AT2', 'SUMAN PRAKASHAN', '1'),
('413', 'AAP', 'LIPEK PRESS', '1'),
('414', 'SP7', 'GYANPETH PAPER BOOK', '1'),
('415', 'LP6', 'AKCHHAR PRAKASHAN PVT.LTD', '1'),
('416', 'GP5', 'DENMAN PRAKASDHAN', '1'),
('417', 'APL', 'HANS PRAKASHAN', '1'),
('418', 'DP0', 'SAMYEK PRAKASHAN', '1'),
('419', 'HP6', 'ARUNODYA PRAKASHAN', '1'),
('420', 'SAM', 'NIDHI PRAKASHAN', '1'),
('421', 'ARU', 'SUKHLAL GUPTA', '1'),
('422', 'NP7', 'SADHNA POCKET BOOKS', '1'),
('423', 'SG', 'PUSTAK BOOK CLUB', '1'),
('424', 'SDN', 'KUMAR PRENTING PRESS', '1'),
('425', 'P[B', 'BHARTIYA GYANPETH', '1'),
('426', 'KPP', 'STAR PUBLICATION', '1'),
('427', 'BGY', 'DIAMND POCKET BOOKS', '1'),
('428', 'SPC', 'SUMAN PUBLICATION', '1'),
('429', 'DP8', 'JAN PRINTING PRESS', '1'),
('430', 'SU2', 'GOOD LUCK PUB', '1'),
('431', 'JPP', 'FUTURE KIDS', '1'),
('432', 'GOD', 'ORIENT LONGMAN', '1'),
('433', 'FUT', 'VIDDYARTHI PUB', '1'),
('434', 'OR1', 'FLAMINGO BOOKS', '1'),
('435', 'VID', 'PEARL PUB', '1'),
('436', 'FB6', 'AMBER PRAKASHAN', '1'),
('437', 'PEP', 'RADICAL BOOKS', '1'),
('438', 'AP5', 'TRISEA PUBLICATION', '1'),
('439', 'RB7', 'KISHOR BHARTI', '1'),
('440', 'TP5', 'DELHI PATHYA PUSTAK', '1'),
('441', 'KIB', 'APM PUBLICATION', '1'),
('442', 'DPP', 'SARASWATI PRESS', '1'),
('443', 'APM', 'HAR ANAND PUBLICA', '1'),
('444', 'SA8', 'APM PUB', '1'),
('445', 'HA2', 'USBORNE PUBLICATION', '1'),
('446', 'APP', 'BHOJPURI AKADME', '1'),
('447', 'UP6', 'TULIKA PRAKASHAN', '1'),
('448', 'BA', 'NAOBHARAT PRAKASHAN', '1'),
('449', 'TP2', 'SAHITYA AKADME', '1'),
('450', 'NBP', 'AMEDHA PRAKASHAN', '1'),
('451', 'SA', 'RAJAT PRAKASHAN', '1'),
('452', 'AME', 'MARUTI PRAKASHAN', '1'),
('453', 'RAJ', 'POONA PRAKASHAN', '1'),
('454', 'MP6', 'SATSAHITY PRAKASHAN', '1'),
('455', 'PP/', 'SUMDA PRAKASHAN', '1'),
('456', 'SP8', 'SHIKSHAN SANSTHAN', '1'),
('457', 'SU4', 'JEEVAN JYOTI PRAKASHAN', '1'),
('458', 'SKN', 'PARAMHANS PRAKASHAN', '1'),
('459', 'JJP', 'KADEMBRE PRAKASHAN', '1'),
('460', 'P P', 'PRAGYA PRAKASHAN', '1'),
('461', 'KP8', 'BHARAT PUBLISHING', '1'),
('462', 'PRG', 'SCHOLARS PUBLICATIN', '1'),
('463', 'BP2', 'BHARTI PRAKASHAN', '1'),
('464', 'SC5', 'CRISEAA PUB.', '1'),
('465', 'BHA', 'MACKMILAN BANGLORE', '1'),
('466', 'CRI', 'RACHNA SAGAR', '1'),
('467', 'MAC', 'ROYAL BOOK DEPO', '1'),
('468', 'RA1', 'RAMESH PUB HOUSE', '1'),
('469', 'RBD', 'VIDYA PUBLICATION', '1'),
('470', 'RP=', 'NEW LIGHT PRAKASHAN', '1'),
('471', 'VP7', 'SECLY AND COMPANY', '1'),
('472', 'NL1', 'READICAL BOOK', '1'),
('473', 'SA4', 'MEGHA BOOKS', '1'),
('474', 'REB', 'OCTOPUS INDIA LONDON', '1'),
('475', 'MB4', 'MAHILA CHARKHA SAMITE', '1'),
('476', 'OCI', 'R K EDUCATION', '1'),
('477', 'MCS', 'COLLIENS', '1'),
('478', 'RK1', 'SRI N SINGH', '1'),
('479', 'COL', 'SAHITYIK PRAKASHAN', '1'),
('480', 'SNS', 'ALLADIN PAPER BOOK', '1'),
('481', 'SAP', 'INDRA PUB HOUSE', '1'),
('482', 'ALD', 'EROKIDS PVT LTD', '1'),
('483', 'IND', 'NAVNEET PUBLICATION', '1'),
('484', 'EPL', 'KYLE CATHIE LTD LONDON', '1'),
('485', 'NAV', 'PATNA [BIHAR]', '1'),
('486', 'KCL', 'F.K.PUBLICATION', '1'),
('487', 'PAT', 'RADICAL PUB', '1'),
('488', 'FKP', 'MODERN PUB', '1'),
('489', 'RAD', 'BLASSOMS VIDYA PUB', '1'),
('490', 'MOD', 'MADHUBAN PUBLICATION', '1'),
('491', 'BLV', 'ARROW PUB', '1'),
('492', 'MAP', 'RASTOGI PUB', '1'),
('493', 'ARP', 'V K CINDIEJ', '1'),
('494', 'RAP', 'V K GLOBAL PUB', '1'),
('495', 'VKC', 'SHAIL PRAKASHAN', '1'),
('496', 'VKG', 'TEXT BOOK PATNA', '1'),
('497', 'SP1', 'FLAMINGO PUBLICATION', '1'),
('498', 'TEX', 'SATISH &amp; BROTHERS', '1'),
('499', 'FMP', 'AADEMS BOOKS', '1'),
('500', 'S&amp;B', 'INSPIRATION', '1');

### Structure of table `fa_purch_data` ###

DROP TABLE IF EXISTS `fa_purch_data`;

CREATE TABLE `fa_purch_data` (
  `supplier_id` int(11) NOT NULL DEFAULT '0',
  `stock_id` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `price` double NOT NULL DEFAULT '0',
  `suppliers_uom` char(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `conversion_factor` double NOT NULL DEFAULT '1',
  `supplier_description` char(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`supplier_id`,`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_purch_data` ###


### Structure of table `fa_purch_order_details` ###

DROP TABLE IF EXISTS `fa_purch_order_details`;

CREATE TABLE `fa_purch_order_details` (
  `po_detail_item` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` int(11) NOT NULL DEFAULT '0',
  `item_code` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` tinytext COLLATE utf8_unicode_ci,
  `delivery_date` date NOT NULL DEFAULT '0000-00-00',
  `qty_invoiced` double NOT NULL DEFAULT '0',
  `unit_price` double NOT NULL DEFAULT '0',
  `act_price` double NOT NULL DEFAULT '0',
  `std_cost_unit` double NOT NULL DEFAULT '0',
  `quantity_ordered` double NOT NULL DEFAULT '0',
  `quantity_received` double NOT NULL DEFAULT '0',
  `trans_type` int(11) NOT NULL,
  `gst` float NOT NULL,
  `cst` float NOT NULL,
  `ist` float NOT NULL,
  `gst_amt` double NOT NULL,
  `cst_amt` double NOT NULL,
  `ist_amt` double NOT NULL,
  `hsn_no` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `pro_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'PO',
  PRIMARY KEY (`po_detail_item`),
  KEY `order` (`order_no`,`po_detail_item`),
  KEY `itemcode` (`item_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_purch_order_details` ###

INSERT INTO `fa_purch_order_details` VALUES
('1', '1', '16GBDDR3', '16 GB DDR3', '2023-09-21', '0', '0', '0', '0', '10', '10', '25', '0', '0', '0', '0', '0', '0', '258', '0', 'PO'),
('2', '2', '1TBHDD', 'HDD 1TB', '2023-09-21', '0', '0', '0', '0', '10', '10', '25', '0', '0', '0', '0', '0', '0', '258', '0', 'PO'),
('3', '3', 'FB-CPU-Test', 'FB-CPU-Test', '2023-09-21', '0', '0', '0', '0', '1', '1', '25', '0', '0', '0', '0', '0', '0', '0', '0', 'MO'),
('4', '4', '16GBDDR3', '16 GB DDR3', '2023-10-04', '0', '0', '0', '0', '16', '16', '25', '0', '0', '0', '0', '0', '0', '258', '0', 'PO');

### Structure of table `fa_purch_orders` ###

DROP TABLE IF EXISTS `fa_purch_orders`;

CREATE TABLE `fa_purch_orders` (
  `order_no` int(11) NOT NULL AUTO_INCREMENT,
  `trans_type` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL DEFAULT '0',
  `desig_group` int(11) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `filename` text COLLATE utf8_unicode_ci NOT NULL,
  `comments` tinytext COLLATE utf8_unicode_ci,
  `ord_date` date NOT NULL DEFAULT '0000-00-00',
  `employee_type` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `reference` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `requisition_no` tinytext COLLATE utf8_unicode_ci,
  `into_stock_location` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `delivery_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `total` double NOT NULL DEFAULT '0',
  `tax_included` tinyint(1) NOT NULL DEFAULT '0',
  `login_id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `approved_status` int(11) NOT NULL,
  `suppliers_id` text CHARACTER SET utf8 NOT NULL,
  `enq_ref` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `quotation` int(8) NOT NULL DEFAULT '0',
  `submitorder` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_no`),
  KEY `ord_date` (`ord_date`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_purch_orders` ###

INSERT INTO `fa_purch_orders` VALUES
('1', '25', '5', '0', '0', '0', '0', '', NULL, '2023-09-21', '', '1', '1', 'PAT', '258 Nehru Nagar Patna 800013', '0', '0', '', '0', '5', '', '0', '0'),
('2', '25', '5', '0', '0', '0', '0', '', NULL, '2023-09-21', '', '2', '1', 'PAT', '258 Nehru Nagar Patna 800013', '0', '0', '', '0', '5', '', '0', '0'),
('3', '25', '0', '0', '0', '0', '0', '', NULL, '2023-09-21', '', '3', NULL, 'PAT', '1', '0', '0', '', '0', '', '', '0', '0'),
('4', '25', '5', '0', '0', '0', '0', '', NULL, '2023-10-04', '', '4', NULL, 'PAT', '258 Nehru Nagar Patna 800013', '0', '0', '', '0', '5', '', '0', '0');

### Structure of table `fa_quick_entries` ###

DROP TABLE IF EXISTS `fa_quick_entries`;

CREATE TABLE `fa_quick_entries` (
  `id` smallint(6) unsigned NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `usage` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `base_amount` double NOT NULL DEFAULT '0',
  `base_desc` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bal_type` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `description` (`description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_quick_entries` ###


### Structure of table `fa_quick_entry_lines` ###

DROP TABLE IF EXISTS `fa_quick_entry_lines`;

CREATE TABLE `fa_quick_entry_lines` (
  `id` smallint(6) unsigned NOT NULL,
  `qid` smallint(6) unsigned NOT NULL,
  `amount` double DEFAULT '0',
  `memo` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `action` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `dest_id` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dimension_id` smallint(6) unsigned DEFAULT NULL,
  `dimension2_id` smallint(6) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `qid` (`qid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_quick_entry_lines` ###


### Structure of table `fa_recieved_management` ###

DROP TABLE IF EXISTS `fa_recieved_management`;

CREATE TABLE `fa_recieved_management` (
  `id` int(11) NOT NULL,
  `ref_id` varchar(255) NOT NULL,
  `issue_no` varchar(255) DEFAULT NULL,
  `subject_title` varchar(255) NOT NULL,
  `recieved_date` datetime NOT NULL,
  `recieve_mode` varchar(255) NOT NULL,
  `document_type` varchar(255) NOT NULL,
  `sender_person` varchar(255) NOT NULL,
  `sender_designation` varchar(255) NOT NULL,
  `sender_department` varchar(255) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_recieved_management` ###

INSERT INTO `fa_recieved_management` VALUES
('1', 'rev-001', NULL, '', '2020-01-22 00:00:00', '', '', '', '', '', '', '1');

### Structure of table `fa_recurrent_invoices` ###

DROP TABLE IF EXISTS `fa_recurrent_invoices`;

CREATE TABLE `fa_recurrent_invoices` (
  `id` smallint(6) unsigned NOT NULL,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `order_no` int(11) unsigned NOT NULL,
  `debtor_no` int(11) unsigned DEFAULT NULL,
  `group_no` smallint(6) unsigned DEFAULT NULL,
  `days` int(11) NOT NULL DEFAULT '0',
  `monthly` int(11) NOT NULL DEFAULT '0',
  `begin` date NOT NULL DEFAULT '0000-00-00',
  `end` date NOT NULL DEFAULT '0000-00-00',
  `last_sent` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `description` (`description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_recurrent_invoices` ###


### Structure of table `fa_reflines` ###

DROP TABLE IF EXISTS `fa_reflines`;

CREATE TABLE `fa_reflines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_type` int(11) NOT NULL,
  `prefix` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pattern` varchar(35) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `prefix` (`trans_type`,`prefix`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_reflines` ###

INSERT INTO `fa_reflines` VALUES
('1', '0', '', '1', '', '1', '0'),
('2', '1', '', '1', '', '1', '0'),
('3', '2', '', '1', '', '1', '0'),
('4', '4', '', '1', '', '1', '0'),
('5', '10', '', '1', '', '1', '0'),
('6', '11', '', '1', '', '1', '0'),
('7', '12', '', '1', '', '1', '0'),
('8', '13', '', '1', '', '1', '0'),
('9', '16', '', '1', '', '1', '0'),
('10', '17', '', '1', '', '1', '0'),
('11', '18', '', '1', '', '1', '0'),
('12', '20', '', '1', '', '1', '0'),
('13', '21', '', '1', '', '1', '0'),
('14', '22', '', '1', '', '1', '0'),
('15', '25', '', '5', '', '1', '0'),
('16', '26', '', '3', '', '1', '0'),
('18', '29', '', '3', '', '1', '0'),
('19', '30', '', '1', '', '1', '0'),
('20', '32', '', '1', '', '1', '0'),
('21', '35', '', '1', '', '1', '0'),
('22', '40', '', '1', '', '1', '0'),
('23', '28', '', '1', '', '1', '0');

### Structure of table `fa_refs` ###

DROP TABLE IF EXISTS `fa_refs`;

CREATE TABLE `fa_refs` (
  `id` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`,`type`),
  KEY `Type_and_Reference` (`type`,`reference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

### Data of table `fa_refs` ###

INSERT INTO `fa_refs` VALUES
('1', '25', '1'),
('2', '25', '2'),
('3', '25', '4'),
('4', '25', '4'),
('1', '26', '1'),
('2', '26', '2'),
('1', '29', '1'),
('2', '29', '2');

### Structure of table `fa_refs1` ###

DROP TABLE IF EXISTS `fa_refs1`;

CREATE TABLE `fa_refs1` (
  `id` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(100) CHARACTER SET utf8 NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_refs1` ###


### Structure of table `fa_return` ###

DROP TABLE IF EXISTS `fa_return`;

CREATE TABLE `fa_return` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` varchar(100) NOT NULL,
  `building` int(11) NOT NULL,
  `floor` int(11) NOT NULL,
  `room` int(11) NOT NULL,
  `department` int(11) NOT NULL,
  `seat` int(11) NOT NULL,
  `return_status` varchar(50) NOT NULL DEFAULT '0',
  `return_date` date NOT NULL,
  `item_status` varchar(50) NOT NULL,
  `sl_no` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT '1',
  `loc_code` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_return` ###


### Structure of table `fa_return_policy` ###

DROP TABLE IF EXISTS `fa_return_policy`;

CREATE TABLE `fa_return_policy` (
  `id` int(11) NOT NULL,
  `ref_id` varchar(50) NOT NULL,
  `return_policy` varchar(100) NOT NULL,
  `no_day` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;

### Data of table `fa_return_policy` ###

INSERT INTO `fa_return_policy` VALUES
('3', 'No-001', 'Staff', '10', '0'),
('4', 'No-002', 'Student', '5', '0');

### Structure of table `fa_room_issue_items` ###

DROP TABLE IF EXISTS `fa_room_issue_items`;

CREATE TABLE `fa_room_issue_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `qty_issued` double DEFAULT NULL,
  `unit_cost` double NOT NULL DEFAULT '0',
  `sl_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `department_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'NA',
  `seat_no` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'NA',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_room_issue_items` ###


### Structure of table `fa_room_issues` ###

DROP TABLE IF EXISTS `fa_room_issues`;

CREATE TABLE `fa_room_issues` (
  `issue_no` int(11) NOT NULL AUTO_INCREMENT,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `loc_code` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workcentre_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`issue_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_room_issues` ###


### Structure of table `fa_room_main` ###

DROP TABLE IF EXISTS `fa_room_main`;

CREATE TABLE `fa_room_main` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) NOT NULL,
  `room_no` varchar(50) NOT NULL,
  `qty` int(10) NOT NULL,
  `inactive` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ;

### Data of table `fa_room_main` ###

INSERT INTO `fa_room_main` VALUES
('1', '1', 'D001', '10', '0'),
('2', '1', 'D002', '10', '0'),
('3', '1', 'D003', '1', '0'),
('4', '1', 'D004', '10', '0');

### Structure of table `fa_room_master` ###

DROP TABLE IF EXISTS `fa_room_master`;

CREATE TABLE `fa_room_master` (
  `room_id` int(11) NOT NULL AUTO_INCREMENT,
  `room_des` char(100) DEFAULT NULL,
  `room_no` char(25) DEFAULT NULL,
  `room_type` varchar(11) DEFAULT NULL,
  `ac_avil` tinyint(11) DEFAULT NULL,
  `status` tinyint(11) DEFAULT NULL,
  `inactive` tinyint(4) NOT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`room_id`),
  UNIQUE KEY `room_no` (`room_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_room_master` ###


### Structure of table `fa_room_transition` ###

DROP TABLE IF EXISTS `fa_room_transition`;

CREATE TABLE `fa_room_transition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) DEFAULT NULL,
  `bed_no` varchar(50) DEFAULT NULL,
  `fee_type` char(11) DEFAULT NULL,
  `charge` float DEFAULT NULL,
  `inactive` tinyint(4) NOT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fa_room_transition` (`room_id`,`bed_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_room_transition` ###


### Structure of table `fa_route` ###

DROP TABLE IF EXISTS `fa_route`;

CREATE TABLE `fa_route` (
  `id` int(11) NOT NULL,
  `route_id` varchar(50) NOT NULL,
  `route_name` varchar(100) NOT NULL,
  `source` varchar(50) NOT NULL,
  `destination` varchar(100) NOT NULL,
  `status` int(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_route` ###

INSERT INTO `fa_route` VALUES
('1', 'route-001', 'SCH-DPUR', 'Danapur Cant', 'School', '1'),
('2', 'route-002', 'SCH-PCITY', 'Patna City', 'School', '1'),
('3', 'route-003', 'SCH-RLYST', 'Railway Station', 'School', '2'),
('4', 'route-004', 'DUPLICATE', 'IIT', 'School', '1'),
('5', 'route-005', 'test', 'test', 'test', '1'),
('6', 'route-006', 'test', 'test', 'test', '1'),
('7', 'route-007', 'test', 'test', 'test', '1'),
('8', 'route-008', 'fdg', 'fg', 'fg', '2');

### Structure of table `fa_route_config` ###

DROP TABLE IF EXISTS `fa_route_config`;

CREATE TABLE `fa_route_config` (
  `id` int(11) NOT NULL,
  `config_id` varchar(50) NOT NULL,
  `route_name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_route_config` ###

INSERT INTO `fa_route_config` VALUES
('5', 'config-001', 'SCH-DPUR', '1'),
('6', 'config-002', 'SCH-PCITY', '1'),
('7', 'config-003', '', '1'),
('8', 'config-004', '', '1'),
('9', 'config-005', '', '1');

### Structure of table `fa_routeconfig_detail` ###

DROP TABLE IF EXISTS `fa_routeconfig_detail`;

CREATE TABLE `fa_routeconfig_detail` (
  `id` int(11) NOT NULL,
  `config_id` varchar(50) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `sequence` int(10) NOT NULL,
  `exp_time` time NOT NULL,
  `drop_time` time NOT NULL,
  `cost` int(11) NOT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_routeconfig_detail` ###

INSERT INTO `fa_routeconfig_detail` VALUES
('21', 'config-001', '1', '1', '06:30:00', '14:30:00', '500', '1'),
('22', 'config-001', '2', '2', '06:40:00', '14:40:00', '500', '1'),
('23', 'config-001', '3', '3', '06:50:00', '14:50:00', '500', '1'),
('24', 'config-001', '4', '4', '07:00:00', '15:00:00', '500', '1'),
('30', 'config-002', '4', '1', '06:50:00', '14:50:00', '500', '1'),
('31', 'config-002', '5', '2', '07:00:00', '15:00:00', '500', '1'),
('32', 'config-002', '6', '3', '07:10:00', '15:15:00', '500', '1'),
('33', 'config-003', '', '0', '00:00:00', '00:00:00', '0', '1'),
('34', 'config-004', '', '0', '00:00:00', '00:00:00', '0', '1'),
('35', 'config-005', '', '0', '00:00:00', '00:00:00', '0', '1');

### Structure of table `fa_salary_structure` ###

DROP TABLE IF EXISTS `fa_salary_structure`;

CREATE TABLE `fa_salary_structure` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `salary_scale_id` int(11) NOT NULL,
  `pay_rule_id` varchar(15) NOT NULL,
  `pay_amount` double NOT NULL,
  `type` tinyint(1) NOT NULL COMMENT '0 for credit, 1 for debit',
  `is_basic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;

### Data of table `fa_salary_structure` ###


### Structure of table `fa_salaryscale` ###

DROP TABLE IF EXISTS `fa_salaryscale`;

CREATE TABLE `fa_salaryscale` (
  `scale_id` int(11) NOT NULL,
  `scale_name` text NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `pay_basis` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = monthly, 1 = daily',
  PRIMARY KEY (`scale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ;

### Data of table `fa_salaryscale` ###


### Structure of table `fa_sales_order_details` ###

DROP TABLE IF EXISTS `fa_sales_order_details`;

CREATE TABLE `fa_sales_order_details` (
  `id` int(11) NOT NULL,
  `order_no` int(11) NOT NULL DEFAULT '0',
  `trans_type` smallint(6) NOT NULL DEFAULT '30',
  `stk_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` tinytext COLLATE utf8_unicode_ci,
  `qty_sent` double NOT NULL DEFAULT '0',
  `unit_price` double NOT NULL DEFAULT '0',
  `quantity` double NOT NULL DEFAULT '0',
  `invoiced` double NOT NULL DEFAULT '0',
  `discount_percent` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_sales_order_details` ###


### Structure of table `fa_sales_orders` ###

DROP TABLE IF EXISTS `fa_sales_orders`;

CREATE TABLE `fa_sales_orders` (
  `order_no` int(11) NOT NULL,
  `trans_type` smallint(6) NOT NULL DEFAULT '30',
  `version` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `debtor_no` int(11) NOT NULL DEFAULT '0',
  `branch_code` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `customer_ref` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comments` tinytext COLLATE utf8_unicode_ci,
  `ord_date` date NOT NULL DEFAULT '0000-00-00',
  `order_type` int(11) NOT NULL DEFAULT '0',
  `ship_via` int(11) NOT NULL DEFAULT '0',
  `delivery_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `contact_phone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deliver_to` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `freight_cost` double NOT NULL DEFAULT '0',
  `from_stk_loc` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `delivery_date` date NOT NULL DEFAULT '0000-00-00',
  `payment_terms` int(11) DEFAULT NULL,
  `total` double NOT NULL DEFAULT '0',
  `prep_amount` double NOT NULL DEFAULT '0',
  `alloc` double NOT NULL DEFAULT '0',
  `gst` double NOT NULL,
  `gst_amt` double NOT NULL,
  `cst` double NOT NULL,
  `cst_amt` double NOT NULL,
  `ist` double NOT NULL,
  `ist_amt` double NOT NULL,
  `hsn_no` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  PRIMARY KEY (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_sales_orders` ###


### Structure of table `fa_sales_pos` ###

DROP TABLE IF EXISTS `fa_sales_pos`;

CREATE TABLE `fa_sales_pos` (
  `id` smallint(6) unsigned NOT NULL,
  `pos_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `cash_sale` tinyint(1) NOT NULL,
  `credit_sale` tinyint(1) NOT NULL,
  `pos_location` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `pos_account` smallint(6) unsigned NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_sales_pos` ###

INSERT INTO `fa_sales_pos` VALUES
('1', 'Default', '1', '1', 'DEF', '2', '0');

### Structure of table `fa_sales_types` ###

DROP TABLE IF EXISTS `fa_sales_types`;

CREATE TABLE `fa_sales_types` (
  `id` int(11) NOT NULL,
  `sales_type` char(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_included` int(1) NOT NULL DEFAULT '0',
  `factor` double NOT NULL DEFAULT '1',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_sales_types` ###

INSERT INTO `fa_sales_types` VALUES
('1', 'Retail', '1', '1', '0'),
('2', 'Wholesale', '0', '0.7', '0');

### Structure of table `fa_salesman` ###

DROP TABLE IF EXISTS `fa_salesman`;

CREATE TABLE `fa_salesman` (
  `salesman_code` int(11) NOT NULL,
  `salesman_name` char(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `salesman_phone` char(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `salesman_fax` char(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `salesman_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `provision` double NOT NULL DEFAULT '0',
  `break_pt` double NOT NULL DEFAULT '0',
  `provision2` double NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`salesman_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_salesman` ###

INSERT INTO `fa_salesman` VALUES
('1', 'Sales Person', '', '', '', '5', '20000', '4', '0');

### Structure of table `fa_seat_allocation` ###

DROP TABLE IF EXISTS `fa_seat_allocation`;

CREATE TABLE `fa_seat_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `master_id` int(11) NOT NULL,
  `seat_no` varchar(50) NOT NULL,
  `inactive` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 ;

### Data of table `fa_seat_allocation` ###

INSERT INTO `fa_seat_allocation` VALUES
('1', '1', 'S001', '0', '0'),
('2', '1', 'S002', '0', '0'),
('3', '1', 'S003', '0', '0'),
('4', '1', 'S004', '0', '0'),
('5', '1', 'S005', '0', '0'),
('6', '1', 'S006', '0', '0'),
('7', '1', 'S007', '0', '0'),
('8', '1', 'S008', '0', '0'),
('9', '1', 'S009', '0', '0'),
('10', '1', 'S0010', '0', '0');

### Structure of table `fa_seat_issue_items` ###

DROP TABLE IF EXISTS `fa_seat_issue_items`;

CREATE TABLE `fa_seat_issue_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `qty_issued` double DEFAULT NULL,
  `unit_cost` double NOT NULL DEFAULT '0',
  `sl_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_seat_issue_items` ###


### Structure of table `fa_seat_issues` ###

DROP TABLE IF EXISTS `fa_seat_issues`;

CREATE TABLE `fa_seat_issues` (
  `issue_no` int(11) NOT NULL AUTO_INCREMENT,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `loc_code` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workcentre_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`issue_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_seat_issues` ###


### Structure of table `fa_seat_master` ###

DROP TABLE IF EXISTS `fa_seat_master`;

CREATE TABLE `fa_seat_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `building` int(11) NOT NULL,
  `floor` int(11) NOT NULL,
  `room` int(11) NOT NULL,
  `department` int(11) NOT NULL,
  `inactive` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `room` (`room`),
  KEY `fa_seat_master_ibfk_2` (`building`),
  KEY `floor` (`floor`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

### Data of table `fa_seat_master` ###

INSERT INTO `fa_seat_master` VALUES
('1', '1', '1', '1', '1', '0');

### Structure of table `fa_security_roles` ###

DROP TABLE IF EXISTS `fa_security_roles`;

CREATE TABLE `fa_security_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sections` text COLLATE utf8_unicode_ci,
  `areas` text COLLATE utf8_unicode_ci,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_security_roles` ###

INSERT INTO `fa_security_roles` VALUES
('1', 'Inquiries', 'Inquiries', '28928;29440;32512;768;2816;3072;3328;5632;5888;8192;8448;10752;11008;13312;15872;16128', '28933;28937;29461;29462;32522;257;258;259;260;513;514;515;516;517;518;519;520;521;522;523;524;525;773;774;775;2822;3073;3075;3076;3077;3329;3330;3331;3332;3333;3334;3335;5377;5633;5640;5889;5890;5891;7937;7938;7939;7940;8193;8194;8450;8451;10497;10753;11009;11010;11012;13313;13315;15617;15618;15619;15620;15621;15622;15623;15624;15625;15626;15873;15882;16129;16130;16131;16132', '0'),
('2', 'System Administrator', 'System Administrator', '256;512;768;2816;3072;3328;5376;5632;5888;7936;8192;8448;9216;9472;9728;10496;10752;11008;13056;13312;15616;15872;16128;20736;418816;25856;419072;419328;419584;419840;30976;31232;31744;32000;32256;28416;28672;28928;29184;29440;29696;29952;30208;30464', '257;258;259;260;513;514;515;516;517;518;519;520;521;522;523;524;525;526;769;770;771;772;773;774;775;2817;2818;2819;2820;2821;2822;2823;3073;3074;3082;3075;3076;3077;3078;3079;3080;3081;3329;3330;3331;3332;3333;3334;3335;5377;5633;5634;5635;5642;5643;5645;5644;5636;5637;5641;5638;5639;5640;5646;5889;5890;5891;7937;7938;7939;7940;8193;8194;8195;8196;8197;8199;8198;8449;8450;8451;9217;9218;9220;9473;9474;9475;9476;9729;10497;10753;10754;10755;10756;10757;11009;11010;11011;11012;13057;13313;13314;13315;15617;15618;15619;15620;15621;15622;15623;15624;15628;15625;15626;15627;15630;15629;15873;15874;15875;15876;15877;15878;15879;15880;15883;15881;15882;15884;16129;16130;16131;16132;20737;20738;20739;20740;20741;418916;418917;418918;418919;418920;418921;418922;418923;418924;418925;418926;418927;418928;418929;418930;418931;418941;418942;418945;418946;418947;418948;418949;418950;418951;418952;418953;25857;25858;419199;419200;419210;419212;419444;419445;419446;419447;419448;419449;419450;419451;419725;419726;419983;419984;419985;419986;419987;28417;28673;28674;28675;28676;28677;28679;28680;28681;28682;28683;28684;28685;28686;28687;28705;28688;28689;28691;28692;28693;28694;28698;28699;28700;28702;28704;28706;28929;28930;28931;29185;29187;29188;29193;29194;29445;29446;29697;29698;29953;29954;29955;30209;30210;30211;30977;30978;30979;30980;30981;30982;30983;30984;30985;30986;30987;31233;31234;31235;31236;31237;31745;31746;31747;31748;31750;32001;32002;32003;32004;32005;32006;32007;32008;32257;32258;32259', '0'),
('3', 'Salesman', 'Salesman', '768;3072;5632;8192;15872', '773;774;3073;3075;3081;5633;8194;15873;775', '0'),
('4', 'Stock Manager', 'Stock Manager', '2816;3072;3328;5632;5888;8192;8448;10752;11008;13312;15872;16128;768', '775', '0'),
('5', 'Production Manager', 'Production Manager', '512;2816;3072;3328;5632;5888;8192;8448;10752;11008;13312;15616;15872;16128;768', '775', '0'),
('6', 'Purchase Officer', 'Purchase Officer', '512;2816;3072;3328;5376;5632;5888;8192;8448;10752;11008;13312;15616;15872;16128;768', '775', '0'),
('7', 'AR Officer', 'AR Officer', '512;768;2816;3072;3328;5632;5888;8192;8448;10752;11008;13312;15616;15872;16128', '521;523;524;771;773;774;2818;2819;2820;2821;2822;2823;3073;3073;3074;3075;3076;3077;3078;3079;3080;3081;3081;3329;3330;3330;3330;3331;3331;3332;3333;3334;3335;5633;5633;5634;5637;5638;5639;5640;5640;5889;5890;5891;8193;8194;8194;8196;8197;8450;8451;10753;10755;11009;11010;11012;13313;13315;15617;15619;15620;15621;15624;15624;15873;15876;15877;15878;15880;15882;16129;16130;16131;16132;775', '0'),
('8', 'AP Officer', 'AP Officer', '512;2816;3072;3328;5376;5632;5888;8192;8448;10752;11008;13312;15616;15872;16128;768', '775', '0'),
('9', 'Accountant', 'New Accountant', '28928;29184;29440;29696;32256;512;768;2816;3072;3328;5376;5632;5888;8192;8448;10752;11008;13312;15616;15872;16128', '28929;28931;29188;29195;29448;29449;29445;29450;29451;29697;29699;32257;32259;257;258;259;260;521;523;524;771;772;773;774;775;2818;2819;2820;2821;2822;2823;3073;3074;3075;3076;3077;3078;3079;3080;3081;3329;3330;3331;3332;3333;3334;3335;5377;5633;5634;5635;5637;5638;5639;5640;5889;5890;5891;7937;7938;7939;7940;8193;8194;8196;8197;8449;8450;8451;10497;10753;10755;11009;11010;11012;13313;13315;15617;15618;15619;15620;15621;15624;15873;15876;15877;15878;15880;15882;16129;16130;16131;16132', '0'),
('10', 'Sub Admin', 'Sub Admin', '29184;29440;29696;512;768;2816;3072;3328;5376;5632;5888;8192;8448;10752;11008;13312;15616;15872;16128', '29188;29195;29448;29449;29445;29450;257;258;259;260;521;523;524;771;772;773;774;775;2818;2819;2820;2821;2822;2823;3073;3074;3082;3075;3076;3077;3078;3079;3080;3081;3329;3330;3331;3332;3333;3334;3335;5377;5633;5634;5635;5637;5638;5639;5640;5889;5890;5891;7937;7938;7939;7940;8193;8194;8196;8197;8449;8450;8451;10497;10753;10755;11009;11010;11012;13057;13313;13315;15617;15619;15620;15621;15624;15873;15874;15876;15877;15878;15879;15880;15882;16129;16130;16131;16132', '0'),
('11', 'library', 'Admin Library', '18176;18432', '18177;18178;18179;18180;18181;18182;18183;18184;18185;18186;18187;18444;18445;18446;18447;18448;18449', '0'),
('12', 'Faculty', 'Academic Faculty', '418816;28416;29696', '418928;418929;418930;418931;418950;418951;418952;28417;29700', '0'),
('13', 'HOD', 'HOD admin', '28416;29184;29696;418816', '28417;29185;29193;29194;29698;29699;29700;29701;418922;418923;418928;418929;418930;418931;418950;418951;418952', '0'),
('14', 'BED', 'BED', '28928', '28935', '0');

### Structure of table `fa_self` ###

DROP TABLE IF EXISTS `fa_self`;

CREATE TABLE `fa_self` (
  `id` int(11) NOT NULL,
  `floor_id` varchar(100) NOT NULL,
  `floor_aisle` varchar(50) NOT NULL,
  `self_desc` text NOT NULL,
  `self_code` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_self` ###

INSERT INTO `fa_self` VALUES
('1', 'GR-A/001', 'GR-AS-001', 'Computer sc.', 'GR-S001', '0'),
('2', 'GR-B/001', 'GR-AS-002', 'Engg. Books', 'GR-AS-S002', '0'),
('3', 'SD-A001', 'SD-A-001', 'Arts Book', 'Second Arts', '0'),
('4', 'SD-A002', 'SD-B-002', 'Comp and Engg', 'Self Comp. Sc.', '0'),
('5', 'LGF-01', 'LGF-01', 'one', 'one', '0');

### Structure of table `fa_shippers` ###

DROP TABLE IF EXISTS `fa_shippers`;

CREATE TABLE `fa_shippers` (
  `shipper_id` int(11) NOT NULL,
  `shipper_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone2` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contact` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`shipper_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_shippers` ###

INSERT INTO `fa_shippers` VALUES
('2', 'ddd', '987456320', '98745620', 'ss', 'patna', '0');

### Structure of table `fa_sql_trail` ###

DROP TABLE IF EXISTS `fa_sql_trail`;

CREATE TABLE `fa_sql_trail` (
  `id` int(11) unsigned NOT NULL,
  `sql` text COLLATE utf8_unicode_ci NOT NULL,
  `result` tinyint(1) NOT NULL,
  `msg` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_sql_trail` ###


### Structure of table `fa_statutory_body_master` ###

DROP TABLE IF EXISTS `fa_statutory_body_master`;

CREATE TABLE `fa_statutory_body_master` (
  `id` int(11) NOT NULL,
  `statutory_name` varchar(150) NOT NULL,
  `statutory_desc` varchar(150) NOT NULL,
  `inactive` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_statutory_body_master` ###

INSERT INTO `fa_statutory_body_master` VALUES
('1', 'PF', 'Provident Fund', '0'),
('2', 'EPF', 'Employee PF', '0'),
('3', 'TDS', 'Tax', '0'),
('4', 'ESI.', 'ESI', '0'),
('5', 'Company Registar', 'Company Registar', '0'),
('6', 'Board meeting', 'Board meeting', '0'),
('7', 'Review Meeting', 'Review Meeting', '0'),
('8', 'Team Meeting', 'Team Meeting', '1'),
('9', 'One tt', 'One rert', '0'),
('10', 'Second', 'Rwer', '0'),
('11', 'Ttyy', 'Rtyrty', '0');

### Structure of table `fa_statutory_frequency_master` ###

DROP TABLE IF EXISTS `fa_statutory_frequency_master`;

CREATE TABLE `fa_statutory_frequency_master` (
  `freq_id` int(11) NOT NULL,
  `frequency_name` varchar(150) NOT NULL,
  `frequency_desc` varchar(150) NOT NULL,
  `inactive` int(11) NOT NULL,
  `frequency_days` int(10) NOT NULL,
  PRIMARY KEY (`freq_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_statutory_frequency_master` ###

INSERT INTO `fa_statutory_frequency_master` VALUES
('1', 'Monthly', 'Monthly', '0', '30'),
('2', 'Quarterly', 'Quarterly', '0', '90'),
('3', 'Yearly', 'Yearly', '0', '365'),
('4', 'Half Yearly', 'Half Yearly', '0', '180');

### Structure of table `fa_statutory_main` ###

DROP TABLE IF EXISTS `fa_statutory_main`;

CREATE TABLE `fa_statutory_main` (
  `id` int(10) NOT NULL,
  `statutory_id` int(10) NOT NULL,
  `return_id` int(10) NOT NULL,
  `freq_id` int(10) NOT NULL,
  `remider_days` int(10) NOT NULL,
  `inactive` tinyint(4) NOT NULL DEFAULT '0',
  `statutory_desc` varchar(100) NOT NULL,
  `f_year` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `updated_date` date NOT NULL,
  `empl_id` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_statutory_main` ###

INSERT INTO `fa_statutory_main` VALUES
('1', '1', '2', '1', '0', '0', 'done', '1', '0', '2019-01-25', ''),
('2', '4', '1', '2', '0', '0', 'done 1', '1', '0', '2019-01-29', ''),
('3', '3', '2', '3', '0', '0', 'done', '1', '0', '2019-03-31', ''),
('4', '3', '2', '3', '0', '0', 'done', '1', '0', '2019-03-31', ''),
('5', '1', '2', '1', '0', '0', 'done', '1', '0', '2020-01-22', ''),
('6', '5', '5', '2', '0', '0', 'done', '1', '0', '2019-03-02', ''),
('7', '8', '8', '1', '0', '0', 'done', '1', '0', '2019-01-29', ''),
('8', '6', '6', '1', '0', '0', '', '3', '0', '2020-01-22', ''),
('9', '6', '6', '1', '0', '0', '', '1', '0', '2020-01-22', ''),
('10', '6', '6', '1', '0', '0', 'test', '1', '0', '2020-01-22', ''),
('11', '4', '1', '2', '0', '0', '', '1', '0', '2020-01-22', ''),
('12', '4', '1', '2', '0', '0', 'done', '1', '0', '2020-01-22', '');

### Structure of table `fa_statutory_master` ###

DROP TABLE IF EXISTS `fa_statutory_master`;

CREATE TABLE `fa_statutory_master` (
  `id` int(10) NOT NULL,
  `statutory_id` int(10) NOT NULL,
  `return_id` int(10) NOT NULL,
  `freq_id` int(10) NOT NULL,
  `due_date` date NOT NULL,
  `remider_days` int(10) NOT NULL,
  `inactive` tinyint(4) NOT NULL DEFAULT '0',
  `statutory_desc` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `effective_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_statutory_master` ###

INSERT INTO `fa_statutory_master` VALUES
('1', '2', '1', '4', '2019-01-28', '26', '0', 'Half Yearly', '0', '2020-07-21'),
('2', '4', '1', '2', '2019-01-28', '20', '0', 'ESI', '0', '2020-07-21'),
('3', '1', '2', '1', '2019-01-28', '6', '0', 'PF', '0', '2019-12-24'),
('4', '3', '2', '3', '2019-01-28', '60', '0', 'TDS', '0', '2021-01-27'),
('5', '5', '5', '2', '2019-01-01', '30', '0', 'All the directors have to be present', '0', '2019-04-01'),
('6', '6', '6', '1', '2019-01-31', '5', '0', 'Monthly Board meeting Reminder', '0', '2020-04-25'),
('7', '7', '7', '1', '2019-02-28', '10', '0', 'Review meeting', '0', '2019-09-26'),
('8', '8', '8', '1', '2019-01-30', '3', '0', 'Monthly Team Meeting', '0', '2019-09-27'),
('9', '9', '9', '2', '2019-01-31', '14', '0', 'fger', '0', '2020-01-26'),
('10', '10', '10', '2', '2019-01-31', '14', '0', 'qwerwe', '0', '2020-01-26');

### Structure of table `fa_statutory_uploads` ###

DROP TABLE IF EXISTS `fa_statutory_uploads`;

CREATE TABLE `fa_statutory_uploads` (
  `id` bigint(20) NOT NULL,
  `statutory_main_id` bigint(20) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `unique_name` varchar(255) NOT NULL,
  `updated_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_statutory_uploads` ###

INSERT INTO `fa_statutory_uploads` VALUES
('1', '1', 'PF', 'Purchase.docx', '5c4acd709a7db', '2019-01-25'),
('2', '2', NULL, 'book.jpg', '5ca05babbf815', '2019-03-31'),
('3', '4', NULL, 'book.jpg', '5ca05bd384820', '2019-03-31'),
('4', '5', NULL, 'book.jpg', '5c7a2b0628ea9', '2019-03-02'),
('5', '6', 'MOM', 'book.jpg', '5c7a71c4bcfb4', '2019-03-02'),
('6', '6', 'member', 'Signature.docx', '5c7a71c4dcde8', '2019-03-02'),
('7', '2', 'esi title', 'logo.png', '5c4fec1fb9ab3', '2019-01-29'),
('8', '7', 'MOM', 'CSS.docx', '5c4fecca5fe08', '2019-01-29');

### Structure of table `fa_stock_category` ###

DROP TABLE IF EXISTS `fa_stock_category`;

CREATE TABLE `fa_stock_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_tax_type` int(11) NOT NULL DEFAULT '1',
  `dflt_units` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'each',
  `dflt_mb_flag` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'B',
  `dflt_sales_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_cogs_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_inventory_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_adjustment_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_wip_act` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dflt_dim1` int(11) DEFAULT NULL,
  `dflt_dim2` int(11) DEFAULT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `dflt_no_sale` tinyint(1) NOT NULL DEFAULT '0',
  `dflt_no_purchase` tinyint(1) NOT NULL DEFAULT '0',
  `dflt_assembly_act` int(11) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_stock_category` ###

INSERT INTO `fa_stock_category` VALUES
('1', 'AC\r\n', '1', 'box', 'B', '4010', '5010', '1510', '5040', '1530', '0', '0', '0', '0', '0', '0'),
('2', 'BAGPACK\r\n', '1', 'box', 'D', '4010', '5010', '1510', '5040', '1530', '0', '0', '0', '0', '0', '0'),
('3', 'BATTERY\r\n', '1', 'box', 'M', '4010', '5010', '1510', '5040', '1530', '0', '0', '0', '0', '0', '0'),
('4', 'BOIMETRIC\r\n', '1', 'box', 'D', '4010', '5010', '1510', '5040', '1530', '0', '0', '0', '0', '0', '0'),
('5', 'Cable\r\n', '1', 'box', 'D', '4010', '5010', '1510', '5040', '1530', '0', '0', '0', '0', '0', '0'),
('6', 'CCTV', '1', 'box', 'D', '4010', '5010', '1510', '5040', '1530', '0', '0', '0', '0', '0', '0'),
('7', 'Computer Hardware\r\n', '1', 'box', 'D', '4010', '5010', '1510', '5040', '1530', '0', '0', '0', '0', '0', '0'),
('8', 'Computer Software', '1', 'box', 'D', '4010', '5010', '1510', '5040', '1530', '0', '0', '0', '0', '0', '0'),
('9', 'ELECTRONIC HARDWARE', '1', 'box', 'D', '4010', '5010', '1510', '5040', '1530', '0', '0', '0', '0', '0', '0'),
('10', 'LAPTOP', '1', 'box', 'D', '4010', '5010', '1510', '5040', '1530', '0', '0', '0', '0', '0', '0'),
('11', 'laptop hardware', '1', 'box', 'D', '4010', '5010', '1510', '5040', '1530', '0', '0', '0', '0', '0', '0'),
('12', 'LOCK', '1', 'box', 'D', '4010', '5010', '1510', '5040', '1530', '0', '0', '0', '0', '0', '0'),
('13', 'Mobile', '1', 'box', 'D', '4010', '5010', '1510', '5040', '1530', '0', '0', '0', '0', '0', '0'),
('14', 'Router', '1', 'box', 'D', '4010', '5010', '1510', '5040', '1530', '0', '0', '0', '0', '0', '0'),
('15', 'TV', '1', 'box', 'D', '4010', '5010', '1510', '5040', '1530', '0', '0', '0', '0', '0', '0'),
('16', 'Manufcatured', '1', 'PC', 'M', '', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0');

### Structure of table `fa_stock_decrease` ###

DROP TABLE IF EXISTS `fa_stock_decrease`;

CREATE TABLE `fa_stock_decrease` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` varchar(100) NOT NULL,
  `present_stock` varchar(100) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `invoie_date` date NOT NULL,
  `category_id` int(11) NOT NULL,
  `sub_cat_name` int(11) NOT NULL,
  `return_stock` int(11) NOT NULL,
  `return_date` date NOT NULL,
  `remarks` text NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `ip` varchar(200) NOT NULL,
  `loc_code` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

### Data of table `fa_stock_decrease` ###

INSERT INTO `fa_stock_decrease` VALUES
('1', '1TBHDD', '8', '2', '2023-09-21', '7', '14', '1', '2023-09-28', 'test', 'superAdmin', '152.58.186.100', 'PAT'),
('3', '1TBHDD', '8', '2', '2023-09-21', '7', '14', '1', '2023-09-28', 'test', 'superAdmin', '152.58.186.100', 'PAT'),
('4', '16GBDDR3', '8', '1', '2023-09-21', '7', '40', '8', '2023-09-29', 'Mistakenly added', 'superAdmin', '223.30.155.86', 'PAT'),
('5', '16GBDDR3', '8', '1', '2023-09-21', '7', '40', '7', '2023-09-29', 'mistake', 'superAdmin', '223.30.155.86', 'PAT'),
('6', '16GBDDR3', '24', '1', '2023-09-21', '7', '40', '5', '2023-10-04', '5 RETURN', 'superAdmin', '103.30.118.49', 'PAT');

### Structure of table `fa_stock_fa_class` ###

DROP TABLE IF EXISTS `fa_stock_fa_class`;

CREATE TABLE `fa_stock_fa_class` (
  `fa_class_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `parent_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `long_description` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `depreciation_rate` double NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_stock_fa_class` ###


### Structure of table `fa_stock_master` ###

DROP TABLE IF EXISTS `fa_stock_master`;

CREATE TABLE `fa_stock_master` (
  `stock_id` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `tax_type_id` int(11) NOT NULL DEFAULT '0',
  `description` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `long_description` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `units` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'each',
  `mb_flag` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'B',
  `sales_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cogs_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inventory_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `adjustment_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `wip_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dimension_id` int(11) DEFAULT NULL,
  `dimension2_id` int(11) DEFAULT NULL,
  `purchase_cost` double NOT NULL DEFAULT '0',
  `material_cost` double NOT NULL DEFAULT '0',
  `labour_cost` double NOT NULL DEFAULT '0',
  `overhead_cost` double NOT NULL DEFAULT '0',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `no_sale` tinyint(1) NOT NULL DEFAULT '0',
  `no_purchase` tinyint(1) NOT NULL DEFAULT '0',
  `editable` tinyint(1) NOT NULL DEFAULT '0',
  `depreciation_method` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `depreciation_rate` double NOT NULL DEFAULT '0',
  `depreciation_factor` double NOT NULL DEFAULT '0',
  `depreciation_start` date NOT NULL DEFAULT '0000-00-00',
  `depreciation_date` date NOT NULL DEFAULT '0000-00-00',
  `fa_class_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sub_cat_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `types` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `warranty` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `to_date` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `from_date` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `weight` float NOT NULL,
  `assembly_account` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `sl_no` tinyint(2) NOT NULL DEFAULT '0',
  `cat_group` int(11) NOT NULL,
  PRIMARY KEY (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_stock_master` ###

INSERT INTO `fa_stock_master` VALUES
('16GBDDR3', '7', '1', '16 GB DDR3', '16 GB DDR3', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '40', '1', '', '', '', '0', '0', '1', '0'),
('16GBDDR4', '7', '1', '16 GB DDR4', '16 GB DDR4', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '40', '1', '', '', '', '0', '0', '1', '0'),
('1Gigabyte', '7', '1', 'Cabinet Gigabyte Gaming 1 ', 'Cabinet Gigabyte Gaming 1 ', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('1TBHDD', '7', '1', 'HDD 1TB', 'HDD 1TB', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '14', '1', '', '', '', '0', '0', '1', '0'),
('240GBSSD', '7', '1', '240 GB SSD', '240 GB SSD', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '51', '1', '', '', '', '0', '0', '1', '0'),
('2TBSSD', '7', '1', '2 TB SSD', '2 TB SSD', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '51', '1', '', '', '', '0', '0', '1', '0'),
('32GBDDR4', '7', '1', '32 GB DDR4', '32 GB DDR4', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '40', '1', '', '', '', '0', '1002', '1', '0'),
('4GBDDR3', '7', '1', '4GB DDR3', '4GB DDR3', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '40', '1', '', '', '', '0', '0', '1', '0'),
('4TBHDD', '7', '1', 'HDD 4TB', 'HDD 4TB', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '14', '1', '', '', '', '0', '0', '1', '0'),
('500GBSSD', '7', '1', '500 GB SSD', '500 GB SSD', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '51', '1', '', '', '', '0', '0', '1', '0'),
('8GBDDR3', '7', '1', '8GB DDR3', '8GB DDR3', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '40', '1', '', '', '', '0', '0', '1', '0'),
('8GBDDR4', '7', '1', '8 GB DDR4', '8 GB DDR4', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '40', '1', '', '', '', '0', '0', '1', '0'),
('AC-STAR-EMP-SPLIT', '1', '1', 'Star Emperiya CX SPLIT AC', 'Star Emperiya CX SPLIT AC', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '45', '1', '1', '', '', '1', '', '1', '0'),
('AC-SUM-AA128Y4ZAPGNNA', '1', '1', 'Samsung Ac (AA128Y4ZAPGNNA)', 'Samsung Ac (AA128Y4ZAPGNNA)', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '45', '1', '1', '', '', '0', '', '1', '0'),
('ADAP-CONVERTER-TC', '7', '1', 'Type C to USB Converter Adaptor ', 'Type C to USB Converter Adaptor ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '2', '1', '1', '', '', '1', '', '1', '0'),
('ADAP-EP-TA611BE-V5 ', '7', '1', 'Samsung adaptor ( EP -TA611BE V5 )     For Shivani', 'Samsung adaptor ( EP -TA611BE V5 )     For Shivani', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '2', '1', '1', '', '', '1', '', '1', '0'),
('ADAP-LAP', '7', '1', 'Lapcare laptop adaptor ', 'Lapcare laptop adaptor ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '2', '1', '1', '', '', '1', '', '1', '0'),
('ADAP-LAPCARE', '7', '1', 'Laptop Adapter Lap care', 'Laptop Adapter Lap care', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '2', '1', '1', '', '', '1', '', '1', '0'),
('ADAP-NT-UE300C-TC', '7', '1', 'Type C to RJ45 Gigabit Network Adapter (Model :- UE300C(UN)', 'Type C to RJ45 Gigabit Network Adapter (Model :- UE300C(UN)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '2', '1', '1', '', '', '1', '', '1', '0'),
('ADAP-NT-UE300C-USB3', '7', '1', 'USB 3.0 to Gigabyte Etherney Adapter (Model :- UE300C(UN)', 'USB 3.0 to Gigabyte Etherney Adapter (Model :- UE300C(UN)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '2', '1', '1', '', '', '1', '', '1', '0'),
('ADAP-USB-SATA', '7', '1', 'Xcess Sata Usb casing', 'Xcess Sata Usb casing', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '2', '1', '1', '', '', '1', '', '1', '0'),
('ADAP-USB-T3-QZ-AD11', '7', '1', 'USB 3.1 Type C to Type a Converter (QZ AD11)', 'USB 3.1 Type C to Type a Converter (QZ AD11)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '2', '1', '1', '', '', '1', '', '1', '0'),
('ADAP-USB-T3-VIBOTON', '7', '1', 'M2 Casing Type C to usb 3.0 (VIBOTON)', 'M2 Casing Type C to usb 3.0 (VIBOTON)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '2', '1', '1', '', '', '1', '', '1', '0'),
('ADAP-WIRELESS-T2U', '7', '1', 'Tp-Link Nano usb wireless adaptor (archer t2u nano us ver 1.0)', 'Tp-Link Nano usb wireless adaptor (archer t2u nano us ver 1.0)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '2', '1', '1', '', '', '1', '', '1', '0'),
('BAT-150AH-T-E', '3', '1', 'Exide inva tall tublar battery  150 AH , 12 V (FEMO-IMTT1500)', 'Exide inva tall tublar battery  150 AH , 12 V (FEMO-IMTT1500)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '18', '1', '1', '', '', '1', '', '1', '0'),
('BAT-42AH-E', '3', '1', 'Exide Battery ( 42 AH )', 'Exide 24 Nos Battery ( 42 AH )', 'PC', 'B', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '18', '1', '1', '', '', '0', '', '1', '0'),
('BAT-65AH-E', '3', '1', 'Development Floor Ups 16 Battery (Exide 65 Ah Powersafe Plus) 2 Year Warranty ', 'Development Floor Ups 16 Battery (Exide 65 Ah Powersafe Plus) 2 Year Warranty ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '18', '1', '1', '', '', '1', '', '1', '0'),
('BAT-EP65-12-E', '3', '1', 'EXIDE EP 65-12 BATTERY', 'EXIDE EP 65-12 BATTERY', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '18', '1', '1', '', '', '1', '', '1', '0'),
('BAT-LAP-B', '3', '1', 'Laptop Battery For Bimlesh ', 'Laptop Battery For Bimlesh ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '22', '1', '1', '', '', '1', '', '1', '0'),
('BAT-LAP-HPOA04', '3', '1', 'Lap care battery (HPOA04)', 'Lap care battery (HPOA04)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '22', '1', '1', '', '', '1', '', '1', '0'),
('BAT-LAP-INEX', '3', '1', 'Dell inspiron laptop battery (Lapkit inex)', 'Dell inspiron laptop battery (Lapkit inex)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '22', '1', '1', '', '', '1', '', '1', '0'),
('BAT-LAP-LAOBT6C2196', '3', '1', 'Laptop Battery for Acer Laptop (LAOBT6C2196)', 'Laptop Battery for Acer Laptop (LAOBT6C2196)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '22', '1', '1', '', '', '1', '', '1', '0'),
('BAT-LAP-N4010', '3', '1', 'Dell laptop Battery(DELL Inspiron 14R(N4010) 6 Cell Laptop Battery)', 'Dell laptop Battery(DELL Inspiron 14R(N4010) 6 Cell Laptop Battery)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '22', '1', '1', '', '', '1', '', '1', '0'),
('BAT-LAP-OA04', '3', '1', 'Lapcare Compatible battery ( OA04)', 'Lapcare Compatible battery ( OA04)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '22', '1', '1', '', '', '1', '', '1', '0'),
('BAT-LAP-TC-3817U', '3', '1', 'Laptop Battery for standby laptop Thoshiba ( Modal no :- TC-3817U', 'Laptop Battery for standby laptop Thoshiba ( Modal no :- TC-3817U', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '22', '1', '1', '', '', '1', '', '1', '0'),
('BAT-MICRO-L', '3', '1', 'Micro Lithium ion Battery  ', 'Micro Lithium ion Battery  ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '25', '1', '1', '', '', '1', '', '1', '0'),
('BAT-UPS-HB1875', '3', '1', '                     MICROTEK SINE WAVE INVERTER UPS HB1875', '                     MICROTEK SINE WAVE INVERTER UPS HB1875', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '19', '1', '1', '', '', '1', '', '1', '0'),
('Benq24INCH', '7', '1', 'Monitor Benq 24&quot;', 'Monitor Benq 24&quot;', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '29', '1', '', '', '', '0', '0', '1', '0'),
('BENQ27INCH', '7', '1', 'Benq 27&quot;  Monitor', 'Benq 27&quot;  Monitor', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '29', '1', '', '', '', '0', '0', '1', '0'),
('BIOCARD', '4', '1', 'Biometric Card Access ', 'Biometric Card Access ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '1', '1', '1', '', '', '1', '', '1', '0'),
('CardGraphics', '7', '1', 'Graphics Crad', 'Graphics Crad', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '13', '1', '', '', '', '0', '0', '1', '0'),
('Corsair2', '7', '1', 'Cabinet Corsair 2', 'Cabinet Corsair 2', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '1', '', '', '0', '1002', '0', '0'),
('Corsairone', '7', '1', 'Cabinet Corsair One', 'Cabinet Corsair One', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('CorsairTwo', '7', '1', 'Cabinet Corsair Two', '', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('Corsiar1', '7', '1', 'Cabinet Corsiar 1', 'Cabinet Corsiar 1', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('Cpu-i3-2.4G-4gb-LAP', '10', '1', 'Cpu-i3 2.4 Ghz, RAM-4GB,SSD-240 GB ( Stand by Laptop )', 'Cpu-i3 2.4 Ghz, RAM-4GB,SSD-240 GB ( Stand by Laptop )', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '5', '', '1', '0'),
('CPU-I3-2330M-2.20-L', '10', '1', 'CPU- i3-2330M-2.20GHz, RAM-8GB, SSD-500 GB (Acer Laptop)', 'CPU- i3-2330M-2.20GHz, RAM-8GB, SSD-500 GB (Acer Laptop)', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '5', '', '1', '0'),
('CPU-I3-4005U-1.70GH', '10', '1', 'CPU- i3-4005U-1.70GHz, RAM-12GB, SSD-500 GB (HP 15 Notebook Laptop),', 'CPU- i3-4005U-1.70GHz, RAM-12GB, SSD-500 GB (HP 15 Notebook Laptop),', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '5', '', '1', '0'),
('CPU-I3-4005U-1.70GHL', '-1', '1', 'CPU- i3-4005U-1.70GHz, RAM-12GB, SSD-500 GB (HP 15 Notebook Laptop)', 'CPU- i3-4005U-1.70GHz, RAM-12GB, SSD-500 GB (HP 15 Notebook Laptop)', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '-1', '1', '1', '', '', '0', '1002', '1', '0'),
('CPU-I3-6100U-2.30-L', '10', '1', 'CPU- i3-6100U-2.30GHz, RAM-8GB, SSD-500 GB (Lenevo Laptop)', 'CPU- i3-6100U-2.30GHz, RAM-8GB, SSD-500 GB (Lenevo Laptop For WFH)', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '5', '', '1', '0'),
('CPU-I5-1035G1-1.0-L', '10', '1', 'CPU- i5-1035G1-1.00GHz, RAM-8GB, SSD-500 GB ', 'CPU- i5-1035G1-1.00GHz, RAM-8GB, SSD-500 GB ASUS Laptop', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '5', '', '1', '0'),
('CPUI7-1260P-RAM-16G', '10', '1', 'CPU- i7-1260P, RAM-16GB, SSD- 1TB', 'CPU- i7-1260P, RAM-16GB, SSD- 1TB Hp Pavillion Laptop', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '0', '1002', '1', '0'),
('DELL24INCH', '7', '1', 'Dell 24&quot; Monitor', 'Dell 24&quot; Monitor', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '29', '1', '', '', '', '0', '0', '1', '0'),
('delll-lap', '10', '1', 'dell inspiration', 'i3 500 gb 8 ram', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '5', '0', '1', '0'),
('DL-ESSL-EML600-2', '12', '1', 'Door Lock Essl Em ( Modal No :- EML600-2 )', 'Door Lock Essl Em ( Modal No :- EML600-2 )', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '8', '1', '1', '', '', '1', '', '1', '0'),
('DoubleJackF10', '7', '1', 'Double Jack F10 Headphone', 'Double Jack F10 Headphone', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '17', '1', '', '', '', '0', '0', '1', '0'),
('DS-2CD1323G0E-I ', '6', '1', 'Hikvision Dome Camera Moadl no :- ( DS-2CD1323G0E-I )', 'Hikvision Dome Camera Moadl no :- ( DS-2CD1323G0E-I )', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '5', '1', '1', '', '', '1', '', '1', '0'),
('DS-2CD2023G2-IU', '6', '1', 'Hikvision Bullet Camea:- Modal no :- ( DS-2CD2023G2-IU )', 'Hikvision Bullet Camea:- Modal no :- ( DS-2CD2023G2-IU )', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '5', '1', '1', '', '', '1', '', '1', '0'),
('DS-2CE1AC0T-IRPF', '6', '1', 'Hikvision Bullet camera ( Modal no :- DS-2CE1AC0T-IRPF = 1 Mp ) ', 'Hikvision Bullet camera ( Modal no :- DS-2CE1AC0T-IRPF = 1 Mp ) ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '5', '1', '1', '', '', '1', '', '1', '0'),
('ESSL-AM-X990', '4', '1', 'Attandance Machine Essl  (Model no :-  X990 + ID)', 'Attandance Machine Essl  (Model no :-  X990 + ID)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '38', '1', '1', '', '', '1', '', '1', '0'),
('ESSL-FR1200 ', '4', '1', 'Fingure Reaer Essl ( Modal no :- FR1200 , RS 485 )', 'Fingure Reaer Essl ( Modal no :- FR1200 , RS 485 )', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '9', '1', '1', '', '', '1', '', '1', '0'),
('FB-CPU-Test', '16', '1', 'test', 'test cpu', 'box', 'MC', '', '', '', '', '', NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '49', '1', '', '', '', '0', '', '1', '0'),
('FB-CPU-Test21', '16', '1', 'test21', 'test cpu21', 'box', 'MC', '', '', '', '', '', NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '49', '1', '', '', '', '0', '', '1', '0'),
('FingersAscend1', '7', '1', 'Cabinet Fingers Ascend 1', 'Cabinet Fingers Ascend 1', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('FingersAscend2', '7', '1', 'Cabinet Fingers Ascend 2', 'Cabinet Fingers Ascend 2', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('FingersAscend3', '7', '1', 'Cabinet Fingers Ascend 3', 'Cabinet Fingers Ascend 3', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('FingersAscend4', '7', '1', 'Cabinet Fingers Ascend 4', 'Cabinet Fingers Ascend 4', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('FingersAscend5', '7', '1', 'Cabinet Fingers Ascend 5', 'Cabinet Fingers Ascend 5', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('FingersAscend6', '7', '1', 'Cabinet Fingers Ascend 6', 'Cabinet Fingers Ascend 6', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('FingersAscend7', '7', '1', 'Cabinet Fingers Ascend 7', 'Cabinet Fingers Ascend 7', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('FingersAscendFive', '7', '1', 'Cabinet Fingers Ascend Five', 'Cabinet Fingers Ascend Five', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('FingersAscendFour', '7', '1', 'Cabinet Fingers Ascend Four', 'Fingers Ascend Four', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('FingersAscendOne', '7', '1', 'Cabinet Fingers Ascend One', 'Cabinet Fingers Ascend One', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('FingersAscendSeven', '7', '1', 'Cabinet Fingers Ascend Seven', 'Fingers Ascend Seven', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('FingersAscendSix', '7', '1', 'Cabinet Fingers Ascend Six', 'Cabinet Fingers Ascend Six', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('FingersAscendThree', '7', '1', 'Cabinet Fingers Ascend Three', 'Cabinet Fingers Ascend Three', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('FingersAscendTwo', '7', '1', 'Cabinet Fingers Ascend Two', 'Cabinet Fingers Ascend Two', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('FrontechFusion1', '7', '1', 'Cabinet Frontech Fusion 1', 'Cabinet Frontech Fusion 1', 'PC', 'D', '1002', '', '', '', '', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('FrontechFusionnew', '7', '1', 'Cabinet Frontech Fusion 1', 'Cabinet Frontech Fusion 1', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('FrontechFusionone', '7', '1', 'Cabinet Frontech Fusion One', 'Cabinet Frontech Fusion One', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('FrontechJewl1', '7', '1', 'Cabinet Frontech Jewl 1', 'Cabinet Frontech Jewl 1', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('FrontechJewlone', '7', '1', 'Cabinet Frontech Jewl one', 'Cabinet Frontech Jewl one', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('FrontechPolo', '7', '1', 'Cabinet Frontech Polo', 'Cabinet Frontech Polo', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('FrontechPoloone', '7', '1', 'Cabinet Frontech Polo one', 'Cabinet Frontech Polo one', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('GamingCircle1', '7', '1', 'Circle Gaming Cabinet 1', 'Circle Gaming Cabinet 1', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('GamingCircle2', '7', '1', 'Cabinet Gaming Circle 2', 'Cabinet Gaming Circle 2', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('GamingCircleone', '7', '1', 'Circle Gaming Cabinet one', 'Circle Gaming Cabinet one', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('GamingCircleTwo', '7', '1', 'Cabinet Gaming Circle Two', 'Cabinet Gaming Circle Two', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('GamingHeadphone', '7', '1', 'Logitech Gaming Headphone', 'Logitech Gaming Headphone\r\n', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '17', '1', '', '', '', '0', '0', '1', '0'),
('GEN-JSPF-35X-3PH', '9', '1', '35 KVA Jakson Cummions Gen-set  3 Phase ( JSPF-35X (3PH)', '35 KVA Jakson Cummions Gen-set  3 Phase ( JSPF-35X (3PH)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '12', '1', '1', '', '', '1', '', '1', '0'),
('GEN-SNMP-MCY-EN', '9', '1', 'SNMP CARD ( SNMP web pro   Modal no :- SNMP-MCY-EN )', 'SNMP CARD ( SNMP web pro   Modal no :- SNMP-MCY-EN )', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '12', '1', '1', '', '', '1', '', '1', '0'),
('GigabyteMBD', '7', '1', 'Gigabyte Motherboard ', 'Gigabyte Motherboard ', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '30', '1', '', '', '', '0', '0', '1', '0'),
('Graphicscard2GB', '7', '1', 'Graphics card 2GB', 'Graphics card 2GB', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '1', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '13', '1', '', '', '', '0', '0', '1', '0'),
('Graphicscard4GB', '7', '1', 'Graphics card 4GB', 'Graphics card 4GB', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '1', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '13', '1', '', '', '', '0', '0', '1', '0'),
('Graphicscard8GB', '7', '1', 'Graphics card 8GB', 'Graphics card 8GB', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '1', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '13', '1', '', '', '', '0', '0', '1', '0'),
('HDMI-CONVERTER', '7', '1', 'Display port to Feamle HDMI converter ', 'Display port to Feamle HDMI converter ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '16', '1', '1', '', '', '1', '', '1', '0'),
('HEADPHONE-G231', '7', '1', 'Logitech gaming headphone G231 prodigy ', 'Logitech gaming headphone G231 prodigy ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '17', '1', '1', '09-12-2021', '30-12-2022', '1', '', '1', '0'),
('HEADPHONE-G340', '7', '1', 'Ligitech H340 usb headphone ', 'Ligitech H340 usb headphone ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '17', '1', '1', '', '', '1', '', '1', '0'),
('HEADPHONE-H-111', '7', '1', 'Logitech H111 Singal jack Headphone ', 'Logitech H111 Singal jack Headphone ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '17', '1', '1', '', '', '1', '', '1', '0'),
('HEADPHONE-H-340', '7', '1', 'Ligitech H340 usb headphone ', 'Ligitech H340 usb headphone ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '17', '1', '1', '', '', '1', '', '1', '0'),
('HEADPHONE-H5', '7', '1', 'Finger&#039;s show stoper H5', 'Finger&#039;s show stoper H5', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '17', '1', '1', '', '', '1', '', '1', '0'),
('HEADPHONE-H9', '7', '1', 'Finger&#039;s Usb-Tonic H9 Hedaphone', 'Finger&#039;s Usb-Tonic H9 Hedaphone', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '17', '1', '1', '', '', '1', '', '1', '0'),
('i3EightGen', '7', '1', 'i3 Eight Gen', 'i3 Eight Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('i3EleventhGen', '7', '1', 'i3 Eleventh Gen', 'i3 Eleventh Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('i3NinthGen', '7', '1', 'i3 Ninth Gen', 'i3 Ninth Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('i3sixthgen', '7', '1', 'i3 Sixth Gen', 'i3 Sixth Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('i3TenthGen', '7', '1', 'i3 Tenth Gen', 'i3 Tenth Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('i3thirdGen', '7', '1', 'Cpu i3 3rd Gen', 'Cpu i3 3rd Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('i3TwelthGen', '7', '1', 'i3 Twelth Gen', 'i3 Twelth Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('i5EightGen', '7', '1', 'i5 Eight Gen', 'i5 Eight Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('i5EleventhGen', '7', '1', 'i5 Eleventh Gen', 'i5 Eleventh Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('i5NinthGen', '7', '1', 'i5 Ninth Gen', 'i5 Ninth Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('i5SixthGen', '7', '1', 'i5 Sixth Gen', 'i5 Sixth Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('i5TenthGen', '7', '1', 'i5 Tenth Gen', 'i5 Tenth Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('i5ThirdGen', '7', '1', 'i5 Third Gen', 'i5 Third Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('i7EightGen', '7', '1', 'i7 Eight Gen', 'i7 Eight Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('i7SeventhGen', '7', '1', 'i7 Seventh Gen', 'i7 Seventh Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('i7SixthGen', '7', '1', 'i7 Sixth Gen', 'i7 Sixth Gen', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '7', '1', '', '', '', '0', '0', '1', '0'),
('Iball1', '7', '1', 'Cabinet I ball 1', 'Cabinet I ball 1', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('Iballone', '7', '1', 'Cabinet I ball one', '', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('L-BAG-HP', '2', '1', 'Laptop Bag for Hp Pavillion ', 'Laptop Bag for Hp Pavillion ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '24', '1', '1', '', '', '1', '', '1', '0'),
('L-BAG-LENOVO', '2', '1', 'Lenovo Bagpack ', 'Lenovo Bagpack ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '24', '1', '1', '', '', '1', '', '1', '0'),
('L-BAG-LP-BLUE', '2', '1', 'Bag (HS.CANVOBNP L P 01 Blue)', 'Bag (HS.CANVOBNP L P 01 Blue)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '24', '1', '1', '', '', '1', '', '1', '0'),
('L-BAG-LP-GRAY', '2', '1', 'Bag (HS.CANVOBNP L P 01 Gray)', 'Bag (HS.CANVOBNP L P 01 Gray)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '24', '1', '1', '', '', '1', '', '1', '0'),
('LAP-ASUS-X509J', '10', '1', 'Asus Laptop vivo book ( X509J )', 'Asus Laptop vivo book ( X509J )', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '1', '', '1', '0'),
('LAP-DELL-14', '10', '1', 'Dell inspiron laptop ( 14&quot; paper 40 pin )', 'Dell inspiron laptop ( 14&quot; paper 40 pin )', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '1', '', '1', '0'),
('LAP-DELL-I3-8GB-1TB', '10', '1', 'CPU- i3-1115G4-3.00GHz, RAM-8GB, SSD-1TB,', 'CPU- i3-1115G4-3.00GHz, RAM-8GB, SSD-1TB, (Laptop: Dell Inspiron 15 3511)', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '5', '', '1', '0'),
('LAP-DELL-IP-3511', '10', '1', 'Dell New 2022 Inspiron 3511 (Modal No:- Inspiron 3511, i3 11th gen, 8GB DDR4,256 GB Nvme,1TB HDD)', 'Dell New 2022 Inspiron 3511 (Modal No:- Inspiron 3511, i3 11th gen, 8GB DDR4,256 GB Nvme,1TB HDD)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '1', '', '1', '0'),
('LAP-HP-15-EG2039TU', '10', '1', 'Hp Pavillion Laptop :- 15-EG2039TU ( i7-1260P . 16 GB RAM , 1 TB NVME 15.6&quot; Display )', 'Hp Pavillion Laptop :- 15-EG2039TU ( i7-1260P . 16 GB RAM , 1 TB NVME 15.6&quot; Display )', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '1', '', '1', '0'),
('LAP-HP-15Q', '10', '1', 'Laptop HP 15Q core i5 8th gen 8 GB ', 'Laptop HP 15Q core i5 8th gen 8 GB ', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '0', '', '1', '0'),
('LAP-HP-EG2039TU', '10', '1', 'Hp Pavillion Laptop :- 15-EG2039TU ( i7-1260P . 16 GB RAM , 1 TB NVME 15.6&quot; Display )', 'Hp Pavillion Laptop :- 15-EG2039TU ( i7-1260P . 16 GB RAM , 1 TB NVME 15.6&quot; Display )', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '1', '', '1', '0'),
('LAP-HP-I5', '10', '1', 'LAP-HP-I5-8GB', 'CPU- i5-5200U-2.20GHz, RAM-8GB, SSD-500 GB (Laptop- HP PAVILION 15-P0204TX Notebook)  Logitech usb keyboard,Mouse &amp; Finger&#039;s F10 Hradphone\r\n', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '5', '', '1', '0'),
('LAP-HP-I5-2.2-8GB', '10', '1', 'CPU- i5-5200U-2.20GHz, RAM-8GB, SSD-500 GB', 'CPU- i5-5200U-2.20GHz, RAM-8GB, SSD-500 GB (Laptop- HP PAVILION 15-P0204TX Notebook)', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '5', '', '1', '0'),
('LAP-I5-16GB-SSD-500G', '10', '1', 'CPU- i5-10400-2.90GHz, RAM-16GB, ', 'CPU- i5-10400-2.90GHz, RAM-16GB, SSD-500 GB,MBD-Gigabyte,', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '0', '1002', '1', '0'),
('LAP-I7-16GB-500GB', '10', '1', 'CPU-I7-1165G7,RAM-16GB, SSD-500GB ', 'CPU- i7-1165G7,RAM-16GB, SSD-500GB                                                         ( Lenovo IdeaPad 5 Pro with laptop bag 14ITL6 ,S/N-MP23AXA6 )', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '5', '', '1', '0'),
('LAP-IPAD-A1893', '10', '1', 'Apple i pad  (Modal no :-A1893)', 'Apple i pad  (Modal no :-A1893)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '20', '1', '1', '', '', '1', '', '1', '0'),
('LAP-IPAD-L14ITL6 ', '10', '1', 'Lenovo IdeaPad 5 Pro 14ITL6 ( i7-1165G7 2.80Ghz , 16 GB RAM ,500GB NVME)', 'Lenovo IdeaPad 5 Pro 14ITL6 ( i7-1165G7 2.80Ghz , 16 GB RAM ,500GB NVME)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '20', '1', '1', '', '', '1', '', '1', '0'),
('LAP-SUM-MO1', '10', '1', 'Samsung Core MO1 ( SM -M013F/DS )   For Shivani', 'Samsung Core MO1 ( SM -M013F/DS )   For Shivani', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '23', '1', '1', '', '', '1', '', '1', '0'),
('LAPCARE-LCP-111', '11', '1', 'Laptop Cooling Pad (Lapcare :- LCP-111)', 'Laptop Cooling Pad (Lapcare :- LCP-111)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '6', '1', '1', '', '', '1', '', '1', '0'),
('LG14INCH', '7', '1', 'Lg 14&quot; Monitor', 'Lg 14&quot; Monitor', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '29', '1', '', '', '', '0', '0', '1', '0'),
('LG19INCH', '7', '1', 'Lg 19&quot; Monitor', 'Lg 19&quot; Monitor', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '29', '1', '', '', '', '0', '0', '1', '0'),
('LG22INCH', '7', '1', 'LG 22&quot; Monitor', 'LG 22&quot; Monitor', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '29', '1', '', '', '', '0', '0', '1', '0'),
('LOGI-WEBCAM-C270', '7', '1', 'Logitech Web Cam ( C270 )', 'Logitech Web Cam ( C270 )', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '48', '1', '1', '28-12-2021', '28-12-2021', '1', '', '1', '0'),
('Logitechcombokbdmous', '7', '1', 'Logitech Combo Kbd Mouse', 'Logitech Combo Kbd Mouse', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '21', '1', '', '', '', '0', '0', '1', '0'),
('LOGITECHWEBCAM', '7', '1', 'Logitech Usb Web Cam', 'Logitech Usb Web Cam', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '48', '1', '', '', '', '0', '0', '1', '0'),
('M-CHARGE-MI', '13', '1', 'Mi Sonic Charger 2.0 Modal No :- MDY-11-EL ', 'Mi Sonic Charger 2.0 Modal No :- MDY-11-EL ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '28', '1', '1', '', '', '1', '', '1', '0'),
('M-MICROMAX-412', '13', '1', 'Micromax x412 Mobile Phone with Adaptor ( ACC05C14)', 'Micromax x412 Mobile Phone with Adaptor ( ACC05C14)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '27', '1', '1', '', '', '1', '', '1', '0'),
('M-REDMI-9', '13', '1', 'Redmi 9 Power Modal No :- M2010J19SI (Electric Green, 4GB RAM, 64GB Storage) - 6000mAh Battery B089MS8HPF                         ( REDMI9PWGREEN-4+64GB )', 'Redmi 9 Power Modal No :- M2010J19SI (Electric Green, 4GB RAM, 64GB Storage) - 6000mAh Battery B089MS8HPF                         ( REDMI9PWGREEN-4+64GB )', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '27', '1', '1', '', '', '1', '', '1', '0'),
('MOUSE-PAD', '7', '1', 'Mouse pad', 'Mouse pad', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '33', '1', '1', '', '', '1', '', '1', '0'),
('MTB-B360M-D3H', '7', '1', 'Gigabyte B360M-D3H Motherboard', 'Gigabyte B360M-D3H Motherboard', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '1', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '30', '1', '1', '', '', '0', '1002', '1', '0'),
('MTB-B460M-DS3H-V2', '7', '1', 'Gigabyte B460M DS3H V2', 'Gigabyte B460M DS3H V2', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '1', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '30', '1', '1', '', '', '0', '1002', '1', '0'),
('MTB-B56OM-DS3H-AC', '7', '1', 'Motherboard Gigabyte  Modal No :-(B56OM-DS3H:AC) ', 'Motherboard Gigabyte  Modal No :-(B56OM-DS3H:AC) ', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '1', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '30', '1', '1', '', '', '0', '1002', '1', '0'),
('MTB-H110', '7', '1', 'Gigabyte H110 M/b', 'Gigabyte H110 M/b', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '1', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '30', '1', '1', '', '', '0', '1002', '1', '0'),
('MTB-SNMP-MCY-EN', '7', '1', 'SNMP CARD ( SNMP web pro   Modal no :- SNMP-MCY-EN )', 'SNMP CARD ( SNMP web pro   Modal no :- SNMP-MCY-EN )', 'PC', 'M', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '30', '1', '1', '', '', '1', '', '1', '0'),
('MUSIC-WOOFER', '7', '1', 'Zook Woofer + Wireless Mic (ZB-Rocker Thunder XL)', 'Zook Woofer + Wireless Mic (ZB-Rocker Thunder XL)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '32', '1', '1', '', '', '1', '', '1', '0'),
('OneGigabyte', '7', '1', 'Cabinet Gaming Gigabyte one', 'Cabinet Gaming Gigabyte one', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('PRECISION-110', '7', '1', 'Screwdriver 110 in 1 set Precision ', 'Screwdriver 110 in 1 set Precision ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '36', '1', '1', '', '', '1', '', '1', '0'),
('President1', '7', '1', 'Cabinet President 1', 'Cabinet President 1', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('President2', '7', '1', 'Cabinet President 2', 'Cabinet President 2', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '0', '0'),
('PresidentOne', '7', '1', 'Cabinet President 1', 'Cabinet President 1', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('PresidentTwo', '7', '1', 'Cabinet President Two', 'Cabinet President Two', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '0', '1', '0'),
('PRO-I3-8GEN', '8', '1', 'I3 8th gen processor', 'I3 8th gen processor', 'PC', 'M', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '37', '1', '1', '', '', '1', '', '1', '0'),
('PRO-I5-11GEN', '8', '1', 'Processor i5 11th gen 2.6 GHZ LGA 1200 ( i5-11400 BX8070811400) ', 'Processor i5 11th gen 2.6 GHZ LGA 1200 ( i5-11400 BX8070811400) ', 'PC', 'M', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '37', '1', '1', '', '', '1', '', '1', '0'),
('RACK-2U', '14', '1', 'D.LINK 2U RACK', 'D.LINK 2U RACK', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '39', '1', '1', '', '', '1', '', '1', '0'),
('RACK-D-2U', '14', '1', 'D-Link 2U Rack ', 'D-Link 2U Rack ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '39', '1', '1', '', '', '1', '', '1', '0'),
('RAM-32GB', '7', '1', 'RAM-32GB', 'RAM-32GB', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '40', '1', '1', '', '', '0', '1002', '1', '0'),
('RAM-DDR3-8GB', '7', '1', 'RAM DDR-3    8 GB Kingston 1333 Mhz', 'RAM DDR-3    8 GB Kingston 1333 Mhz', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '1', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '40', '1', '1', '', '', '0', '1002', '1', '0'),
('RAM-DDR4-16GB', '7', '1', '16 GB 3000 Mhz DDR4 CORSIAR VEN RAM', '16 GB 3000 Mhz DDR4 CORSIAR VEN RAM', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '1', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '40', '1', '1', '', '', '0', '1002', '1', '0'),
('RAM-DDR4-8GB', '7', '1', 'Corsiar DDR 4 RAM 8 GB 3000 Mhz', 'Corsiar DDR 4 RAM 8 GB 3000 Mhz', 'PC', 'M', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '40', '1', '1', '', '', '1', '', '1', '0'),
('REALME-TV-32', '15', '1', 'REALME 32&quot; INCH ANDROID TV', 'REALME 32&quot; INCH ANDROID TV', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '42', '1', '1', '', '', '1', '', '1', '0'),
('ROUT-D--DGS-1210-28', '14', '1', 'D-Link Systems 28-Port Gigabit Web Smart (DGS-1210-28)', 'D-Link Systems 28-Port Gigabit Web Smart (DGS-1210-28)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '41', '1', '1', '', '', '1', '', '1', '0'),
('ROUT-D-DGS-1210-5', '14', '1', 'Dlink 52 Port switch( 52-Port Gigabit Smart Managed Switch DGS-1210-5)', 'Dlink 52 Port switch( 52-Port Gigabit Smart Managed Switch DGS-1210-5)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '41', '1', '1', '', '', '1', '', '1', '0'),
('ROUT-D-DGS-1210-52', '14', '1', 'D LINK 48PORT SWITCH (DGS-1210-52)', 'D LINK 48PORT SWITCH (DGS-1210-52)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '41', '1', '1', '', '', '1', '', '1', '0'),
('ROUT-D-WIFI-001-DIR-825', '14', '1', 'D-Link DIR-825 AC 1200 Wi-Fi Dual-Band Gigabit (LAN/WAN) Router | B098DTPWSM ( IT-ROUTER-001-DIR-825 )', 'D-Link DIR-825 AC 1200 Wi-Fi Dual-Band Gigabit (LAN/WAN) Router | B098DTPWSM ( IT-ROUTER-001-DIR-825 )', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '41', '1', '1', '', '', '1', '', '1', '0'),
('ROUT-H-DS-3E0510P-E/M ', '14', '1', 'Hikvision 8 Port Gigabit Poe Unmangged switch :-Modal No :- DS-3E0510P-E/M ', 'Hikvision 8 Port Gigabit Poe Unmangged switch :-Modal No :- DS-3E0510P-E/M ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '41', '1', '1', '', '', '1', '', '1', '0'),
('ROUT-H-DS-7632NI-K2', '14', '1', 'Hikvision Embeded NVR Modal No :- ( DS-7632NI-K2)', 'Hikvision Embeded NVR Modal No :- ( DS-7632NI-K2)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '41', '1', '1', '', '', '1', '', '1', '0'),
('ROUT-TP-AC600', '14', '1', 'TP-Link AC600 (Modal No :- Archer T2U Plus ver 1.0)', 'TP-Link AC600 (Modal No :- Archer T2U Plus ver 1.0)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '41', '1', '1', '', '', '1', '', '1', '0');
INSERT INTO `fa_stock_master` VALUES
('ROUT-TP-UE300', '14', '1', 'TP-Link UE300 USB 3.0 to RJ45 Gigabit Ethernet (UE300)', 'TP-Link UE300 USB 3.0 to RJ45 Gigabit Ethernet (UE300)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '41', '1', '1', '', '', '1', '', '1', '0'),
('ROUT-TP-WN823N', '14', '1', 'Tp-Link 300 Mbps (TP-WN823N)', 'Tp-Link 300 Mbps (TP-WN823N)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '41', '1', '1', '', '', '1', '', '1', '0'),
('ROUT-WIFI-A-RT-AX55', '14', '1', 'Wi-Fi Router With Mac binding feature Asus Modal No :- ( RT-AX55)', 'Wi-Fi Router With Mac binding feature Asus Modal No :- ( RT-AX55)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '41', '1', '1', '', '', '1', '', '1', '0'),
('SAMSUNG24INCH', '7', '1', 'Sansung 24&quot; Monitor', 'Sansung 24&quot; Monitor', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '29', '1', '', '', '', '0', '0', '1', '0'),
('SingleJackH5HeadPh', '7', '1', 'Single Jack H5 Head Phone', 'Single Jack H5 Head Phone', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '17', '1', '', '', '', '0', '0', '1', '0'),
('SMPS-ANTEC-VP-450', '7', '1', 'ANTEC VP 450 SMPS (VP450P PLUS IN V3000A200H-18) 450 Watt ', 'ANTEC VP 450 SMPS (VP450P PLUS IN V3000A200H-18) 450 Watt ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '43', '1', '1', '', '', '1', '', '1', '0'),
('SMPS-CORSIAR-450', '7', '1', 'Corsiar 450 Watt smps ', 'Corsiar 450 Watt smps ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '43', '1', '1', '', '', '1', '', '1', '0'),
('SMPS-F-G-12-407', '7', '1', 'SMPS Fingers gama-12-407', 'SMPS Fingers gama-12-407', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '43', '1', '1', '', '', '1', '', '1', '0'),
('SMPS-F-G-401', '7', '1', 'SMPS Finger&#039;s Gamma-401 ', 'SMPS Finger&#039;s Gamma-401 ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '43', '1', '1', '', '', '1', '', '1', '0'),
('SMPS-F-GAMA-401', '7', '1', 'Fingures SMPS (GAMA-401)', 'Fingures SMPS (GAMA-401)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '43', '1', '1', '', '', '1', '', '1', '0'),
('SMPS-F-P-400', '7', '1', 'Finger&#039;s Polonium-400', 'Finger&#039;s Polonium-400', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '43', '1', '1', '', '', '1', '', '1', '0'),
('SMPS-FA-C3', '7', '1', 'Cabinet Finger&#039;s Ascend c3 with SMPS ', 'Cabinet Finger&#039;s Ascend c3 with SMPS ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '43', '1', '1', '', '', '1', '', '1', '0'),
('SMPS-I-ZPS-281', '7', '1', 'SMPS  I Ball :- ZPS-281 ', 'SMPS  I Ball :- ZPS-281 ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '43', '1', '1', '', '', '1', '', '1', '0'),
('SMPS-S-H5', '7', '1', 'Finger&#039;s show stoper H5', 'Finger&#039;s show stoper H5', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '43', '1', '1', '', '', '1', '', '1', '0'),
('UPS-10-KVA', '7', '1', 'ON LINE UPS ( I -Max 10 KVA/192 V )', 'ON LINE UPS ( I -Max 10 KVA/192 V )', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '46', '1', '1', '', '', '1', '', '1', '0'),
('UPS-600-VA', '7', '1', 'UPS LUMINIOUS 600VA', 'UPS LUMINIOUS 600VA', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '46', '1', '1', '', '', '1', '', '1', '0'),
('USB-LINK-HUB', '7', '1', 'Usb ( 1 Gbps Lan + 3.1 Usb ) Tp link Hub', 'Usb ( 1 Gbps Lan + 3.1 Usb ) Tp link Hub', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '2', '1', '1', '', '', '1', '', '1', '0'),
('USB-PENDRIVE-64GB', '7', '1', 'SanDisk Ultra 64 GB USB Pen Drives (SDDDC2-064G-I35, Black, Silver) | B01EZ0X3L8 ', 'SanDisk Ultra 64 GB USB Pen Drives (SDDDC2-064G-I35, Black, Silver) | B01EZ0X3L8 ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '34', '1', '1', '', '', '1', '', '1', '0'),
('USB-PORT-HUB4', '7', '1', 'USB 3.1 Gen:1    4 Port Hub (  QZ-HB03)', 'USB 3.1 Gen:1    4 Port Hub (  QZ-HB03)', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '47', '1', '1', '', '', '1', '', '1', '0'),
('USB-SOUND', '7', '1', 'Usb sound card ', 'Usb sound card ', 'PC', 'B', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '44', '1', '1', '', '', '1', '', '1', '0'),
('USBH340', '7', '1', 'USB H340 Headphone ', 'USB H340 Headphone ', 'PC', 'B', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '17', '1', '', '', '', '0', '0', '1', '0'),
('Zebronics1', '7', '1', 'Zebronics Cabinet', 'Zebronics Cabinet', 'PC', 'M', '1002', '', '1002', '1002', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', 'S', '0', '0', '0000-00-00', '0000-00-00', '', '3', '1', '', '', '', '0', '1002', '1', '0');

### Structure of table `fa_stock_moves` ###

DROP TABLE IF EXISTS `fa_stock_moves`;

CREATE TABLE `fa_stock_moves` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_no` int(11) NOT NULL DEFAULT '0',
  `stock_id` char(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type` smallint(6) NOT NULL DEFAULT '0',
  `loc_code` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `price` double NOT NULL DEFAULT '0',
  `reference` char(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `qty` double NOT NULL DEFAULT '1',
  `standard_cost` double NOT NULL DEFAULT '0',
  `person_id` int(11) NOT NULL,
  `discount_percent` double NOT NULL,
  `visible` int(11) NOT NULL,
  `decrease` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`trans_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_stock_moves` ###

INSERT INTO `fa_stock_moves` VALUES
('1', '1', '16GBDDR3', '25', 'PAT', '2023-09-21', '5', '', '10', '0', '0', '0', '0', '0'),
('2', '2', '1TBHDD', '25', 'PAT', '2023-09-21', '5', '', '10', '0', '0', '0', '0', '0'),
('3', '1', '16GBDDR3', '29', 'PAT', '2023-09-21', '0', '', '-1', '0', '0', '0', '0', '0'),
('4', '1', '1TBHDD', '29', 'PAT', '2023-09-21', '0', '', '-1', '0', '0', '0', '0', '0'),
('5', '1', '1Gigabyte', '26', 'PAT', '2023-09-21', '0', '1', '1', '0', '0', '0', '0', '0'),
('6', '3', 'FB-CPU-Test', '25', 'PAT', '0000-00-00', '0', '3', '1', '0', '0', '0', '0', '0'),
('7', '2', '16GBDDR3', '29', 'PAT', '2023-09-21', '0', '', '-1', '0', '0', '0', '0', '0'),
('8', '2', '1TBHDD', '29', 'PAT', '2023-09-21', '0', '', '-1', '0', '0', '0', '0', '0'),
('9', '2', 'Corsiar1', '26', 'PAT', '2023-09-21', '0', '2', '1', '0', '0', '0', '0', '0'),
('11', '3', '1TBHDD', '28', 'PAT', '2023-09-28', '0', '2', '-1', '0', '0', '0', '0', '1'),
('12', '4', '16GBDDR3', '28', 'PAT', '2023-09-29', '0', '1', '-8', '0', '0', '0', '0', '1'),
('13', '5', '16GBDDR3', '28', 'PAT', '2023-09-29', '0', '1', '-7', '0', '0', '0', '0', '1'),
('14', '3', '16GBDDR3', '25', 'PAT', '2023-10-04', '5', '', '16', '0', '0', '0', '0', '1'),
('15', '6', '16GBDDR3', '28', 'PAT', '2023-10-04', '0', '1', '-5', '0', '0', '0', '0', '1');

### Structure of table `fa_stock_retruns` ###

DROP TABLE IF EXISTS `fa_stock_retruns`;

CREATE TABLE `fa_stock_retruns` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `grp_no` int(11) NOT NULL DEFAULT '0',
  `stock_id` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type` smallint(6) NOT NULL DEFAULT '0',
  `loc_code` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `price` double NOT NULL DEFAULT '0',
  `reference` char(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `qty` double NOT NULL DEFAULT '1',
  `return_status` int(11) NOT NULL DEFAULT '0',
  `item_status` int(11) NOT NULL DEFAULT '0',
  `discount_percent` double NOT NULL,
  `visible` int(11) NOT NULL,
  `osl_no` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`trans_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_stock_retruns` ###


### Structure of table `fa_stock_serial_no` ###

DROP TABLE IF EXISTS `fa_stock_serial_no`;

CREATE TABLE `fa_stock_serial_no` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assmbl_id` int(11) NOT NULL,
  `serial_no` int(11) NOT NULL,
  `inactive` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `sub_asset_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `assmbl_id` (`assmbl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_stock_serial_no` ###


### Structure of table `fa_stock_sub_category` ###

DROP TABLE IF EXISTS `fa_stock_sub_category`;

CREATE TABLE `fa_stock_sub_category` (
  `sub_cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `sub_cat_name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `inactive` tinyint(11) NOT NULL,
  `slab_id` int(11) NOT NULL,
  `effective_date` date NOT NULL,
  `code` int(11) NOT NULL,
  `department_id` varchar(50) NOT NULL,
  `employee_id` varchar(100) NOT NULL,
  PRIMARY KEY (`sub_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1 ;

### Data of table `fa_stock_sub_category` ###

INSERT INTO `fa_stock_sub_category` VALUES
('1', '4', 'ACCESS CARD', 'ACCESS CARD', '0', '2', '2021-05-07', '5248', '', ''),
('2', '7', 'ADAPTOR\r\n', 'ADAPTOR\r\n', '0', '7', '2021-05-07', '525416', '', ''),
('3', '7', 'CABINET', 'CABINET', '0', '2', '2021-12-09', '21235', '', ''),
('4', '5', 'CABLE C TYPE', 'CABLE C TYPE\r\n', '0', '4', '2021-05-07', '25355', '', ''),
('5', '6', 'CCTV', 'CCTV\r\n', '0', '3', '2021-05-07', '2324', '', ''),
('6', '11', 'COOLING PAD\r\n', 'CPU Assemble', '0', '1', '2022-01-19', '26', '', ''),
('7', '7', 'CPU\r\n', 'Electric Vehicle', '0', '1', '2022-01-25', '258', '', ''),
('8', '12', 'DOOR LOCK\r\n', 'DOOR LOCK', '0', '1', '2022-01-25', '258', '', ''),
('9', '4', 'FINGURE REAER\r\n', 'FINGURE REAER', '0', '1', '2022-01-25', '258', '', ''),
('10', '8', 'FIREWALL', 'FIREWALL', '0', '1', '2022-01-25', '258', '', ''),
('11', '7', 'FOOTPEDAL', 'FOOTPEDAL', '0', '1', '2022-01-25', '258', '', ''),
('12', '9', 'GENERATER', 'GENERATER\r\n', '0', '1', '2022-01-25', '258', '', ''),
('13', '7', 'GRAPHIC CARD', 'GRAPHIC CARD\r\n', '0', '1', '2022-01-25', '258', '', ''),
('14', '7', 'HDD\r\n', 'HDD', '0', '1', '2022-01-25', '258', '', ''),
('15', '5', 'HDMI CABLE', 'HDMI CABLE', '0', '1', '2022-01-25', '258', '', ''),
('16', '7', 'HDMI CONVERTER', 'HDMI CONVERTER', '0', '1', '2022-01-25', '258', '', ''),
('17', '7', 'HEADPHONE', 'HEADPHONE', '0', '1', '2022-01-25', '258', '', ''),
('18', '3', 'INVERTER BATTERY', 'INVERTER BATTERY', '0', '1', '2022-01-25', '258', '', ''),
('19', '3', 'INVERTER UPS', 'INVERTER UPS', '0', '1', '2022-01-25', '258', '', ''),
('20', '10', 'IPAD\r\n', 'IPAD\r\n', '0', '1', '2022-01-25', '258', '', ''),
('21', '7', 'KEYBOARD\r\n', 'KEYBOARD\r\n', '0', '1', '2022-01-25', '258', '', ''),
('22', '3', 'LAP BATTERY\r\n', 'LAP BATTERY\r\n', '0', '1', '2022-01-25', '258', '', ''),
('23', '10', 'LAPTOP\r\n', 'LAPTOP\r\n', '0', '1', '2022-01-25', '258', '', ''),
('24', '2', 'LAPTOP BAG\r\n', 'LAPTOP BAG\r\n', '0', '1', '2022-01-25', '258', '', ''),
('25', '3', 'MICRO BATTERY\r\n\r\n', 'MICRO BATTERY\r\n\r\n', '0', '1', '2022-01-25', '258', '', ''),
('26', '7', 'MICROPHONE', 'MICROPHONE', '0', '1', '2022-01-25', '258', '', ''),
('27', '13', 'MOBILE', 'MOBILE', '0', '1', '2022-01-25', '258', '', ''),
('28', '13', 'MOBILE CHARGER', 'MOBILE CHARGER', '0', '1', '2022-01-25', '258', '', ''),
('29', '7', 'MONITOR', 'MONITOR\r\n', '0', '1', '2022-01-25', '258', '', ''),
('30', '7', 'Motherboard', 'Motherboard', '0', '1', '2022-01-25', '258', '', ''),
('31', '7', 'MOUSE\r\n', 'MOUSE', '0', '1', '2022-01-25', '258', '', ''),
('32', '7', 'MUSIC SYSTEM\r\n', 'MUSIC SYSTEM', '0', '1', '2022-01-25', '258', '', ''),
('33', '7', 'PAD\r\n', 'PAD', '0', '1', '2022-01-25', '258', '', ''),
('34', '7', 'PEN DRIVE\r\n', 'PEN DRIVE', '0', '1', '2022-01-25', '258', '', ''),
('35', '5', 'POWER CABLE\r\n', 'POWER CABLE', '0', '1', '2022-01-25', '258', '', ''),
('36', '7', 'PRECISION\r\n', 'PRECISION\r\n', '0', '1', '2022-01-25', '258', '', ''),
('37', '8', 'PROCESSOR\r\n', 'PROCESSOR\r\n', '0', '1', '2022-01-25', '258', '', ''),
('38', '4', 'PUNCH MACHINE\r\n', 'PUNCH MACHINE\r\n', '0', '1', '2022-01-25', '258', '', ''),
('39', '14', 'RACK\r\n', 'RACK\r\n', '0', '1', '2022-01-25', '258', '', ''),
('40', '7', 'RAM\r\n', 'RAM\r\n', '0', '1', '2022-01-25', '258', '', ''),
('41', '14', 'ROUTER\r\n', 'ROUTER\r\n', '0', '1', '2022-01-25', '258', '', ''),
('42', '15', 'Smart TV\r\n', 'Smart TV\r\n', '0', '1', '2022-01-25', '258', '', ''),
('43', '7', 'SMPS\r\n', 'SMPS\r\n', '0', '1', '2022-01-25', '258', '', ''),
('44', '7', 'SOUND CARD\r\n', 'SOUND CARD\r\n', '0', '1', '2022-01-25', '258', '', ''),
('45', '1', 'Split AC\r\n', 'Split AC\r\n', '0', '1', '2022-01-25', '258', '', ''),
('46', '7', 'UPS\r\n', 'UPS\r\n', '0', '1', '2022-01-25', '258', '', ''),
('47', '7', 'USB PORT\r\n', 'USB PORT\r\n', '0', '1', '2022-01-25', '258', '', ''),
('48', '7', 'WEB CAM\r\n', 'WEB CAM\r\n', '0', '1', '2022-01-25', '258', '', ''),
('49', '16', 'CPU', 'Manufacture CPu', '0', '1', '2023-02-08', '2', '', ''),
('50', '1', 'outdoor', 'teststt', '0', '1', '2023-08-07', '25323', '1', 'EMP-F-013'),
('51', '7', 'SSD', 'SSD', '0', '1', '2023-09-12', '258', '1', '');

### Structure of table `fa_stop` ###

DROP TABLE IF EXISTS `fa_stop`;

CREATE TABLE `fa_stop` (
  `id` int(11) NOT NULL,
  `stop_id` varchar(50) NOT NULL,
  `stop_name` varchar(100) NOT NULL,
  `status` int(8) NOT NULL,
  `total_student` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_stop` ###

INSERT INTO `fa_stop` VALUES
('1', 'stop-001', 'ST-001', '1', '0'),
('2', 'stop-002', 'ST-002', '1', '0'),
('3', 'stop-003', 'ST-003', '1', '0'),
('4', 'stop-004', 'ST-004', '1', '0'),
('5', 'stop-005', 'ST-005', '1', '0'),
('6', 'stop-006', 'ST-006', '1', '0'),
('7', 'stop-007', 'ST-007', '1', '0'),
('8', 'stop-008', 'ST-008', '2', '0'),
('9', 'stop-009', 'ST-009', '2', '0'),
('10', 'stop-010', 'ST-010', '2', '0'),
('11', 'stop-011', 'ST-011', '2', '0');

### Structure of table `fa_store_location` ###

DROP TABLE IF EXISTS `fa_store_location`;

CREATE TABLE `fa_store_location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(100) NOT NULL,
  `store` varchar(50) NOT NULL,
  `store_desc` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

### Data of table `fa_store_location` ###

INSERT INTO `fa_store_location` VALUES
('1', 'PAT', 'Nehru nagar', '258 Nehru Nagar', '0');

### Structure of table `fa_sub_asset_master` ###

DROP TABLE IF EXISTS `fa_sub_asset_master`;

CREATE TABLE `fa_sub_asset_master` (
  `sub_asset_id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `code` varchar(100) NOT NULL,
  `inactive` int(11) NOT NULL DEFAULT '0',
  `cat_id` int(11) NOT NULL,
  `sub_cat_id` int(11) NOT NULL,
  `units` varchar(10) NOT NULL,
  `mb_flag` varchar(10) NOT NULL,
  PRIMARY KEY (`sub_asset_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ;

### Data of table `fa_sub_asset_master` ###

INSERT INTO `fa_sub_asset_master` VALUES
('3', '1', 'cpu250rI3/1', '0', '1', '3', '', '');

### Structure of table `fa_supp_allocations` ###

DROP TABLE IF EXISTS `fa_supp_allocations`;

CREATE TABLE `fa_supp_allocations` (
  `id` int(11) NOT NULL,
  `person_id` int(11) DEFAULT NULL,
  `amt` double unsigned DEFAULT NULL,
  `date_alloc` date NOT NULL DEFAULT '0000-00-00',
  `trans_no_from` int(11) DEFAULT NULL,
  `trans_type_from` int(11) DEFAULT NULL,
  `trans_no_to` int(11) DEFAULT NULL,
  `trans_type_to` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_supp_allocations` ###


### Structure of table `fa_supp_invoice_items` ###

DROP TABLE IF EXISTS `fa_supp_invoice_items`;

CREATE TABLE `fa_supp_invoice_items` (
  `id` int(11) NOT NULL,
  `supp_trans_no` int(11) DEFAULT NULL,
  `supp_trans_type` int(11) DEFAULT NULL,
  `gl_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `grn_item_id` int(11) DEFAULT NULL,
  `po_detail_item_id` int(11) DEFAULT NULL,
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` tinytext COLLATE utf8_unicode_ci,
  `quantity` double NOT NULL DEFAULT '0',
  `unit_price` double NOT NULL DEFAULT '0',
  `unit_tax` double NOT NULL DEFAULT '0',
  `memo_` tinytext COLLATE utf8_unicode_ci,
  `dimension_id` int(11) NOT NULL DEFAULT '0',
  `dimension2_id` int(11) NOT NULL DEFAULT '0',
  `gst` double NOT NULL,
  `gst_amt` double NOT NULL,
  `cst` double NOT NULL,
  `cst_amt` double NOT NULL,
  `ist` double NOT NULL,
  `ist_amt` double NOT NULL,
  `hsn_no` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_supp_invoice_items` ###


### Structure of table `fa_supp_trans` ###

DROP TABLE IF EXISTS `fa_supp_trans`;

CREATE TABLE `fa_supp_trans` (
  `trans_no` int(11) unsigned NOT NULL DEFAULT '0',
  `type` smallint(6) unsigned NOT NULL DEFAULT '0',
  `supplier_id` int(11) unsigned NOT NULL DEFAULT '0',
  `reference` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `supp_reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tran_date` date NOT NULL DEFAULT '0000-00-00',
  `due_date` date NOT NULL DEFAULT '0000-00-00',
  `ov_amount` double NOT NULL DEFAULT '0',
  `ov_discount` double NOT NULL DEFAULT '0',
  `ov_gst` double NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '1',
  `alloc` double NOT NULL DEFAULT '0',
  `tax_included` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`trans_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_supp_trans` ###


### Structure of table `fa_suppliers` ###

DROP TABLE IF EXISTS `fa_suppliers`;

CREATE TABLE `fa_suppliers` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `supp_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `supp_ref` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `supp_address` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `gst_no` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `contact` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `supp_account_no` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `website` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bank_account` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `curr_code` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_terms` int(11) DEFAULT NULL,
  `tax_included` tinyint(1) NOT NULL DEFAULT '0',
  `dimension_id` int(11) DEFAULT '0',
  `dimension2_id` int(11) DEFAULT '0',
  `tax_group_id` int(11) DEFAULT NULL,
  `credit_limit` double NOT NULL DEFAULT '0',
  `purchase_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payable_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payment_discount_account` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `notes` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `vendor_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `address_pin` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `supp_address_pin` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address_state` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `supp_address_state` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `bank_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `bank_account_number` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `bank_ifsc` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `address_country` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `supp_country` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_suppliers` ###

INSERT INTO `fa_suppliers` VALUES
('1', 'Sweta Infotech', 'SI', 'Nehru Nagar', 'Nehru Nagar', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800013', '800013', '1479', '1479', '', '', '', '99', '99'),
('2', 'Sify Technologies Private Limited', 'Sify', 'Anan Plaza, Near RBI &amp; Subhash Park South Gandhi Maidan  Road Patna ', 'Anan Plaza, Near RBI &amp; Subhash Park South Gandhi Maidan  Road Patna ', '10AAACS9032R1Z6', '', 'Sify001', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', 'Internet Service Provider', '0', 'vendor-001', '800001', '800001', '1479', '800001', '', '', '', '1479', '1479'),
('3', 'Microsof Corporation', 'Microsof', 'Shed No1.1 B Situated at 23/5 Delhi Mathura Road, Ballabhgarh \n', 'Shed No1.1 B Situated at 23/5 Delhi Mathura Road, Ballabhgarh \n', '06AAACM5586C1zl', '', 'Micro001', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-001', '121004', '121004', '1486', '121004', '', '', '', '1486', '1486'),
('4', 'Lalita Electricals', 'Lalita elc', '', 'New Dak Bunglow Road Patna Near Shambhu Nath Plaza\n', '10AJLPS8057M1Z0', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1479'),
('5', 'IT Vision', 'IT Vision', '', ' Karpura House S. p verma Road Patna\n', '10ACOPR3183P1Z2', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', ' Karpura House S. p verma Road Patna\n', '0', 'vendor-001', '800001', '800001', '1479', '800001', '', '', '', '1479', '1479'),
('6', 'Google India Private Limited', 'Google ', '', 'Tower B Unitech Signature Tower2 Sector 15 Part 1 Village- silokhera Gurugram Haryana-122002\n', '', '', '06AACCG0527D1ZB', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-001', '122002', '122002', '1486', '1475', '', '', '', '99', '99'),
('7', 'Atria Convergence Technologies Limited', 'Atria', '', '', '36AACA8907B1ZZ', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-001', '800013', '800013', '1479', '800013', '', '', '', '1479', '1479'),
('8', 'AIM Technosoft India private limited', 'AIM Technosoft ', '', '22 Kenderdine Lane , 2nd Floor Room No06 Kolkata-700012\n', '19AAAWCA6740Q1ZL', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-001', '700012', '700012', '1506', '1475', '', '', '', '99', '99'),
('9', 'RepuGen', 'Repu', 'Nehru nagar ', 'Nehru Nagar', '3214569870', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-001', '800013', '800013', '1479', '800013', '', '', '', '1479', '1479'),
('10', 'RepuGen2', 'Repu2', 'Hyderabad', 'hyderabad', '3214569870', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-001', '500016', '500016', '2053', '500016', '', '', '', '2053', '2053'),
('11', 'Muskan Agencay', 'Muskan Agencay', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1479'),
('12', 'Amazon.in', 'Amazon.in', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('13', 'Ayam ', 'Ayam', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('14', 'Shree Agencies ', 'Shree Agencies ', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('15', 'Industrial Machinary &amp; Services ', 'Industrial Machinary &amp; Ser', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('16', 'Flipkart.com ', 'Flipkart.com ', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('17', 'Network Crae', 'Network Crae', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('18', 'Service World', 'Service World', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('19', 'Super Computer', 'Super Computer', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('20', 'Travel store', 'Travel store', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('21', 'Maruti Battery Center', 'Maruti Battery Center', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('22', 'Mi.com', 'Mi.com', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('23', 'New Hello Mobile', 'New Hello Mobile', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('24', 'Digital Equipments', 'Digital Equipments', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('25', 'Total Solution ', 'Total Solution ', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('26', 'The Telecon', 'The Telecon', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('27', 'Super Fast Laptop Repair', 'Super Fast Laptop Repair', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475'),
('28', 'SK ENTERPRISES', 'SK ENTERPRISES', '', '', '', '', '', '', '', 'INR', '4', '0', '0', '0', '1', '0', '', '', '', '', '0', 'vendor-002', '800001', '800001', '1479', '800001', '', '', '', '1479', '1475');

### Structure of table `fa_sys_group` ###

DROP TABLE IF EXISTS `fa_sys_group`;

CREATE TABLE `fa_sys_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `component` varchar(100) NOT NULL,
  `work_center` varchar(100) NOT NULL,
  `loc_code` varchar(100) NOT NULL,
  `quantity` double NOT NULL,
  `serial_no` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `issue_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ;

### Data of table `fa_sys_group` ###

INSERT INTO `fa_sys_group` VALUES
('1', '19', 'FB-CPU-Test', '2', 'PAT', '1', '', '0', '2023-09-20'),
('2', '13', 'FB-CPU-058', '2', 'PAT', '1', '', '0', '2023-09-20'),
('3', '13', '16GBDDR3', '2', 'PAT', '1', '', '0', '2023-09-20');

### Structure of table `fa_sys_prefs` ###

DROP TABLE IF EXISTS `fa_sys_prefs`;

CREATE TABLE `fa_sys_prefs` (
  `name` varchar(35) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `category` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `length` smallint(6) DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_sys_prefs` ###

INSERT INTO `fa_sys_prefs` VALUES
('accounts_alpha', 'glsetup.general', 'tinyint', '1', '0'),
('accumulate_shipping', 'glsetup.customer', 'tinyint', '1', '0'),
('add_pct', 'setup.company', 'int', '5', '-1'),
('allow_negative_prices', 'glsetup.inventory', 'tinyint', '1', '1'),
('allow_negative_stock', 'glsetup.inventory', 'tinyint', '1', '0'),
('alternative_tax_include_on_docs', 'setup.company', 'tinyint', '1', ''),
('auto_curr_reval', 'setup.company', 'smallint', '6', '1'),
('bank_charge_act', 'glsetup.general', 'varchar', '15', '5690'),
('barcodes_on_stock', 'setup.company', 'tinyint', '1', '0'),
('base_sales', 'setup.company', 'int', '11', '1'),
('bcc_email', 'setup.company', 'varchar', '100', ''),
('company_logo_report', 'setup.company', 'tinyint', '1', '0'),
('coy_logo', 'setup.company', 'varchar', '100', 'logo.png'),
('coy_name', 'setup.company', 'varchar', '60', 'Finesse Web Tech'),
('coy_no', 'setup.company', 'varchar', '25', '123456789'),
('creditors_act', 'glsetup.purchase', 'varchar', '15', '2100'),
('curr_default', 'setup.company', 'char', '3', 'INR'),
('debtors_act', 'glsetup.sales', 'varchar', '15', '1200'),
('default_adj_act', 'glsetup.items', 'varchar', '15', '5040'),
('default_cogs_act', 'glsetup.items', 'varchar', '15', '5010'),
('default_credit_limit', 'glsetup.customer', 'int', '11', '1000'),
('default_delivery_required', 'glsetup.sales', 'smallint', '6', '1'),
('default_dim_required', 'glsetup.dims', 'int', '11', '20'),
('default_inv_sales_act', 'glsetup.items', 'varchar', '15', '4010'),
('default_inventory_act', 'glsetup.items', 'varchar', '15', '1510'),
('default_loss_on_asset_disposal_act', 'glsetup.items', 'varchar', '15', '5660'),
('default_prompt_payment_act', 'glsetup.sales', 'varchar', '15', '4500'),
('default_quote_valid_days', 'glsetup.sales', 'smallint', '6', '30'),
('default_receival_required', 'glsetup.purchase', 'smallint', '6', '10'),
('default_sales_act', 'glsetup.sales', 'varchar', '15', '4010'),
('default_sales_discount_act', 'glsetup.sales', 'varchar', '15', '4510'),
('default_wip_act', 'glsetup.items', 'varchar', '15', '1530'),
('default_workorder_required', 'glsetup.manuf', 'int', '11', '20'),
('deferred_income_act', 'glsetup.sales', 'varchar', '15', ''),
('depreciation_period', 'glsetup.company', 'tinyint', '1', '1'),
('domicile', 'setup.company', 'varchar', '55', ''),
('email', 'setup.company', 'varchar', '100', 'accounts@domain.com'),
('exchange_diff_act', 'glsetup.general', 'varchar', '15', '4450'),
('f_year', 'setup.company', 'int', '11', '7'),
('fax', 'setup.company', 'varchar', '30', '+91 (44) 2222-2221'),
('freight_act', 'glsetup.customer', 'varchar', '15', '4430'),
('gl_closing_date', 'setup.closing_date', 'date', '8', '2019-03-31'),
('grn_clearing_act', 'glsetup.purchase', 'varchar', '15', '0'),
('gst_no', 'setup.company', 'varchar', '25', '9876543'),
('legal_text', 'glsetup.customer', 'tinytext', '0', ''),
('loc_notification', 'glsetup.inventory', 'tinyint', '1', '0'),
('login_tout', 'setup.company', 'smallint', '6', '1000'),
('no_customer_list', 'setup.company', 'tinyint', '1', '0'),
('no_item_list', 'setup.company', 'tinyint', '1', '0'),
('no_supplier_list', 'setup.company', 'tinyint', '1', '0'),
('no_zero_lines_amount', 'glsetup.sales', 'tinyint', '1', '1'),
('past_due_days', 'glsetup.general', 'int', '11', '30'),
('payroll_deductleave_act', NULL, 'int', NULL, '5410'),
('payroll_month_work_days', NULL, 'float', NULL, '26'),
('payroll_overtime_act', NULL, 'int', NULL, '5420'),
('payroll_payable_act', NULL, 'int', NULL, '2100'),
('payroll_work_hours', NULL, 'float', NULL, '8'),
('phone', 'setup.company', 'varchar', '30', '+91 (44) 2222-2222'),
('po_over_charge', 'glsetup.purchase', 'int', '11', '10'),
('po_over_receive', 'glsetup.purchase', 'int', '11', '10'),
('postal_address', 'setup.company', 'tinytext', '0', 'Nehru Nagar patna'),
('print_dialog_direct', 'setup.company', 'tinyint', '1', '0'),
('print_invoice_no', 'glsetup.sales', 'tinyint', '1', '0'),
('print_item_images_on_quote', 'glsetup.inventory', 'tinyint', '1', '0'),
('profit_loss_year_act', 'glsetup.general', 'varchar', '15', '9990'),
('pyt_discount_act', 'glsetup.purchase', 'varchar', '15', '5060'),
('ref_no_auto_increase', 'setup.company', 'tinyint', '1', '0'),
('retained_earnings_act', 'glsetup.general', 'varchar', '15', '3590'),
('round_to', 'setup.company', 'int', '5', '1'),
('shortname_name_in_list', 'setup.company', 'tinyint', '1', ''),
('show_po_item_codes', 'glsetup.purchase', 'tinyint', '1', '0'),
('state', NULL, '', NULL, '1479'),
('suppress_tax_rates', 'setup.company', 'tinyint', '1', ''),
('tax_algorithm', 'glsetup.customer', 'tinyint', '1', '1'),
('tax_last', 'setup.company', 'int', '11', '1'),
('tax_prd', 'setup.company', 'int', '11', '1'),
('time_zone', 'setup.company', 'tinyint', '1', '1'),
('use_dimension', 'setup.company', 'tinyint', '1', '1'),
('use_fixed_assets', 'setup.company', 'tinyint', '1', '1'),
('use_manufacturing', 'setup.company', 'tinyint', '1', '1'),
('version_id', 'system', 'varchar', '11', '2.4.1');

### Structure of table `fa_sys_types` ###

DROP TABLE IF EXISTS `fa_sys_types`;

CREATE TABLE `fa_sys_types` (
  `type_id` smallint(6) NOT NULL DEFAULT '0',
  `type_no` int(11) NOT NULL DEFAULT '1',
  `next_reference` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

### Data of table `fa_sys_types` ###


### Structure of table `fa_tag_associations` ###

DROP TABLE IF EXISTS `fa_tag_associations`;

CREATE TABLE `fa_tag_associations` (
  `record_id` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `tag_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_tag_associations` ###


### Structure of table `fa_tags` ###

DROP TABLE IF EXISTS `fa_tags`;

CREATE TABLE `fa_tags` (
  `id` int(11) NOT NULL,
  `type` smallint(6) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_tags` ###


### Structure of table `fa_tax_group_items` ###

DROP TABLE IF EXISTS `fa_tax_group_items`;

CREATE TABLE `fa_tax_group_items` (
  `tax_group_id` int(11) NOT NULL DEFAULT '0',
  `tax_type_id` int(11) NOT NULL DEFAULT '0',
  `tax_shipping` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tax_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_tax_group_items` ###

INSERT INTO `fa_tax_group_items` VALUES
('1', '1', '0');

### Structure of table `fa_tax_groups` ###

DROP TABLE IF EXISTS `fa_tax_groups`;

CREATE TABLE `fa_tax_groups` (
  `id` int(11) NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_tax_groups` ###

INSERT INTO `fa_tax_groups` VALUES
('1', 'Tax', '0'),
('2', 'Tax Exempt', '0');

### Structure of table `fa_tax_slab` ###

DROP TABLE IF EXISTS `fa_tax_slab`;

CREATE TABLE `fa_tax_slab` (
  `slab_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_rate` int(11) NOT NULL,
  `tax_description` varchar(150) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`slab_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ;

### Data of table `fa_tax_slab` ###

INSERT INTO `fa_tax_slab` VALUES
('1', '0', 'GST Free', '1'),
('2', '5', 'First Slab', '1');

### Structure of table `fa_tax_types` ###

DROP TABLE IF EXISTS `fa_tax_types`;

CREATE TABLE `fa_tax_types` (
  `id` int(11) NOT NULL,
  `rate` double NOT NULL DEFAULT '0',
  `sales_gl_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `purchasing_gl_code` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_tax_types` ###

INSERT INTO `fa_tax_types` VALUES
('1', '12.36', '2150', '2145', 'VAT', '0');

### Structure of table `fa_tour_request_details` ###

DROP TABLE IF EXISTS `fa_tour_request_details`;

CREATE TABLE `fa_tour_request_details` (
  `id` int(11) NOT NULL,
  `place` varchar(50) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `auth_by` varchar(40) NOT NULL,
  `departure_date` datetime NOT NULL,
  `arrival_date` datetime NOT NULL,
  `name` varchar(50) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `tour_id` varchar(50) NOT NULL,
  `bill_id` varchar(50) NOT NULL,
  `total_amount` float NOT NULL,
  `submit_date` date NOT NULL,
  `status` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_tour_request_details` ###

INSERT INTO `fa_tour_request_details` VALUES
('116', 'patna', 'meeting', 'Ritika', '2019-07-05 10:00:00', '2019-07-05 23:00:00', 'Today', 'EMP-F-008', 'TRD-07-2019-117', 'T_Bill_TRD-07-2019-117', '0', '2019-07-05', '1'),
('117', 'patna', 'For Demo', 'Shreekant', '2019-08-26 09:00:00', '2019-08-26 16:50:00', 'Omprakash', 'EMP-F-001', 'TRD-08-2019-118', 'T_Bill_TRD-08-2019-118', '0', '2019-08-26', '0'),
('118', 'delhi', 'meeting', 'manager', '2020-01-25 16:00:00', '2020-01-26 16:00:00', 'Administrator', '', 'TRD-01-2020-119', 'T_Bill_TRD-01-2020-119', '0', '2020-01-27', '0');

### Structure of table `fa_trans_tax_details` ###

DROP TABLE IF EXISTS `fa_trans_tax_details`;

CREATE TABLE `fa_trans_tax_details` (
  `id` int(11) NOT NULL,
  `trans_type` smallint(6) DEFAULT NULL,
  `trans_no` int(11) DEFAULT NULL,
  `tran_date` date NOT NULL,
  `tax_type_id` int(11) NOT NULL DEFAULT '0',
  `rate` double NOT NULL DEFAULT '0',
  `ex_rate` double NOT NULL DEFAULT '1',
  `included_in_price` tinyint(1) NOT NULL DEFAULT '0',
  `net_amount` double NOT NULL DEFAULT '0',
  `amount` double NOT NULL DEFAULT '0',
  `memo` tinytext COLLATE utf8_unicode_ci,
  `reg_type` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_trans_tax_details` ###


### Structure of table `fa_type` ###

DROP TABLE IF EXISTS `fa_type`;

CREATE TABLE `fa_type` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `inactive` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_type` ###

INSERT INTO `fa_type` VALUES
('1', 'Amc', '0'),
('2', 'Non Amc', '0');

### Structure of table `fa_type_maintenance` ###

DROP TABLE IF EXISTS `fa_type_maintenance`;

CREATE TABLE `fa_type_maintenance` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `maintain_type` varchar(100) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ;

### Data of table `fa_type_maintenance` ###

INSERT INTO `fa_type_maintenance` VALUES
('1', 'Preventive'),
('2', 'N/A'),
('3', 'Breakdown');

### Structure of table `fa_user_assign_group` ###

DROP TABLE IF EXISTS `fa_user_assign_group`;

CREATE TABLE `fa_user_assign_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `added_date` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_user_assign_group` ###


### Structure of table `fa_user_attendance` ###

DROP TABLE IF EXISTS `fa_user_attendance`;

CREATE TABLE `fa_user_attendance` (
  `w_id` int(11) NOT NULL,
  `empl_id` varchar(100) NOT NULL,
  `a_in_time` datetime DEFAULT NULL,
  `a_out_time` datetime DEFAULT NULL,
  `working_hours` int(11) NOT NULL,
  PRIMARY KEY (`w_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_user_attendance` ###


### Structure of table `fa_user_issue_items` ###

DROP TABLE IF EXISTS `fa_user_issue_items`;

CREATE TABLE `fa_user_issue_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `qty_issued` double DEFAULT NULL,
  `unit_cost` double NOT NULL DEFAULT '0',
  `sl_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_user_issue_items` ###


### Structure of table `fa_user_issues` ###

DROP TABLE IF EXISTS `fa_user_issues`;

CREATE TABLE `fa_user_issues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` int(11) NOT NULL DEFAULT '0',
  `floor` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `room` int(11) NOT NULL,
  `department` int(11) NOT NULL,
  `seat` int(11) NOT NULL,
  `issue_date` date DEFAULT NULL,
  `department_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employee_id` varchar(110) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_user_issues` ###

INSERT INTO `fa_user_issues` VALUES
('1', '1', '1', '1', '1', '1', '2023-09-20', '6', 'EMP-F-100'),
('2', '1', '1', '1', '1', '10', '2023-09-20', '2', 'EMP-F-196');

### Structure of table `fa_user_workinghours` ###

DROP TABLE IF EXISTS `fa_user_workinghours`;

CREATE TABLE `fa_user_workinghours` (
  `id` int(11) NOT NULL,
  `full_day` float NOT NULL,
  `half_day` float NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_user_workinghours` ###

INSERT INTO `fa_user_workinghours` VALUES
('1', '8.5', '4.5', '1');

### Structure of table `fa_useronline` ###

DROP TABLE IF EXISTS `fa_useronline`;

CREATE TABLE `fa_useronline` (
  `id` int(11) NOT NULL,
  `timestamp` int(15) NOT NULL DEFAULT '0',
  `ip` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `file` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_useronline` ###


### Structure of table `fa_users` ###

DROP TABLE IF EXISTS `fa_users`;

CREATE TABLE `fa_users` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `real_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `role_id` int(11) NOT NULL DEFAULT '1',
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_format` tinyint(1) NOT NULL DEFAULT '0',
  `date_sep` tinyint(1) NOT NULL DEFAULT '0',
  `tho_sep` tinyint(1) NOT NULL DEFAULT '0',
  `dec_sep` tinyint(1) NOT NULL DEFAULT '0',
  `theme` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `page_size` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'A4',
  `prices_dec` smallint(6) NOT NULL DEFAULT '2',
  `qty_dec` smallint(6) NOT NULL DEFAULT '2',
  `rates_dec` smallint(6) NOT NULL DEFAULT '4',
  `percent_dec` smallint(6) NOT NULL DEFAULT '1',
  `show_gl` tinyint(1) NOT NULL DEFAULT '1',
  `show_codes` tinyint(1) NOT NULL DEFAULT '0',
  `show_hints` tinyint(1) NOT NULL DEFAULT '0',
  `last_visit_date` datetime DEFAULT NULL,
  `query_size` tinyint(1) unsigned NOT NULL DEFAULT '10',
  `graphic_links` tinyint(1) DEFAULT '1',
  `pos` smallint(6) DEFAULT '1',
  `print_profile` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `rep_popup` tinyint(1) DEFAULT '1',
  `sticky_doc_date` tinyint(1) DEFAULT '0',
  `startup_tab` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `transaction_days` int(6) NOT NULL DEFAULT '30' COMMENT 'Transaction days',
  `save_report_selections` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Save Report Selection Days',
  `use_date_picker` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Use Date Picker for all Date Values',
  `def_print_destination` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Default Report Destination',
  `def_print_orientation` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Default Report Orientation',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  `empl_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `in_time` date DEFAULT NULL,
  `out_time` date DEFAULT NULL,
  `attempts` int(11) DEFAULT NULL,
  `frgt_status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_users` ###

INSERT INTO `fa_users` VALUES
('1', 'admin', 'e10adc3949ba59abbe56e057f20f883e', 'Administrator', '2', '9874563210', 'admin@gmail.com', 'en_IN', '1', '2', '0', '0', 'dynamic', 'A4', '2', '2', '4', '1', '1', '1', '1', '2023-10-26 10:36:34', '10', '1', '1', '', '1', '0', 'extendedhrm', '30', '0', '1', '0', '0', '0', 'superAdmin', '2023-05-01', NULL, '0', '0');

### Structure of table `fa_utility` ###

DROP TABLE IF EXISTS `fa_utility`;

CREATE TABLE `fa_utility` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `sub_cat_id` int(11) NOT NULL,
  `items_id` text NOT NULL,
  `name` varchar(50) NOT NULL,
  `maintenance_type_id` int(2) NOT NULL,
  `description` varchar(100) NOT NULL,
  `freq_id` text NOT NULL,
  `inactive` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

### Data of table `fa_utility` ###

INSERT INTO `fa_utility` VALUES
('1', '1', '1', '45', '', '', '1', 'cleaning AC', '1', '0');

### Structure of table `fa_utility_category` ###

DROP TABLE IF EXISTS `fa_utility_category`;

CREATE TABLE `fa_utility_category` (
  `cats_id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  `inactive` int(11) NOT NULL,
  PRIMARY KEY (`cats_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ;

### Data of table `fa_utility_category` ###

INSERT INTO `fa_utility_category` VALUES
('1', 'Utility', '0'),
('2', 'Process', '0');

### Structure of table `fa_utility_maintenance` ###

DROP TABLE IF EXISTS `fa_utility_maintenance`;

CREATE TABLE `fa_utility_maintenance` (
  `ut_maintain_id` int(11) NOT NULL AUTO_INCREMENT,
  `utility_id` int(11) NOT NULL,
  `frequency_id` int(11) NOT NULL,
  `ut_check1` int(2) NOT NULL,
  `ut_check2` int(2) NOT NULL,
  `ut_check3` int(2) NOT NULL,
  `ut_check4` int(2) NOT NULL,
  `ut_check5` int(2) NOT NULL,
  `ut_check6` int(2) NOT NULL,
  `obv_date` text NOT NULL,
  `obv_1` varchar(200) NOT NULL,
  `obv_2` varchar(200) NOT NULL,
  `obv_3` varchar(200) NOT NULL,
  PRIMARY KEY (`ut_maintain_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_utility_maintenance` ###


### Structure of table `fa_utility_parameter_items` ###

DROP TABLE IF EXISTS `fa_utility_parameter_items`;

CREATE TABLE `fa_utility_parameter_items` (
  `items_id` int(11) NOT NULL AUTO_INCREMENT,
  `ut_param_id` int(11) NOT NULL,
  `param_title` text NOT NULL,
  `param_desc` text NOT NULL,
  `inactive` int(11) NOT NULL,
  PRIMARY KEY (`items_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ;

### Data of table `fa_utility_parameter_items` ###

INSERT INTO `fa_utility_parameter_items` VALUES
('1', '1', 'Air Cleaning', 'Air Cleaning', '0'),
('2', '1', 'Washing', 'Washing', '0');

### Structure of table `fa_utility_parameters_master` ###

DROP TABLE IF EXISTS `fa_utility_parameters_master`;

CREATE TABLE `fa_utility_parameters_master` (
  `ut_param_id` int(11) NOT NULL AUTO_INCREMENT,
  `utly_type` int(11) NOT NULL,
  `utly_cat_id` int(11) NOT NULL,
  `utly_sub_cat_id` int(11) NOT NULL,
  `utilitys_id` int(11) NOT NULL,
  `type_maintenance_id` int(2) NOT NULL,
  `frequency_id` int(11) NOT NULL,
  `inactive` int(11) NOT NULL,
  PRIMARY KEY (`ut_param_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

### Data of table `fa_utility_parameters_master` ###

INSERT INTO `fa_utility_parameters_master` VALUES
('1', '1', '1', '45', '0', '1', '1', '0');

### Structure of table `fa_vehicle` ###

DROP TABLE IF EXISTS `fa_vehicle`;

CREATE TABLE `fa_vehicle` (
  `id` int(11) NOT NULL,
  `vehicle_id` varchar(50) NOT NULL,
  `vehicle_no` varchar(50) NOT NULL,
  `reg_no` varchar(50) NOT NULL,
  `seating_capacity` int(11) NOT NULL,
  `driver_name` varchar(50) NOT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_vehicle` ###

INSERT INTO `fa_vehicle` VALUES
('0', 'vehicle-007', '20', '1', '7', '', '1'),
('1', 'vehicle-001', 'R-001', '1', '7', 'Ritika kumari pd', '1'),
('2', 'vehicle-001', 'M-11', '1', '7', 'Ritika kumari pd', '1'),
('3', 'vehicle-002', 'M-12', '4', '5', 'kundan33', '1'),
('4', 'vehicle-003', 'M-13', '12', '6', 'Kundan', '1'),
('5', 'vehicle-004', 'M-13', '1', '7', 'Ritika kumari pd', '1'),
('6', 'vehicle-005', 'M-12', '2', '4', 'Ritika kumari', '1'),
('7', 'vehicle-006', 'M24636', '1', '7', 'Ritika kumari pd', '1');

### Structure of table `fa_vendor_details` ###

DROP TABLE IF EXISTS `fa_vendor_details`;

CREATE TABLE `fa_vendor_details` (
  `id` int(11) NOT NULL,
  `cat_id` varchar(80) NOT NULL,
  `fascial_year` int(10) NOT NULL,
  `vendor_type` varchar(100) NOT NULL,
  `cumulative_payment` int(10) NOT NULL,
  `single_payment` int(10) NOT NULL,
  `percentage` int(10) NOT NULL DEFAULT '1',
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_vendor_details` ###

INSERT INTO `fa_vendor_details` VALUES
('4', 'vendor-001', '2', 'Software', '2000', '700', '8', '1'),
('5', 'vendor-002', '3', 'Hardware', '10001', '8001', '23', '1');

### Structure of table `fa_visitor_management` ###

DROP TABLE IF EXISTS `fa_visitor_management`;

CREATE TABLE `fa_visitor_management` (
  `vistitor_id` int(11) NOT NULL,
  `ref_id` varchar(50) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `to_meet` varchar(100) NOT NULL,
  `company` varchar(100) NOT NULL,
  `coming_from` varchar(100) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `contact_number` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `tr_fromdate` datetime DEFAULT NULL,
  `tr_todate` datetime DEFAULT NULL,
  `remarks` text NOT NULL,
  `inserted_date` date DEFAULT NULL,
  PRIMARY KEY (`vistitor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

### Data of table `fa_visitor_management` ###

INSERT INTO `fa_visitor_management` VALUES
('1', 'ref-001', 'Ritika', 'Kumari', 'HR', 'Finessewebtech', 'kidwaipuri', 'meeting', '6200104322', 'test@test.com', '2019-07-15 12:39:00', NULL, 'meeting regarding job', '2019-07-15'),
('2', 'ref-002', 'tsq', 'dsd', 'ss', 'ddfd', 'd', 'dd', '9874563210', 'ssdf@gmail.com', '2020-01-21 18:02:00', NULL, 'jhvjhkj', '2020-01-21');

### Structure of table `fa_voided` ###

DROP TABLE IF EXISTS `fa_voided`;

CREATE TABLE `fa_voided` (
  `type` int(11) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL,
  `date_` date NOT NULL DEFAULT '0000-00-00',
  `memo_` tinytext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_voided` ###


### Structure of table `fa_wo_costing` ###

DROP TABLE IF EXISTS `fa_wo_costing`;

CREATE TABLE `fa_wo_costing` (
  `id` int(11) NOT NULL,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `cost_type` tinyint(1) NOT NULL DEFAULT '0',
  `trans_type` int(11) NOT NULL DEFAULT '0',
  `trans_no` int(11) NOT NULL DEFAULT '0',
  `factor` double NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_wo_costing` ###


### Structure of table `fa_wo_issue_items` ###

DROP TABLE IF EXISTS `fa_wo_issue_items`;

CREATE TABLE `fa_wo_issue_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `qty_issued` double DEFAULT NULL,
  `unit_cost` double NOT NULL DEFAULT '0',
  `sl_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_wo_issue_items` ###


### Structure of table `fa_wo_issues` ###

DROP TABLE IF EXISTS `fa_wo_issues`;

CREATE TABLE `fa_wo_issues` (
  `issue_no` int(11) NOT NULL AUTO_INCREMENT,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `reference` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `loc_code` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workcentre_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`issue_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_wo_issues` ###


### Structure of table `fa_wo_manufacture` ###

DROP TABLE IF EXISTS `fa_wo_manufacture`;

CREATE TABLE `fa_wo_manufacture` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `quantity` double NOT NULL DEFAULT '0',
  `date_` date NOT NULL DEFAULT '0000-00-00',
  `item_code` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stock_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_wo_manufacture` ###

INSERT INTO `fa_wo_manufacture` VALUES
('1', '1', '1', '1', '2023-09-21', 'FB-CPU-Test', '1'),
('2', '2', '2', '1', '2023-09-21', 'FB-CPU-Test21', '0');

### Structure of table `fa_wo_requirements` ###

DROP TABLE IF EXISTS `fa_wo_requirements`;

CREATE TABLE `fa_wo_requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `workorder_id` int(11) NOT NULL DEFAULT '0',
  `stock_id` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `workcentre` int(11) NOT NULL DEFAULT '0',
  `units_req` double NOT NULL DEFAULT '1',
  `unit_cost` double NOT NULL DEFAULT '0',
  `loc_code` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `units_issued` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_wo_requirements` ###

INSERT INTO `fa_wo_requirements` VALUES
('1', '1', '16GBDDR3', '2', '1', '0', 'PAT', '1'),
('2', '1', '1TBHDD', '2', '1', '0', 'PAT', '1'),
('4', '2', '16GBDDR3', '2', '1', '0', 'PAT', '1'),
('5', '2', '1TBHDD', '2', '1', '0', 'PAT', '1');

### Structure of table `fa_workcentres` ###

DROP TABLE IF EXISTS `fa_workcentres`;

CREATE TABLE `fa_workcentres` (
  `id` int(11) NOT NULL,
  `name` char(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` char(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `inactive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_workcentres` ###

INSERT INTO `fa_workcentres` VALUES
('2', 'Patna', 'Nehru Nagar', '0');

### Structure of table `fa_workorders` ###

DROP TABLE IF EXISTS `fa_workorders`;

CREATE TABLE `fa_workorders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wo_ref` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `loc_code` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `units_reqd` double NOT NULL DEFAULT '1',
  `stock_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date_` date NOT NULL DEFAULT '0000-00-00',
  `type` tinyint(4) NOT NULL DEFAULT '0',
  `required_by` date NOT NULL DEFAULT '0000-00-00',
  `released_date` date NOT NULL DEFAULT '0000-00-00',
  `units_issued` double NOT NULL DEFAULT '0',
  `closed` tinyint(1) NOT NULL DEFAULT '0',
  `released` tinyint(1) NOT NULL DEFAULT '0',
  `additional_costs` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

### Data of table `fa_workorders` ###

INSERT INTO `fa_workorders` VALUES
('1', '1', 'PAT', '1', '1Gigabyte', '0000-00-00', '2', '2023-10-11', '2023-09-21', '1', '1', '1', '0'),
('2', '2', 'PAT', '1', 'Corsiar1', '0000-00-00', '2', '2023-10-11', '2023-09-21', '1', '1', '1', '0');